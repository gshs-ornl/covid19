#!/usr/bin/env Rscript
# Utilities used to combine all the CSVs in the directory and export as a single
# CSV file that will be imported into the database for python


# iterate_files -----------------------------------------------------------
#' @title       iterate through a given file vector
#' @param files the files to iterate over
#' @return      an rbindlist call from data.table
#' @export
iterate_files <- function(files) {
  file_list <- list()
  for (f in files) {
        candidate <- try_fread(f, integer64 = 'character', logical01 = FALSE)
        file_list[[f]] <- candidate
  }
  data.table::rbindlist(file_list, fill = TRUE)
}
# retrieve_candidate_files ------------------------------------------------
#' @title       retrieve candidate fiels for ingestion
#' @description using the value of the OUTPUT_DIR system variable, create a list
#'              of all the
#' @export
retrieve_candidate_files <- function(dir = NULL) {
  if (is.null(dir)) {
    dir <- evaluate_env_dir(dir, 'OUTPUT_DIR')
  }
  automated_scrapes <- list.files(path = dir,
                                  pattern = '^covidR.*.csv$',
                                  full.names = TRUE,
                                  ignore.case = TRUE)
  py_regex <- paste0('^(', paste0(tolower(state.name), collapse = '|'),
                             ')')
  py_scrapes <- list.files(path = dir,
                           pattern = py_regex,
                           full.names = TRUE,
                           ignore.case = TRUE)
  automated_scrapes <- automated_scrapes[
    !grepl('(hattiesburg|hopkins|tomq|nyt|manual)', automated_scrapes,
           ignore.case = TRUE, perl = FALSE)]
  manual_scrapes <- list.files(path = dir,
                               pattern = '.*manual.*\\.csv$',
                               full.names = TRUE, ignore.case = TRUE)
  hattiesburg_scrapes <- list.files(path = dir,
                                    pattern = '.*hattiesburg_raw.*\\.csv$',
                                    ignore.case = TRUE, full.names = TRUE)
  nyt_county_scrapes <- list.files(path = dir,
                                   pattern = '.*nyt_counties_raw.*csv$',
                                   ignore.case = TRUE, full.names = TRUE)
  nyt_state_scrapes <- list.files(path = dir,
                                  pattern = '.*nyt_states_raw.*csv$',
                                  ignore.case = TRUE, full.names = TRUE)
  tomq_scrapes <- list.files(path = dir,
                             pattern = '.*tomq_once_raw.*csv$',
                             ignore.case = TRUE, full.names = TRUE)
  hopkins_scrapes <- list.files(path = dir,
                                pattern = '.*hopkins_daily_once_raw.*.csv',
                                ignore.case = TRUE, full.names = TRUE)
  return(list(
    automated = automated_scrapes,
    manual = manual_scrapes,
    hattiesburg = hattiesburg_scrapes,
    nyt_county = nyt_county_scrapes,
    nyt_state = nyt_state_scrapes,
    tomq = tomq_scrapes,
    hopkins = hopkins_scrapes,
    py_scrapes = py_scrapes
  ))
}
# try_fread ---------------------------------------------------------------
#' @title       try fread for a given file
#' @description tries to read a file; if an error is raised,  prints the message
#'              and returns an empty data.table object
#' @param x the file location to read the data from
#' @param ... additional options that can be passed to data.table::fread
#' @return      a data.table::data.table() object
#' @export
try_fread <- function(x, ...) {
  message(gettextf('Processing file: %s', x))
  tryCatch({
    data.table::fread(x, fill = TRUE, ...)
  },
  error = function(e) {
    cat('\nError reading in file: ', x, '\n')
    warning(e)
    data.table::data.table()
  },
  warning = function(cond) {
    data.table::fread(x, fill = TRUE, ...)
  })
}
# Evaluate a Directory Variable -------------------------------------------
#' @title       evaluate a directory system variable
#' @description evaluates a system variable and stops if does not exist
#' @param x either a character representing a file or, more usefully, a
#'          Sys.getenv() of the system variable
#' @param env NULL, if provided assumes that x is a default directory
#' @export
evaluate_env_dir <- function(x = '', env = NULL) {
  if (is.null(env)) stopifnot(dir.exists(x)); return(x)
  if (x != '') stopifnot(dir.exists(x)); return(x)
  stopifnot(Sys.getenv(env) != '')
  return(Sys.getenv(env))
}
# name_curation -----------------------------------------------------------
#' @title       given a curation type, return a filename
#' @param curation_type the type of curation
name_curation <- function(curation_type, input_dir = NULL) {
  if (is.null(input_dir)) {
    input_dir <- Sys.getenv('INPUT_DIR')
  }
  file.path(input_dir, paste0(curation_type, '_', Sys.Date(),
                              '.csv'))
}
# curate_state ------------------------------------------------------------
#' @title       curate automated state scraper files
#' @description adjusts date formats, cleans up the automated state scraper
#'              files
#' @param x a DT or DT-like object matching the state
curate_automated_state <- function(x) {
  tryCatch({
    x[, c(static())]
  },
  error = function(e) {
    message(gettextf('Curating automated scrape encountered issue: %s', e))
  },
  warning = function(e) {
    message(gettextf('Curating automated data encountered an issue: %s', e))
    suppressWarnings(x[,c(static())])
  })
  x
}
# curate_nyt_county -------------------------------------------------------
#' @title       curate the nyt_county_raw files
#' @description converts the NYT county time series fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the output file to
#' @export
curate_nyt_county <- function(x, input_dir = NULL) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  updated <- max(as.Date(x[['date']]))
  x[, `:=`(provider = 'nyt',
           country = 'US',
           url = 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties.csv',
           state = x[['state']],
           county = x[['county']],
           cases = x[['cases']],
           deaths = x[['deaths']],
           fips = x[['fips']],
           updated = updated)]
  fn <- name_curation('nyt_county', input_dir)
  fwrite(x, fn)
  return(x)
}
# curate_nyt_states -------------------------------------------------------
#' @title       curate the nyt_state_raw files
#' @description converts the NYT state time series fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the output file to
#' @export
curate_nyt_state <- function(x, input_dir = NULL) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  updated <- max(as.Date(x[['date']]))
  x[, `:=`(provider = 'ny',
           country = 'US',
           url = 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv',
           state = x[['state']],
           fips = x[['fips']],
           cases = x[['cases']],
           updated = updated,
           deaths = x[['deaths']])]
  fn <- name_curation('nyt_state', input_dir)
  fwrite(x, fn)
  invisible(x)
}
# curate_hopkins ----------------------------------------------------------
#' @title       curate the hopkins files
#' @description converts the hopkins time series fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the input file from
#' @export
curate_hopkins <- function(x, input_dir = NULL) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  gdat <- as.Date('2000-01-01')
  x[, date := gdat]
  x[, Last_Update := gsub('T', ' ', as.character(Last_Update), fixed = TRUE)]
  x[nchar(Last_Update) %in% c(11, 12, 13) & date == gdat,
      date := as.Date(Last_Update, format = '%m/%d/%y %H:%M')]
  x[date != gdat & !is.na(date), Last_Update := NA]
  x[nchar(Last_Update) == 13 & date == gdat,
      date := as.Date(Last_Update, format = '%m/%d/%Y %H:%M')]
  x[date != gdat & !is.na(date), Last_Update := NA]
  x[nchar(Last.Update) %in% c(13,14,15) & date == gdat,
      date := as.Date(Last.Update, format = '%m/%d/%Y %H:%M')]
  x[date != gdat & !is.na(date), Last.Update := NA]
  x[date == gdat, date := anytime::anydate(Last_Update)]
  x[date != gdat & !is.na(date), Last_Update := NA]
  x[date == gdat, `:=`(date = anytime::anydate(Last.Update))]
  x[date != gdat & !is.na(date), Last.Update := NA]
  x[!is.na(Last_Update) & (date == gdat | is.na(date)),
      date := as.Date(Last_Update, format = '%Y-%m-%dT%H:%M:%S')]
  x[date != gdat & !is.na(date), Last_Update := NA]
  x[!is.na(Last.Update) & (date == gdat | is.na(date)),
      date := as.Date(Last.Update, format = '%Y-%m-%dT%H:%M:%S')]
  x[date != gdat & !is.na(date), Last.Update := NA]
  x[, date := format(date, format = '%Y-%m-%d')]
  x[nchar(date) == 8, date := paste0('20', date)]
  x[, date := as.Date(date)]
  ud <- max(x[['date']])
  x[, `:=`(lat = Latitude, lon = Longitude)]
  x[is.na(lat) & is.na(lon), `:=`(lat = Lat, lon = Long_) ]
  x[, `:=`(Last.Update = NULL, Last_Update = NULL, Lat = NULL,
             cases = Confirmed, Long_ = NULL,
             Confirmed = NULL, country = NA_character_,
             deaths = Deaths, state = NA_character_,
             Deaths = NULL, county = NA_character_,
             fips = FIPS, FIPS = NULL)]
  x[Country.Region != '', country := Country.Region]
  x[is.na(country), country := Country_Region]
  x[is.na(state), state := Province.State]
  x[is.na(state) | state == '', state := Province_State]
  x[is.na(county), county := Admin2]
  x[, `:=`(provider = 'jhs', Combined_Key = NULL, Province.State = NULL,
           country = country, Province_State = NULL, Latitude = NULL,
           state = state, Longitude = NULL, Admin2 = NULL,
           date = date, Country_Region = NULL,
           cases = cases,
           recovered = Recovered, Recovered = NULL,
           other = 'Active', other_value = Active, Active = NULL)]
  fn <- name_curation('jhs', input_dir)
  fwrite(x, fn)
  invisible(x)
}
# curate_tomq -------------------------------------------------------------
#' @title       curate the tompq files
#' @description converts the tompq time series fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the input file from
#' @export
curate_tomq <- function(x, input_dir) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  upd <- max(anytime::anydate(x[['Last_Update']]))
  x[,
    `:=`(provider = 'tomq', country = 'US',
         state = State_Name,
         State_Name = NULL, updated = upd,
         url = 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/',
         county = County_Name, County_Name = NULL,
         date = anytime::anydate(Last_Update),
         Last_Update = NULL, cases = Confirmed,  deaths = Death,
         lat = Latitude, Latitude = NULL, lon = Longitude,
         other = 'Fatality Rate', other_value = Fatality_Rate,
         Fatality_Rate = NULL, Longitude = NULL, New_Death = NULL,
         Confirmed = NULL, Death = NULL, New = NULL, updated = upd)]
  x[state == 'New York' & county == 'New York', county := 'New York City']
  fn <- name_curation('tomq', input_dir)
  fwrite(x, fn)
  invisible(x)
}
# curate_hattiesburg ------------------------------------------------------
#' @title       curate the hattiesburg files
#' @description converts the hattiesburg fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the input file from
#' @export
curate_hattiesburg <- function(x, input_dir) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  x[, `:=`(date = as.Date(paste(update_time, '2020'), format = '%B %d %Y'),
           provider = 'hattiesburg', other = 'Active', other_value = active,
           something = NULL, update_time = NULL)]
  x[, updated := max(x[['date']])]
  fn <- name_curation('tomq', input_dir)
  fwrite(x, fn)
  invisible(x)
}
# curate_manual -----------------------------------------------------------
#' @title       curate the manual scrape files
#' @description converts the hattiesburg fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the input file from
#' @export
curate_manual <- function(x, input_dir) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  message('fill in with new data')
  NULL
}
# curate_manual_once ------------------------------------------------------
#' @title       curate the hattiesburg files
#' @description converts the hattiesburg fields into a format suitable
#'              for import into the database
#' @param x a DT or DT-like object of nyt_county_raw type
#' @param input_dir the directory to move the input file from
#' @note       this is not exported, as it should only be called once
curate_manual_once <- function(x, input_dir) {
  if (is.na(input_dir) || is.null(input_dir) || input_dir == '') {
    input_dir <- evaluate_env_dir(env = 'INPUT_DIR')
  }
  dat <- data.table::copy(x)
  # trim up any whitespace that got inserted
  col_classes <- sapply(dat, class)  # get columnar named character classes
  col_class_counts <- table(col_classes)
  char_cols <- names(x)[col_classes == 'character']  # subset to character class
  dat <- clean_dt(dat)
  dat[, (char_cols) := lapply(.SD, stringr::str_trim), .SDcols = char_cols]
  # remove columns with all NAs and NULLs
  dat <- clean_dt(dat)
  dat <- dat[is.na(county) | county == '', `:=`(county = county.county)]
  dat <- dat[is.na(county) | county == '', `:=`(county = counties)]
  dat <- dat[is.na(state_name) | state != '', state := state]
  dat <- dat[is.na(State) | State != '', state := state]
  dat <- dat[, `:=`(county.county = NULL, counties = NULL, state_name = NULL,
                    State = NULL, provider = 'state', country = 'US')]
  dat <- dat[is.na(updated) | updated == '', `:=`(updated = update_time)]
  dat[, `:=`(update_time = NULL, access_time_back = access_time,
             access_time = anytime::anytime(access_time))]
  dat[!is.na(access_time), access_time_back := NA]
  dat[is.na(access_time),
      `:=`(access_time = as.POSIXct(substring(access_time, 1),
                                    format = '0%Y-%m-%d-%H%M%S'))]
  dat[is.na(access_time) | length(access_time) == 0 & nchar(access_time) == 15,
      access_time := as.Date(access_time_back,
                             tryFormats = c('%Y-%m-%d-%H:%M',
                                            '%Y-%m-%d-%H%M%S'))]
  dat[is.na(access_time) | length(access_time) == 0,
      access_time := as.Date(gsub('02020','2020', access_time_back),
                                  format = c('%Y-%m-%d-%H%M%S'))]
  dat[!is.na(access_time) | length(access_time) != 0, access_time_back := NA]
  dat[is.na(access_time), access_time := as.Date('2020/04/01')]
  dat[, access_time_back := NULL]
  gdat <- as.Date('2000/01/01')
  dat[, date := gdat]
  dat[date == gdat & !is.na(updated) & nchar(updated) == 5,
      `:=`(date = as.Date('2020/03/29'), updated = NA)]
  dat[date == gdat & !is.na(updated) & nchar(updated) == 9,
      `:=`(date = as.Date(updated, format = '%m/%d/%Y'), updated = NA)]
  dat[date == gdat & nchar(updated) %in% c(18, 19),
      `:=`(date = as.Date(updated, format = '%Y-%m-%d-%H:%M:%S'))]
  dat[date == gdat & nchar(updated) %in% c(15, 16, 17),
      `:=`(date = as.Date(updated, format = '%Y-%m-%d-%H%M%S'))]
  dat[!is.na(date) & date != gdat , updated := NA]
  dat[is.na(date), date := gdat]
  dat[date == gdat & nchar(updated) == 17,
      date := as.Date(updated, format = '%Y-%m-%d-%H:%M:%S')]
  dat[date == gdat & nchar(updated) == 15,
      date := as.Date(updated, format = '%Y-%m-%d-%H:%M')]
  dat[!is.na(date) & date != gdat , updated := NA]
  dat[is.na(date), date := gdat]
  dat[date == gdat & nchar(updated) == 16,
      date := as.Date(updated, format = '%Y-%m-%d-%H%M%S')]
  dat[date == gdat & nchar(updated) == 16,
      date := as.Date('2020/03/26')]   # hardcoded guess to the 36th of march
  dat[date == gdat & nchar(updated) == 19,
      date := as.Date('2020-03-18-15:38', format = '%Y-%m-%d-%H:%M')]
  dat[!is.na(date) & date != gdat , updated := NA]
  dat[,`:=`(updated = date, date = NULL)]
  dat[, age_case_num := as.integer(age_cases)]
  dat[is.na(age_range) | age_range == '' & cases_age_definition != '' &
        is.na(cases_age_definition),
      `:=`(age_range = cases_age_definition, cases_age_definition = NA)]
  dat[is.na(sex) | sex == '', `:=`(sex = sex_definition, sex_definition = NA)]
  dat[, `:=`(cases_age_definition = NULL, sex_definition = NULL,
             cases_age_value_bak = cases_age_value,
             cases_age_value_try = as.integer(cases_age_value))]
  dat[is.na(cases_age_value_try) & (age_range == '' | is.na(age_range)),
      age_range := cases_age_value_try]
  dat[is.na(age_cases) | age_cases == '', age_cases := cases_age_value_try]
  dat[is.na(age_cases) | age_cases == '', age_cases := age_case_num]
  cn <- c('state', 'url', 'access_time', 'updated', 'county')
  dat[(age_range == '' | is.na(age_range)) & hospitalized_age_definition != '',
      age_range := hospitalized_age_definition]
  dat[(age_range == '' | is.na(age_range)) & age_range_hospitalized != '',
      age_range := age_range_hospitalized]
  dat[, `:=`(age_hospitalized = hospitalized_age_value,
             hospitalized_age_value = NULL)]
  dat[(age_range == '' | is.na(age_range)) & deaths_age_definition != '',
      age_range := deaths_age_definition]
  dat[(age_range == '' | is.na(age_range)) & !is.na(hospitalized_age),
      age_range := hospitalized_age]
  dat[age_cases == '' | is.na(age_cases), age_cases := age_counts]
  dat[age_cases == '' | is.na(age_cases), age_cases := age_case_num]
  dat[sex_counts == '' | is.na(sex_counts), sex_counts := sex_cases]
  dat[age_deaths_percent == '' | is.na(age_deaths_percent),
      age_deaths_percent := deaths_age_percent]
  age_cases <- melt(dat, id.vars = cn,
                    measure.vars = c('cases_0_9',
                                     'cases_0_17',
                                     'cases_0_19',
                                     'cases_10_19',
                                     'cases_18_49',
                                     'cases_20_29',
                                     'cases_30_39',
                                     'cases_40_49',
                                     'cases_50_59',
                                     'cases_60_69',
                                     'cases_70_79',
                                     'cases_50+',
                                     'cases_70+',
                                     'cases_80+'),
                    variable.name = 'age_range', value.name = 'age_counts')
  age_hospitalized <- melt(dat, id.vars = cn,
                    measure.vars = c('hospitalized_0_9',
                                     'hospitalized_0_19',
                                     'hospitalized_10_19',
                                     'hospitalized_20_29',
                                     'hospitalized_30_39',
                                     'hospitalized_40_49',
                                     'hospitalized_50_59',
                                     'hospitalized_60_69',
                                     'hospitalized_70_79',
                                     'hospitalized_80+'),
                    variable.name = 'age_range_hospitalized',
                    value.name = 'hospitalized_age')
  age_deaths <- melt(dat, id.vars = cn,
                    measure.vars = c('deaths_0_9',
                                     'deaths_10_19',
                                     'deaths_20_29',
                                     'deaths_30_39',
                                     'deaths_40_49',
                                     'deaths_50_59',
                                     'deaths_60_69',
                                     'deaths_70_79',
                                     'deaths_80+'),
                    variable.name = 'age_range',
                    value.name = 'age_deaths')
  labs <- melt(dat, id.vars = cn,
               measure.vars = c('tested_comm',
                                'tested_state'),
               variable.name = 'lab',
               value.name = 'lab_tests')
  dat[, `:=`(cases_0_9 = NULL, cases_10_19 = NULL, cases_20_29 = NULL,
             cases_30_39 = NULL, cases_40_49 = NULL, `cases_50+` = NULL,
             cases_50_59 = NULL, cases_60_69 = NULL, `cases_70+` = NULL,
             cases_70_79 = NULL, `cases_80+` = NULL, hospitalized_0_9 = NULL,
             hospitalized_10_19 = NULL, hospitalized_20_29 = NULL,
             hospitalized_30_39 = NULL, hospitalized_40_49 = NULL,
             hospitalized_50_59 = NULL, hospitalized_60_69 = NULL,
             hospitalized_70_79 = NULL, `hospitalized_80+` = NULL)]
  dat[, `:=`(
             hospitalized_0_19 = NULL, cases_18_49 = NULL, cases_0_19 = NULL,
             deaths_0_9 = NULL, deaths_0_19 = NULL, deaths_10_19 = NULL,
             deaths_20_29 = NULL, deaths_30_39 = NULL, deaths_40_49 = NULL,
             deaths_50_59 = NULL, deaths_60_69 = NULL, deaths_70_79 = NULL,
             `deaths_80+` = NULL, cases_0_17 = NULL, counties = NA_integer_,
             no_longer_monitored = no_longer_monitor, no_longer_monitor = NULL)]
  dat[, `:=`(
             icu = ICU, ICU = NULL, cases_age_value = NULL, tested_comm = NULL,
             cases_age_value_try = NULL, tested_state = NULL,
             age_percent = cases_age_percent, age_deaths = deaths_age_value,
             deaths_age_value = NULL, pending = pending_tests,
             pending_tests = NULL, cases_age_value_bak = NULL,
             negative = negative_tests, negative_tests = NULL,
             presumptive = presumptive_positive,  presumptive_positive = NULL,
             page = page_raw, page_raw = NULL)]
  d <- data.table::rbindlist(list(dat, labs, age_deaths, age_hospitalized,
                                  age_cases), fill = TRUE)
  d[, `:=`(region = NA_character_, severe = NA_integer_, lat = NA_real_,
           lon = NA_real_, fips = NA_character_, active = NA_integer_,
           quarantined = NA_integer_, scrape_group = paste0('manual_',updated),
           resolution = 'state', age_negative = NA_integer_,
           age_tested = NA_integer_, sex_cases = NULL,
           cases_age_percent = NULL, hospitalized_age_definition = NULL,
           age_hospitalized_percent = hospitalized_age_percent,

           hospitalized_age_percent = NULL, hospitalized_age = NULL,
           age_case_num = NULL)]
  d[other == '' & other_definition != '',
    `:=`(other = other_definition, other_definition = NA)]
  d[, `:=`(age_cases = age_case_num, age_hospitalized = NULL)]
  invisible(d)
}



# curate_all --------------------------------------------------------------
#' @title       retrieves all current files in the specified path and makes
#'              independent aggregates of each file
#' @description creates aggregate files across providers
#' @param input_dir the location to find the aggregate fiels
#' @param output_dir the location to store the aggregate files
#' @return      locations where each aggregate may be found
#' @export
curate_all <- function(input_dir = NULL, output_dir = NULL) {
  input_dir <- evaluate_env_dir(input_dir, 'INPUT_DIR')
  output_dir <- evaluate_env_dir(output_dir, 'OUTPUT_DIR')
  file_list <- retrieve_candidate_files(input_dir)
  output_files <- c()
  for (i in 1:length(file_list)) {
    message(gettextf('Parsing files of type %s', names(file_list)[i]))
    fn <- file.path(output_dir, paste0(format(Sys.Date(), '%Y-%m-%d'), '_',
                                       names(file_list)[i], '.csv'))
    output_files <- c(output_files, fn)
    dat <- iterate_files(file_list[[i]])
    fwrite(dat, fn)
  }
  return(output_files)
}


