#' @title       Scrape the Alabama Website
#' @description Scrape the Alabama public health website for information about
#'               coronavirus
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_alabama <- function() {
  state <- NULL
  state_name <- 'Alabama'
  timezone <- 'America/Chicago'
  # parsed_url <- covidR::urls[state == state_name][['url']]
  # parse_url <- 'https://www.alabamapublichealth.gov/infectiousdiseases/2019-coronavirus.html'
  #state_url <- 'https://www.wvtm13.com/article/coronavirus-map-alabama/31919956#'
  # state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233180907/'
  state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233180907/'
  # county_url <- 'https://e.infogram.com/api/live/data/368965865/1584753987108/'
  county_url <- 'https://e.infogram.com/api/live/data/368965865/1585233181585/'
  c_page <- jsonlite::fromJSON(county_url)
  s_page <- jsonlite::fromJSON(state_url)
  county <- as.matrix(jsonlite::fromJSON(county_url)$data)
  state <- as.matrix(jsonlite::fromJSON(state_url)$data)
  counties <- county[1:67]
  c_cases <- county[70:135]
  ud <- lubridate::as_datetime(c_page$updated, tz = timezone)
  d2 <- make_dat(state = state_name, url = state_url,
                 tested = gsub(',', '', state[2]),
                 deaths = gsub(',' , '', state[3]), page = s_page,
                 cases = state[1])
  d1 <- make_dat(state = state_name, url = county_url, page = c_page,
                county = counties, cases = c_cases)
  d <- rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'alabama')
  invisible(d)
}

#' @title        Scrape the Alaskan URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_alaska <- function() {
  state_name <- 'Alaska'
  timezone <- 'America/Anchorage'
  # urls <- covidR::urls[state == state_name][['url']]
  url <- 'http://dhss.alaska.gov/dph/Epi/id/Pages/COVID-19/monitoring.aspx'
  page <- xml2::read_html(trimws(url))
  page_raw <- rvest::html_text(page)
  ud <- stringr::str_extract(page_raw, '(?<=Updated )\\w{1,} \\d{1,}, \\d{4,}')
  ud <- lubridate::as_date(paste(ud, '17'), tz = timezone,
                           format = '%B %d, %Y %H')
  tbls <- rvest::html_table(page, header = FALSE, fill = TRUE)
  cdat <- tbls[[1]][-1,]
  cdat <- cdat[-nrow(cdat),]
  sdat <- tbls[[1]][nrow(tbls[[1]]),]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = trimws(sdat[,6]), pending = trimws(sdat[,5]),
                 update_date = ud)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = trimws(cdat[,6]),
                county = trimws(cdat[,1]),
                pending_tests = trimws(cdat[,5]),
                update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'alaska')
  invisible(d)
}

#' @title        Scrape the Arizona URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arizona <- function() {
  state <- NULL
  state_name <- 'Arizona'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- xml2::read_html(trimws(parse_url))
  access_time <- Sys.time()
  print('Arizona requires further development with Selenium')
}

#' @title        Scrape the Arizona URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arkansas <- function() {
  state_name <- 'Arkansas'
  timezone <- 'America/Chicago'
  base_url <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/ArcGIS/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=county_nam%20asc&outSR=102100&resultOffset=0&resultRecordCount=100&cacheHint=true'
  page <- jsonlite::fromJSON(base_url)
  dat <- page$features$attributes
  d1 <- make_dat(state = state_name, url = base_url, page = page,
                county = dat[2:nrow(dat), 'county_nam'],
                cases = dat[2:nrow(dat), 'positive'],
                negative_tests = dat[2:nrow(dat), 'negative'],
                pending_tests = dat[2:nrow(dat), 'pending'],
                tested = dat[2:nrow(dat), 'total_tests'],
                recovered = dat[2:nrow(dat), 'recovered'],
                deaths = dat[2:nrow(dat), 'deaths'])
  d2 <- make_dat(state = state_name, url = base_url, page = page,
                 cases = dat[1, 'positive'],
                 negative_tests = dat[1, 'negative'],
                 pending_tests = dat[1, 'pending'],
                 tested = dat[1, 'total_tests'],
                 recovered = dat[1, 'recovered'],
                 deaths = dat[1, 'deaths'])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'arkansas')
  invisible(d)
}

#' @title      scrape la times from california
#' @description scrapes data from the LA Times from the Case by county table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_california <- function() {
  state <- NULL
  state_name <- 'California'
  parse_url <- covidR::urls[state == state_name][['url']][2]
  page <- xml2::read_html(trimws(parse_url))
  tbls <- rvest::html_table(page, header = TRUE, trim = TRUE, fill = TRUE)
  cdat <- tbls[[2]]
  page_raw <- rvest::html_text(page)
  timezone = 'America/Los_Angeles'
  scases <- gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[1]/p[1]'
  )), fixed = TRUE)
  sdeaths <- gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[2]/p[1]'
  )))
  update_date <- rvest::html_node(page,
                                  xpath = '/html/body/article/header/p[2]/time')
  update_date <- gsub(' Pacific', '', rvest::html_text(update_date),
                      ignore.case = FALSE, fixed = TRUE)
  update_date <- lubridate::as_datetime(convert_am_pm(update_date),
                                        format = '%B %d, %I:%M %p',
                                        tz = timezone)
  updated <- update_date
  num_counties <- nrow(tbls[[2]])
  counties <- cdat[,1]
  num_cases <- trimws(gsub(',', '', cdat[,2], fixed = TRUE))
  num_deaths <- trimws(cdat[,3])
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                county = counties, cases = num_cases, update_date = updated,
                deaths = num_deaths)
  d2 <- make_dat(state = state_name, counties = num_counties, cases = scases,
                 deaths = sdeaths)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'california')
  invisible(d)
}

#' @title      scrape la times from colorado
#' @description scrapes data from the LA Times from the Case by county table
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_colorado <- function() {
  state_name <- 'Colorado'
  parse_url <- 'https://www.kktv.com/content/news/BREAKING--568535251.html'
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  timezone <- 'America/Denver'
  county_url <- 'https://opendata.arcgis.com/datasets/fbae539746324ca69ff34f086286845b_0.csv?outSR=%7B%22latestWkid%22%3A3857%2C%22wkid%22%3A102100%7D'
  dat <- read.csv(county_url)
  names(dat) <- toupper(names(dat))
  page_text <- rvest::html_text(
    rvest::html_node(page, xpath = '//*[@id="articlebody"]/p[8]'))
  page_data <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="articleBody"]/p[1]/b'
  ))
  update_date <- gsub('Data through ', '',
                      unique(dat[['DATE_DATA_LAST_UPDATED']]))
  update_date <- lubridate::as_datetime(paste(update_date, '16'),
                                        format = '%B %d, %Y %H',
                                        tz = timezone)
  updated <- update_date
  d1 <- make_dat(state = state_name, url = as.character(parse_url),
                page = page_raw, cases = unique(dat[['STATE_POS_CASES']]),
                update_date = updated, deaths = unique(dat[['STATE_DEATHS']]),
                tested = unique(dat[['STATE_NUMBER_TESTED']]),
                counties = unique(dat[['STATE_NUMBER_OF_COUNTIES_POS']]),
                hospitalized = unique(dat[['STATE_NUMBER_HOSPITALIZATIONS']]))
  d2 <- make_dat(state = state_name, url = county_url,
                 page = paste0(as.character(dat), collapse = '\n'),
                 county = dat[['LABEL']], cases = dat[['COUNTY_POS_CASES']])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'colorado')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_dc <- function() {
  state <- NULL
  state_name <- 'District of Columbia'
  timezone <- 'America/New_York'
  parse_url <- 'https://coronavirus.dc.gov/release/coronavirus-data-update-march-'
  day <- lubridate::day(Sys.Date())
  if (lubridate::hour(Sys.time) >= 21) {
    parse_url <- paste0(parse_url, day)
  } else {
    parse_url <- paste0(parse_url, day - 1)
  }
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  update_date <- lubridate::as_datetime(
    paste(lubridate::month(Sys.Date()), day, '2020', '20:30', sep = ' '),
                                        format = '%m %d %Y %H:%M',
                                        tz = timezone)
  cases <- stringr::str_extract(page_raw, '(?<=case total to )\\d{1,}')
  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = cases, update_date = update_date)
  write_out(d, 'dc')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_florida <- function() {
  state <- NULL
  state_name <- 'Florida'
  timezone <- 'America/New_York'
  parse_url <- 'https://fdoh.maps.arcgis.com/apps/opsdashboard/index.html#/8d0de33f260d444c852a615dc7837c86'
  dat <- jsonlite::fromJSON(parse_url)
  page_raw <- as.character(dat)
  fdat <- dat$features$attributes
  # florida datestamp nonsensical, make our own
  update_date <- make_access_time()
  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = fdat[['T_positive']], county = fdat[['County_1']],
                tested = fdat[['T_total']],
                negative_tests = fdat[['T_negative']],
                deaths = fdat[['FLandNonFLDeaths']],
                pending_tests = fdat[['T_pending']])
  write_out(d, 'florida')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_georgia <- function() {
  state <- NULL
  state_name <- 'Georgia'
  timezone <- 'America/New_york'
  # parse_url <- covidr::urls[state == state_name][['url']]
  # parse_url <- 'https://dph.georgia.gov/covid-19-daily-status-report'
  parse_url <- 'https://d20s4vd27d0hk0.cloudfront.net/?initialWidth=569&amp;childId=covid19dashdph&amp;parentTitle=COVID-19%20Daily%20Status%20Report%20%7C%20Georgia%20Department%20of%20Public%20Health&amp;parentUrl=https%3A%2F%2Fdph.georgia.gov%2Fcovid-19-daily-status-report%22'
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  ud <- stringr::str_extract(page_raw, 'as of \\d{1,}\\/\\d{1,}\\/\\d{4} \\d{1,}:\\d{1,}:\\d{1,}')
  update_date <- lubridate::as_datetime(ud,
                                        format = 'as of %m/%d/%Y %H:%M:%S',
                                        tz = timezone)
  updated <- update_date
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 update_date = update_date,
                 cases = stringr::str_extract(tbls[[6]][2,3],
                                              '\\d{1,}(?=.*\\()'),
                 hospitalized = stringr::str_extract(tbls[[6]][3,2],
                                              '\\d{1,}(?=.*\\()'),
                 deaths = stringr::str_extract(tbls[[6]][4,2],
                                              '\\d{1,}(?=.*\\()'),
                 lab = tbls[[8]][,1], lab_positive = tbls[[8]][,2],
                 lab_tests = tbls[[8]][,3])
  cdf <- tbls[[7]][2:nrow(tbls[[7]]) - 1,]
  cdf <- cdf[-1,]
  names(cdf) <- cdf[1,]
  cdf <- cdf[-1,]
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = cdf[,2], county = cdf[,1], deaths = cdf[,3],
                update_date = updated)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'georgia')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hawaii <- function() {
  state <- NULL
  state_name <- 'Hawaii'
  timezone <- 'Pacific/Honolulu'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  cases <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[1]/dl'
  ))
  hosp <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[1]'
  ))
  death <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[2]'
  ))
  cases <- strsplit(cases, '\n', fixed = TRUE)[[1]]
  stc <- stringr::str_extract(cases[1], '(?<=Total cases: ).*(?=\\s\\()')
  sth <- stringr::str_extract(hosp, '(?<=Hospitalization: ).*(?=\\s\\()')
  std <- stringr::str_extract(death, '(?<=deaths: ).*(?=\\s\\()')
  stp <- stringr::str_extract(cases[5], '(?<=Pending: ).*(?=\\s\\()')
  ud <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[3]'
  ))
  ud <- lubridate::as_datetime(
    convert_am_pm(ud), format = 'Cumulative totals as of %I:%M%p on%B %d, %Y',
    tz = timezone)
  cc <- stringr::str_extract(cases[-c(1,6)], '^.*(?=\\sCounty:)')
  cn <- stringr::str_extract(cases[-c(1,6)], '(?<=County: ).*(?=\\s\\()')
  # update_date <- unique(names(table))
  # update_date <- convert_am_pm(stringr::str_extract(
  #   update_date, '(\\d{1,}:\\d{2}\\w{2} on \\w+ \\d{1,}, \\d{4})'))
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%i:%m%p on %b %d, %y',
  #                                       tz = timezone)
  # updated <- update_date
  # table <- table[c(-1, -2, -3),]
  # table <- table[1:nrow(table) - 1,]
  # names(table) <- c('county', 'cases')
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = stc, hospitalized = sth, deaths = std,
                update_date = ud)
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 county = cc, cases = cn, update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'hawaii')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_idaho <- function() {
  state <- county <- NULL
  state_name <- 'Idaho'
  timezone <- 'America/Denver'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 cases = tbls[[1]][18,3], deaths = tbls[[1]][18,4],
                 cases_male = tbls[[4]][1,2], cases_female = tbls[[4]][,1],
                 hospitalized = tbls[[5]][1,2],
                 state_tests = gsub(',', '', tbls[[2]][,1]),
                 private_tests = gsub(',', '', tbls[[2]][,2]),
                 age_range = tbls[[3]][,1], age_cases = tbls[[3]][,2])
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 county = tbls[[1]][,2], cases = tbls[[1]][,3],
                 deaths = tbls[[1]][,4])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'idaho')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_louisiana <- function() {
  state <- NULL
  state_name <- 'Louisiana'
  base_url <- 'http://ldh.la.gov/Coronavirus/'
  url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Deaths%20desc%2CCases%20desc%2CParish%20asc&outSR=102100&resultOffset=0&resultRecordCount=65&cacheHint=true'
  page <- jsonlite::fromJSON(url)
  tbl <- page$features$attributes
  d1 <- make_dat(state = state_name, url = url, county = tbl$Parish,
                cases = tbl$Cases, deaths = tbl$Deaths, lat = tbl$Latitude,
                lon = tbl$Longitude, fips = tbl$PFIPS)
  tests_url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  td <- jsonlite::fromJSON(tests_url)
  td <- td$features$attributes$value
  cd <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value2%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cd <- cd$features$attributes$value
  counties <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=(Cases%20%3E%200)%20AND%20(PFIPS%20%3C%3E%200)%20AND%20(PFIPS%20%3C%3E%2099999)&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22count%22%2C%22onStatisticField%22%3A%22FID%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cs <- counties$features$attributes$value
  cases <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cases <- cases$features$attributes$value
  deaths <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Deaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  deaths <- deaths$features$attributes$value
  d2 <- make_dat(state = state_name, url = base_url, tested = td + cd,
                 counties = cs, deaths = deaths, cases = cases)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'louisiana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maine <- function() {
  state <- NULL
  state_name <- 'Maine'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)

  update_date <- gsub('Updated: ', '', unique(tbls[[2]][1,1]))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %y at %I:%M %p',
                                        tz = timezone)
  state_cases <- tbls[[2]]
  county_cases <- tbls[[3]][-1:-2,]
  d1 <- make_dat(state = state_name, url = url, county = county_cases[,1],
                 cases = county_cases[,2], page = page_raw,
                 recovered = county_cases[,3], update_date = update_date)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = gsub(',', '', state_cases[3,1]),
                 negative_tests = gsub(',', '', state_cases[3,3]),
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'maine')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maryland <- function() {
  print('requries selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_massachusetts <- function() {
  state <- NULL
  state_name <- 'Massachusetts'
  print('requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_michigan <- function() {
  state_name <- 'Michigan'
  timezone <- 'America/Chicago'
  url <-
    'https://www.michigan.gov/coronavirus/0,9753,7-406-98163-520743--,00.html'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tables <- rvest::html_table(page, fill = TRUE)
  county_cases <- tables[[1]]
  names(county_cases) <- county_cases[1,]
  county_cases <- county_cases[-1,]
  update_date <- paste0(format(Sys.Date(),
                               format = '%Y-%m-%d'), ' 2:00 PM')
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%Y-%m-%d %I:%M %p',
                                        tz = timezone)
  if (length(tables) > 3) {
    state_data <- tables[[4]]
    d1 <- make_dat(state = state_name, url = url, page = page_raw,
                   county = county_cases$county, cases = county_cases$cawses,
                   update_date = update_date)
    d2 <- make_dat(state = state_name, url = url, page = page_raw,
                   hospitalized = state_data$Hospitalized,
                   cases = state_data$Number)
    d <- data.table::rbindlist(list(d1, d2), fill = TRUE)

  } else {
    d <- make_dat(state = state_name, url = url, page = page_raw,
                 county = county_cases$county, cases = county_cases$cawses,
                 update_date = update_date)
  }
  write_out(d, 'michigan')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_minnesota <- function() {
  state_name <- 'Minnesota'
  url <- 'https://www.health.state.mn.us/diseases/coronavirus/situation.html'
  timezone <- 'America/Chicago'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  update_date <- stringr::str_extract(page_raw,
                                      '(?<=As of )\\w{1,} \\d{1,}, \\d{4}')
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  print('needs selenium for county results')
  state_cases <- as.integer(gsub(',', '',
                                 stringr::str_extract(page_raw,
                                                      '(?<=Positive: )\\d{1,}'))
                            )
  tested <- as.integer(gsub(',', '',
                            stringr::str_extract(page_raw,
                                                 '(?<=Lab: )\\d{1,}')))
  d <- make_dat(state = state_name, url = url, update_date = update_date,
                cases = state_cases, tested = tested)
  write_out(d, 'minnesota')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_mississippi <- function() {
  state_name <- 'Mississippi'
  page <- get_page('https://msdh.ms.gov/msdhsite/_static/14,0,420.html')
  page_raw <- rvest::html_text(page)
  cases <- rvest::html_node(page, xpath = '//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[2]/transform/div/div[3]/visual-modern/div/svg/g[1]/text/tspan')
  print('needs selenium')
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_missouri <- function() {
  state_name <- 'Missouri'
  timezone <- 'America/Chicago'
  st_url <- covidR::urls[state == state_name][['url']]
  st_page <- get_page(st_url)
  st_page_raw <- rvest::html_text(st_page)
  st_tbls <- rvest::html_table(st_page)[[1]]
  ud <- rvest::html_text(rvest::html_node(st_page, xpath = '//*[@id="main-content"]/p[2]'))
  ud <- convert_am_pm(strsplit(ud, '\r\n\\s{1,}')[[1]][1])
  updated <- lubridate::as_datetime(ud, format = 'As of %I:%M %p CT, %B %d',
                                    tz = timezone)
  url <- 'https://health.mo.gov/living/healthcondiseases/communicable/novel-coronavirus/results.php'
  page <- get_page(url)
  county_page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)[[1]]
  d1 <- make_dat(state = state_name, url = st_url, page = st_page_raw,
                 cases = st_tbls[2,2], update_date = updated,
                 deaths = stringr::str_extract(st_tbls[1,1],
                                               '\\d{1,}'))
  d2 <- make_dat(state = state_name, url = url, page = county_page_raw,
                 county = tbls[,1], cases = tbls[,2],
                 update_date = updated)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'missouri')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_montana <- function() {
  state_name <- 'Montana'
  timezone <- 'America/Denver'
  url <- 'https://dphhs.mt.gov/publichealth/cdepi/diseases/coronavirusmt'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="dnn_ctr92389_HtmlModule_lblContent"]/div[2]'))
  tbl <- gsub('\n{1,}', ' ', tbl)
  state_cases <- as.integer(stringr::str_extract(
    tbl, '(?<=in Montana )(\\d{1,}|\\d{1,},\\d{3})'))
  tested <- as.integer(stringr::str_extract(
    tbl, '(?<=by MTPHL\\*\\* )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  negative <- as.integer(stringr::str_extract(
    tbl, '(?<=negative results )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  update_date <- convert_am_pm(stringr::str_extract(page_raw,
                                                    '(?<=Last updated: ).*'))
  update_date <- gsub('a.m.', 'AM', update_date)
  update_date <- gsub('p.m.', 'PM', update_date)
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%m/%d/%Y at %I:%M %p',
                                        tz = timezone)

  d <- make_dat(state = state_name, url = url, update_date = update_date,
                cases = state_cases, tested = tested, negative_tests = negative)
  write_out(d, 'montana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nebraska <- function() {
  state_name <- 'Nebraska'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name,][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  cases <- as.integer(stringr::str_extract(
    page_raw, '(?<=cases – )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  negative <- as.integer(stringr::str_extract(
    page_raw, '(?<= negative - )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  update_date <- stringr::str_extract(
    page_raw, '(?<=Updated: )\\w{1,} \\d{1,}, \\d{4}'
  )
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases, negative_tests = negative,
                update_date = update_date)
  write_out(d, 'nebraska')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nevada <- function() {
  state_name <- 'Nevada'
  timezone <- 'America/Los_Angeles'
  url <- 'http://dpbh.nv.gov/coronavirus/'
  url <- 'https://app.powerbigov.us/view?r=eyJrIjoiMjA2ZThiOWUtM2FlNS00MGY5LWFmYjUtNmQwNTQ3Nzg5N2I2IiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  # tbl <- rvest::html_table(page)[[1]]
  # update_date <- lubridate::as_datetime(
  #   gsub('last updated ', '', tbl[2,1]), format = '%m/%d/%y, %i:%m %p',
  #   tz = timezone)
  # make_dat(state = state_name, url = url, page = page_raw,
  #          update_date = update_date, cases = tbl[3, 2],
  #          presumptive_positive = tbl[4, 2], negative_tests = tbl[5, 2],
  #          monitored = tbl[9,2])
  print('Nevada needs selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_hampshire <- function() {
  print('County data is in a picture')
  state <- NULL
  state_name <- 'New Hampshire'
  timezone <- 'America/New_York'
  url <- 'https://nh.gov/covid19/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_table(page)[[1]]
  update_date <- gsub('updated', '', stringr::str_extract(rvest::html_text(
    rvest::html_node(
      page, xpath = '//*[@id="bodycontainer"]/main/div[3]/section[1]/h4')),
    '\\(([^\\)]+)\\)'
    ))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '( %B %d, %Y, %I:%M %p',
                                        tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = tbl[1,2], pending_tests = tbl[2,2], tested = tbl[3,2],
                monitored = tbl[4,2], update_date = update_date)
  write_out(d, 'new_hampshire')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @importFrom magrittr %>%
#' @export
scrape_new_jersey <- function() {
  state <- NULL
  state_name <- 'New Jersey'
  timezone <- 'America/New_York'
  url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Counties/FeatureServer/0/query?f=json&returnGeometry=true&spatialRel=esriSpatialRelIntersects&geometry=%7B%22xmin%22%3A-8766409.899972958%2C%22ymin%22%3A5009377.085700976%2C%22xmax%22%3A-8140237.764260961%2C%22ymax%22%3A5635549.2214129735%2C%22spatialReference%22%3A%7B%22wkid%22%3A102100%7D%7D&geometryType=esriGeometryEnvelope&inSR=102100&outFields=*&outSR=102100&resultType=tile'
  page <- jsonlite::fromJSON(url)
  page_raw <- jsonlite::toJSON(page)
  tbl <- data.table::as.data.table(page$features$attributes)
  tbl[, county := snakecase::to_title_case(COUNTY)]
  url2 <- 'https://maps.arcgis.com/sharing/rest/content/items/84737ef7f760486293b6afa536f028e0?f=json'
  call_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/survey123_4b4d331a233d419abbcc52ab45158b56/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22max%22%2C%22onStatisticField%22%3A%22total_calls_%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  page <- jsonlite::fromJSON(url2)
  county_data_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&resultOffset=0&resultRecordCount=25&cacheHint=true'
  cd <- jsonlite::fromJSON(county_data_url)
  ud <- lubridate::as_datetime(page$modified, tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                county = snakecase::to_title_case(cd$features$attributes$COUNTY),
                cases = cd$features$attributes$TOTAL_CASES, update_date = ud)
  warning('New Jersey needs selenium for state data and deaths')
  write_out(d, 'new_jersey')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_mexico <- function() {
  state <- NULL
  state_name <- 'New Mexico'
  timezone <- 'America/Denver'
  url <- 'https://nmhealth.org/news/alert/2020/3/?view=856'
  print('url contains a date element, may need to evaluate after march')
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  st_total <- stringr::str_extract(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content"]/p[3]')),
    '(?<=total of )\\d{1,}')
  ud <- strsplit(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content"]/div[2]/em')), ' - ', fixed = TRUE)[[1]][1]
  ud <- lubridate::as_datetime(paste(ud, '12:00'), format = '%B %d, %Y %H:%M',
                               tz = timezone)
  cc <- rvest::html_text(rvest::html_node(page,
                                          xpath = '//*[@id="content"]/ul[2]'))
  cc <- strsplit(cc, '\r\n', fixed = TRUE)[[1]]
  counties <- c()
  cases <- c()
  for (c in cc) {
    cs <- strsplit(c, ': ', fixed = TRUE)[[1]]
    counties <- append(counties, gsub(' County', '', cs[1]))
    cases <- append(cases, cs[2])
  }
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = st_total, update_date = ud)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = counties, cases = cases, update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_mexico')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_york <- function() {
  state_name <- 'New York'
  timezone <- 'America/New_York'
  url <- 'https://coronavirus.health.ny.gov/county-county-breakdown-positive-cases'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  c_tbl <- tbls[[1]][-nrow(tbls[[1]]),]
  s_tbl <- tbls[[1]][nrow(tbls[[1]]),]
  ud <- rvest::html_text(rvest::html_node(page,
                                          xpath = '/html/body/div[3]/div/main/div/div/div[2]/div/div/div/div/div[1]'))
  ud <- lubridate::as_datetime(ud, format = 'Last Update: %B %d, %Y | %I:%M%p',
                               tz = timezone)
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = gsub(',', '', s_tbl[,2]))
  d2 <- make_dat(state = state_name, page = page_raw, url = url,
                 cases = gsub(',', '', c_tbl[,2]), county = c_tbl[,1])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_york')
  return(d)
}



#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_north_carolina <- function() {
  state_name <- 'North Carolina'
  url <- ' https://www.ncdhhs.gov/covid-19-case-count-nc'
  timezone <- 'America/New_York'
  print('County data will need selenium')
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_table(page)[[1]]
  cases <- tbl[2,1]
  deaths <- tbl[2,2]
  tested <- tbl[2,3]
  update_date <- convert_am_pm(stringr::str_extract(page_raw,
                                                    '(?<=Last updated ).*\\.'))
  update_date <- gsub('a\\.m\\.', 'AM', update_date)
  update_date <- gsub('p\\.m\\.', 'PM', update_date)
  udpate_date <- lubridate::as_datetime(update_date,
                                        format = '%I:%M%p, %B %d, %Y.',
                                        tz = timezone)
  d <- make_dat(state = state_name, cases = cases, deaths = deaths, url = url,
                page = page_raw, update_date = update_date)
  write_out(d, 'north_carolina')
  warning('North Carolina county data requries selenium')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_north_dakota <- function() {
  state_name <- 'North Dakota'
  print('ND has data in images, will need selenium and OCR to scrape')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_ohio <- function() {
  state_name <- 'Ohio'
  url <- covidR::urls[state == state_name][['url']]
  timezone <- 'America/New_York'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  state_cases_html <- rvest::html_text(
    rvest::html_node(page, xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[1]')
  )
  state_cases_str <- gsub('\\s', '', state_cases_html, perl = TRUE)
  state_cases <- stringr::str_extract(state_cases_str, '\\d{1,}(?=Confirmed)')
  counties <- stringr::str_extract(state_cases_str,
                                   '\\d{1,}(?=NumberofCounties)')
  hospitalized <- stringr::str_extract(state_cases_str,
                                       '\\d{1,}(?=NumberofHospit)')
  deaths <- stringr::str_extract(state_cases_str,
                                 '\\d{1,}(?=NumberofDeaths)')
  update_date <- rvest::html_text(
    rvest::html_node(
      page,
      xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[3]/span[2]'))
  update_date <- lubridate::as_datetime(
    paste(update_date, '14'),
    format = '%m/%d/%Y %H',
    tz = timezone)
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = state_cases, counties = counties,
                 hospitalized = hospitalized, deaths = deaths,
                 update_date = update_date)

  tbl <- rvest::html_text(
    rvest::html_node(page,
                     xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[3]/div/div/div/div[1]/div/p'))
  counties <- stringr::str_extract_all(tbl, '\\w{1,} \\(\\d{1,}\\)')[[1]]
  county_cases <- lapply(counties, extract_county_number)
  cases <- c()
  counties <- c()
  for (case in county_cases) {
    counties <- append(counties, case[1])
    cases <- append(cases, case[2])
  }
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = cases, county = counties, update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'ohio')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oklahoma <- function() {
  state_name <- 'Oklahoma'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  update_date <- rvest::html_text(
    rvest::html_node(
      page,
      xpath = '/html/body/div[2]/main/div/div/div[5]/div[1]/div/div[5]/div/p[2]/em'
      ))
  update_date <- stringr::str_extract(
    update_date,
    '\\d{4}-\\d{1,}-\\d{1,} at \\d{1,}:\\d{1,}\\s\\w{1,}')
  update_date <- gsub(' at', '', update_date, fixed = TRUE)
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%Y-%m-%d %I:%M %p',
                                        tz = timezone)
  tbls <- rvest::html_table(page)
  state_tbl <- tbls[[1]]
  county_tbl <- tbls[[5]]
  state_cases <- state_tbl[1,2] + state_tbl[2,2]
  state_negative <- state_tbl[3,2]
  state_pending <- state_tbl[4,2]
  state_hospitalized <- state_tbl[5,2]
  state_deaths <- state_tbl[6,2]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = state_cases, negative_tests = state_negative,
                 pending_tests = state_pending, update_date = update_date,
                 hospitalized = state_hospitalized, deaths = state_deaths,
                 state_tests = tbls[[2]][1,2],
                 private_tests = tbls[[2]][2,2] + tbls[[2]][3,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = county_tbl[,2], county = county_tbl[,1],
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'oklahoma')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oregon <- function() {
  state_name <- 'Oregon'
  timezone <- 'America/Los_Angeles'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- unique(names(tbls[[1]]))
  update_date <- stringr::str_extract(
    update_date, '\\d{1,}/\\d{1,}/\\d{1,}, \\d{1,}:\\d{1,} \\w\\.\\w.')
  update_date <- gsub('a.m.', 'AM', update_date)
  update_date <- gsub('p.m.', 'PM', update_date)
  update_date <- lubridate::as_datetime(
    update_date, format = '%m/%d/%Y, %I:%M %p', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], update_date = update_date,
                 hospitalized = tbls[[4]][1,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[2]][,1], cases = tbls[[2]][,2],
                 deaths = tbls[[2]][,3], negative_tests = tbls[[2]][,4],
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'oregon')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_pennsylvania <- function() {
  state_name <- 'Pennsylvania'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  url <- 'https://www.health.pa.gov/topics/disease/coronavirus/Pages/Cases.aspx'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="ctl00_PlaceHolderMain_PageContent__ControlWrapper_RichHtmlField"]/p/span'
  ))
 ud <- stringr::str_extract(update_date,
                                     '(?<=counts last updated at ).*$')
 update_date <- convert_am_pm(ud)
 update_date <- lubridate::as_datetime(update_date,
                                       format = '%I:%m %p on %m/%d/%Y',
                                       tz = timezone)
 d1 <- make_dat(state = state_name, update_date = update_date,
                cases = tbls[[1]][2,2], negative_tests = tbls[[1]][2,1],
                deaths = tbls[[1]][2,3],
                age_range = gsub('<U+200B>', '',
                                 tbls[[2]][2:nrow(tbls[[2]]), 1], fixed = TRUE),
                age_percent = gsub('<U+200B>', '',
                                 tbls[[2]][2:nrow(tbls[[2]]), 2], fixed = TRUE),
               url = url, page = page_raw)
 d2 <- make_dat(state = state_name, update_date = update_date, page = page_raw,
                county = tbls[[4]][,1], cases = tbls[[4]][,2],
                deaths = tbls[[4]][,3])
 d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
 write_out(d, 'pennsylvania')
 d
}

#' @title       scrape Puerto Rico
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_puerto_rico <- function() {
  state_name <- 'Puerto Rico'
  timezone <- 'Atlantic/Bermuda'
  url <- 'http://www.salud.gov.pr/Pages/coronavirus.aspx'
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # tbls <- rvest::html_table(page, fill = TRUE)
  # tbl <- tbls[[1]]
  # update_date <- rvest::html_text(
  #   rvest::html_node(
  #     page, xpath = '//*[@id="WebPartWPQ6"]/div[1]/h3[2]'))
  # update_date <- gsub(')', '', gsub('de', '', gsub('\\s{1,}', '',
  #                                    gsub('(Datos al', '', update_date,
  #                                                         fixed = TRUE))))
  # update_date <- convert_month_language(update_date)
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%d%B%Y,%H:%M',
  #                                       tz = timezone)
  # d <- make_dat(state = state_name, url = url, page = page_raw,
  #               tested = tbl[3,2], cases = tbl[3,3],
  #               negative_tests = tbl[3,4], update_date = update_date,
  #               pending_tests = tbl[3,4])
  # write_out(d, 'puerto_rico')
  # invisible(d)
  warning('Puerto Rico requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_rhode_island <- function() {
  state_name <- 'Rhode Island'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  # url_spreadsheet <- 'https://docs.google.com/spreadsheet/tq?key=1n-zMS9Al94CPj_Tc3K7Adin-tN9x1RSjjx2UzJ4SV7Q&headers=0&range=A2%3AB5&gid=0&tqx=reqId%3A1'
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # js <- gsub('/*O_o*/\ngoogle.visualization.Query.setResponse(', '', page_raw,
  #            fixed = TRUE)
  # js <- gsub(');', '', js, fixed = TRUE)
  # tbl <- unlist(jsonlite::fromJSON(js)$table$rows$c)
  # d1 <- make_dat(state = state_name, url = url, page = page_raw,
  #               cases = tbl[[2]], negative_tests = tbl[[8]],
  #               pending_tests = tbl[[10]], quarantined = tbl[[14]])
  # write_out(d, 'rhode_island')
  # invisible(d)
  warning('Rhode Island needs selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_carolina <- function() {
  state_name <- 'South Carolina'
  url <- 'https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/monitoring-testing-covid-19'
  page <- get_page(url)
  raw_page <- rvest::html_text(page)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/article/div/div/section[1]/div/p[1]/span'))
  update_date <- convert_am_pm(gsub('\\s{1,}', '', update_date))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%A,%B%d,%I:%M%p')
  print('South Carolina needs selenium to get county cases')
  county_url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/Covid19_Cases_Centroid_SharingView/FeatureServer/0/query?f=json&where=Confirmed%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Confirmed%20desc&resultOffset=0&resultRecordCount=1000&cacheHint=true'
  page <- jsonlite::fromJSON(county_url)
  cdat <- page$features$attributes
  # tbls <- rvest::html_table(page)
  # cdat <- jsonlite::fromJSON(county_url)$features$attributes
  # d1 <- make_dat(state = state_name, url = url, page = raw_page,
  #               update_date = update_date, negative_tests = tbl[1,2],
  #               cases = tbl[2,2])
  d <- make_dat(state = state_name, url = url, page = raw_page, county = cdat$NAME,
                cases = cdat$Confirmed, recovered = cdat$Recovered,
                deaths = cdat$Death, lat = cdat$Lat, lon = cdat$Long_,
                active = cdat$Active, update_date = update_date)
  write_out(d, 'south_carolina')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_dakota <- function() {
  state_name <- 'South Dakota'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content_block"]/p[5]/text()[2]'))
  ud <- convert_am_pm(gsub('\\s', '', update_date, perl = TRUE))
  ud <- gsub('Lastupdated:', '', ud, fixed = TRUE)
  update_date <- lubridate::as_datetime(
    ud, format = '%I:%M%p;%B%d,%Y', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], deaths = tbls[[2]][2,2],
                 update_date = update_date, resolution = 'state',
                 recovered = tbls[[2]][3,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[3]][-8, ][,2], county = tbls[[3]][-8,][,1],
                 resolution = 'county', update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'south_dakota')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_tennessee <- function() {
  state_name <- 'Tennessee'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  ud <- lubridate::as_datetime(paste(Sys.Date(), '14:00'),
                               format = '%Y-%m-%d %H:%M', tz = timezone)
  st_tsts <- sum(as.integer(gsub(',','',tbls[[1]][1:2,2])))
  st_neg <- sum(as.integer(gsub(',', '', tbls[[1]][1:2,3])))
  st_css <- sum(as.integer(gsub(',', '', tbls[[1]][3,3])))
  d1 <- make_dat(state = state_name, tested = tbls[[1]][1,2],
                 cases = st_tsts, deaths = tbls[[2]][2,2],
                 update_date = ud, url = url, page = page_raw)
  d2 <- make_dat(state = state_name, page = page_raw,
                 county = gsub(' County', '', tbls[[5]][,1]),
                 cases = tbls[[5]][,2], update_date = ud,
                 url = url)
  out <- data.table::data.table(county = tbls[[4]][,1],
                                cases = tbls[[2]][, 2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'tennessee')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_texas <- function() {
  state_name <- "Texas"
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- trimws(stringr::str_extract(page_raw, '(?<=Last updated ).*'))
  update_date <- lubridate::as_datetime(
    paste0(update_date, ' 12:00:00'), format = '%B %d, %Y %H:%M:%S',
    tz = timezone)
  county_url <- 'https://services5.arcgis.com/ACaLB9ifngzawspq/arcgis/rest/services/COVID19County_ViewLayer/FeatureServer/0/query?f=json&where=Count_%3C%3E0&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Count_%20desc&resultOffset=0&resultRecordCount=254&cacheHint=true'
  countyies <- jsonlite::fromJSON(county_url)
  # st_tsts <- sum(as.integer(gsub(',','',tbls[[1]][1:2,2])))
  st_cases <- tbls[[2]][nrow(tbls[[2]]),2]
  c_dat <- countyies$features$attributes
  # d1 <- make_dat(state = state_name, tested = tbls[[1]][1,2],
  #                cases = st_tsts, deaths = tbls[[2]][2,2],
  #                update_date = update_date, url = url)
  # d2 <- make_dat(state = state_name,
  #                county = gsub(' County', '', tbls[[4]][,1]),
  #                cases = tbls[[4]][,2], update_date = update_date,
  #                url = url)
  # d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                update_date = update_date, cases = st_cases)
  d2 <- make_dat(state = state_name, update_date = update_date,
                 page = countyies, deaths = c_dat$Deaths, url = url,
                 cases = c_dat$Count_, county = c_dat$Count_)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'texas')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_utah <- function() {
  state_name <- 'Utah'
  timezone <- 'America/Denver'
  url <- 'https://coronavirus.utah.gov/case-counts/'
  url <- 'https://coronavirus-dashboard.utah.gov/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  print('No Data available without Selenium for Utah')

}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_vermont <- function() {
  state_name <- 'Vermont'
  timezone <- 'America/New_York'
  url <- 'https://www.healthvermont.gov/response/infectious-disease/2019-novel-coronavirus'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_table(page)[[1]]
  ud <- stringr::str_extract(page_raw, '(?<=Last updated: ).*')
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = tbl[1,2], tested = tbl[2,2], deaths = tbl[3,2],
                monitored = tbl[4,2], no_longer_monitored = tbl[5,2],
                update_date = ud)
  write_out(d, 'vermont')
  warning('vermont county data needs Selenium and picture recognition')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_virginia <- function() {
  state_name <- 'Virgina'
  print('Virginia scraping requires selenium')
}
#' @title      scrape washington
#' @description scrapes urls for washington
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_washington <- function() {
  state_name <- 'Washington'
  timezone <- 'America/Los_Angeles'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus/010101010100e803ab2663a90d0000210068747470733a2f2f72652e73656375726974792e66356161732e636f6d2f72652f'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  neg <- as.integer(gsub(',', '', tbls[[2]][1,2]))
  pos <- as.integer(gsub(',', '', tbls[[2]][2,2]))
  t_tests <- neg + pos
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[1]][1:nrow(tbls[[1]]) - 1,1],
                 cases = tbls[[1]][1:nrow(tbls[[1]]) - 1,2],
                 deaths = tbls[[1]][1:nrow(tbls[[1]]) - 1,3])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = pos, negative_tests = neg,
                 tested = t_tests)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'washington')
  invisible(d)
}
#' @title       scrape west virginia
#' @description scrapes urls for west virginia
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_west_virginia <- function() {
  state_name <- 'West Virgina'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  state_dat <- tbls[[4]][1,1]
  county_dat <- tbls[[4]][4,2]
  ud <- paste0(stringr::str_extract(
    state_dat, '(?<=Updated: )\\d{1,}/\\d{1,}/\\d{4}'), '12:00')
  ud <- lubridate::as_datetime(ud, format = '%m/%d/%Y %H:%M',
                               tz = timezone)
  state_dat <- gsub('\r\n', '', state_dat)
  st_cases <- stringr::str_extract(state_dat, '(?<=Positive Cases)\\d{1,}')
  st_negs <- stringr::str_extract(state_dat, '(?<=Negative Cases)\\d{1,}')
  st_deaths <- stringr::str_extract(state_dat, '(?<=Deaths)\\d{1,}')
  st_pending <- stringr::str_extract(state_dat, '(?<=Pending)\\d{1,}')
  d1 <- make_dat(state = state_name, cases = st_cases, negative_tests = st_negs,
                 deaths = st_deaths, pending_tests = st_pending, url = url,
                 page = page_raw)
  county_dat <- extract_county_number_to_df(strsplit(
    gsub('Counties with positive cases: ', '', tbls[[7]][[1]]), ',')[[1]])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = county_dat[,1],
                 cases = county_dat[,2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'west_virginia')
  invisible(d)
}
#' @title       scrape wisconsin
#' @description scrapes url for wisconsin
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wisconsin <- function() {
  state_name <- 'Wisconsin'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  county_url <- 'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=true&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=POSITIVE%20DESC&outSR=102100&resultOffset=0&resultRecordCount=1000'
  cj <- jsonlite::fromJSON(county_url)$features$attributes
  ud <- lubridate::as_datetime(paste(unique(cj$DATE), '14:00'),
                               format = '%m/%d/%Y %H:%M', tz = timezone)
  sj <- jsonlite::fromJSON(
    'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/2/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&resultType=none&distance=0.0&units=esriSRUnit_Meter&returnGeodetic=false&outFields=NEGATIVE%2CPOSITIVE%2CDEATHS%2CDATE&returnHiddenFields=false&returnGeometry=true&featureEncoding=esriDefault&multipatchOption=xyFootprint&maxAllowableOffset=&geometryPrecision=&outSR=&datumTransformation=&applyVCSProjection=false&returnIdsOnly=false&returnUniqueIdsOnly=false&returnCountOnly=false&returnExtentOnly=false&returnQueryGeometry=false&returnDistinctValues=false&cacheHint=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&having=&resultOffset=&resultRecordCount=&returnZ=false&returnM=false&returnExceededLimitFeatures=true&quantizationParameters=&sqlFormat=none&f=pjson&token=9khYV8ELTHK1P3ES04DSnCtAqj8bQtfI69A91SPr4vedIc8kWlNLppwF3IMBZvPKoyIQMpeQT7Az_YtQdKUQLpW6OC2W1w8BWm66NGn19cQFjAMh7eSZDLnhuRVkSqzYrFeDUtBPtLjPWvSMymC55d5GVLzh-nZq8fA8E-WYtxPwLZHiA8OZP2s6x17GkZ6au5yhBy-9eOkE8AXjFmqDt0ds-HGDWKZvt03XfnUxnpQ.'
    )$features$attributes
  page_raw <- rvest::html_text(page)
  cnty_raw <- as.character(cj)
  tbls <- rvest::html_table(page, fill = TRUE)[[1]]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = sj[,2], deaths = sj[,3], update_date = ud,
                 negative_tests = sj[,1])
  d2 <- make_dat(state = state_name, url = county_url, page = cnty_raw,
                 cases = cj$POSITIVE, deaths = cj$DEATHS, county = cj$NAME,
                 update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'wisconsin')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wyoming <- function() {
  state_name <- 'Wyoming'
  timezone <- 'America/Denver'
  # url <- covidR::urls[state == state_name][['url']]
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # tbls <- rvest::html_table(page)
  # tn <- rvest::html_text(rvest::html_node(
  #   page, xpath = '//*[@id="et-boc"]/div/div/div/div[3]/div[1]/div/div/p[1]'))
  # ud <- stringr::str_extract(tn, '^\\d{1,}\\/%d{1}\\/%d{1,}')
  # updated <- lubridate::as_datetime(ud, format = '%m/%d/%y (%H %p',
  #                                   tz = timezone)
  # pd <- stringr::str_extract(tn,
  #                            '(?<=Wyoming Public Health Laboratory: )\\d{1,}')
  # cdctest <- stringr::str_extract(
  #   tn, '(?<=CDC lab: )\\d{1,}')
  # ctest <- stringr::str_extract(tn, '(?<=commercial labs: )\\d{1,}')
  # total_test <- as.integer(pd) + as.integer(cdctest) + as.integer(ctest)
  # pos <- rvest::html_text(rvest::html_node(
  #   page, xpath = '//*[@id="et-boc"]/div/div/div/div[3]/div[1]/div/div/p[2]/strong'
  # ))
  # ud <- stringr::str_extract(tn, '^\\d{1,}\\/\\d{1,}\\/\\d{1,}')
  # ud <- lubridate::as_datetime(paste(ud, '15'), format = '%m/%d/%y%H',
  #                              tz = timezone)
  # st_pos <- stringr::str_extract(pos, '\\d{1,}')
  # cc <- rvest::html_text(rvest::html_node(
  #   page, xpath = '//*[@id="et-boc"]/div/div/div/div[3]/div[2]/div/div/p'
  # ))
  # wyoming_counties <- c('Albany', 'Big Horn', 'Campbell', 'Converse',
  #                       'Crook', 'Fremont', 'Goshen', 'Hot Springs',
  #                       'Johnnson', 'Laramie', 'Natrona', 'Niobrara',
  #                       'Park', 'Platte', 'Sheridan', 'Sublette',
  #                       'Sweetwater', 'Tenton', 'Uinta', 'Washakie',
  #                       'Weston')
  # cregx <- paste0('(', paste0(wyoming_counties, collapse = '|'),
  #                 '): \\d{1,}')
  # county_cases <- stringr::str_extract_all(cc, cregx)[[1]]
  # ccc <- strsplit(county_cases, ':', fixed = TRUE)
  # counties <- c()
  # cases <- c()
  # for (p in ccc) {
  #   counties <- append(counties, p[1])
  #   cases <- append(cases, trimws(p[2], 'l'))
  # }
  # updated <- trimws(trimws(
  #   rvest::html_text(rvest::html_node(
  #     page,
  #     xpath = '//*[@id="main"]/article/div/div/section[1]/div/p[1]/span/em'))
  #   ))
  url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/COVID19_County_Polygon_SharingView2/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Confirmed%20desc&resultOffset=0&resultRecordCount=1000&cacheHint=true'
  ud <- lubridate::as_datetime(trimws(updated), format = '%A, %B %d, %I:%M %p ',
                           tz = timezone)
  c_rw <- jsonlite::fromJSON(url)
  cdat <- c_rw$features$attributes
  death_url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/COVID19_County_Polygon_SharingView2/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Death%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  death_dat <- jsonlite::fromJSON(death_url)
  deaths <- death_dat$features$attributes$value
  case_url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/COVID19_County_Polygon_SharingView2/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Confirmed%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  case_dat <- jsonlite::fromJSON(case_url)
  cases <- case_dat$features$attributes$value
  # d1 <- make_dat(state = state_name, url = url, page = page_raw,
  #                tested = total_test, cases = st_pos, update_date = updated)
  d2 <- make_dat(state = state_name,
                 url = convert_urls_to_str(case_url, death_url),
                 page = convert_json_to_str(c_rw, death_dat, case_dat),
                              cases = cases, deaths = deaths)
  d1 <- make_dat(state = state_name, url = url,
                 page = convert_json_to_str(c_rw),
                 update_date = ud, county = cdat$NAME, cases = cdat$Confirmed,
                deaths = cdat$Death, )
  # d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'wyoming')
  invisible(d)
}

#' @title       scrape the hopkins data
#' @description scrapes the timeseries data from john hopkins's github
#' @return      a data.table ready for export
#' @export
scrape_hopkins_timeseries <- function() {
  url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv'
  dat <- as.data.table(read.csv(url))
  write_out(dat, 'hopkins_timeseries')
  invisible(dat)
}

#' @title       scrape hopkins daily reports once
#' @description scrape all hopkins reports
#' @return      a data.table ready for export
#' @export
scrape_hopkins_daily_once <- function() {
  date_trips <- c()
  urls <- c()
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  cur_month <- lubridate::month(Sys.Date())
  months <- as.character(seq(1, cur_month))
  for (month in months) {
    days <- lubridate::days_in_month(lubridate::month(as.integer(month)))[[1]]
    if (nchar(month) == 1) {
      char_month <- paste0('0', month)
      months[months == month] <- char_month
    } else {
      char_month <- month
    }
    for (day in seq(1, days)) {
      day <- as.character(day)
      if (nchar(day) == 1) {
        day <- paste0('0', day)
      }
      csv_date <- paste0(paste(char_month, day, '2020', sep = '-'), '.csv')
      date_trips <- c(date_trips, csv_date)
      urls <- c(urls, paste0(base_url, csv_date))
    }
  }
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  names(dat) <- c('state', 'country_region', 'updated', 'cases', 'deaths',
                  'recovered', 'state', 'lat', 'lon', 'fips', 'admin2',
                  'provice_state', 'country', 'last_updated', 'latitude',
                  'longitude', 'active', 'combined_keys', 'fips')
  write_out(dat, 'hopkins_daily_once')
  invisible(dat)
}


#' @title       scrape the hopkins daily data
#' @description scrapes the current date for daily data
#' @return       a data.table ready for export
#' @export
scrape_hopkins_daily <- function() {
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  target <- paste0(format(Sys.Date(), format = '%m_%d_%Y'), '.csv')
  url <- paste0(base_url, target)
  dat <- as.data.table(read.csv(url))
  write_out(dat, 'hopkins_daily')
  invisible(dat)
}

#' @title       scrapes the tomquisel covid19 data once
#' @description the one off to grab all raw data from tomquisel data set
#' @return      a data.table ready for export
#' @export
scrape_tomquisel_once <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  start_date <- as.Date('2020-03-14')
  cur_date <- Sys.Date()
  valid_dates <- seq(start_date, cur_date, by = 'days')
  urls <- paste0(base_url, valid_dates, '.csv')
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  write_out(dat, 'tomquisel_once')
  invisible(dat)
}

#' @title       scrapes the tomquisel data for today's data
#' @description gets the csv from the github repo daily
#' @return       a data.table ready for export
#' @export
scrape_tomquisel <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  cur_date <- Sys.Date()
  url <- paste0(base_url, cur_date, '.csv')
  dat <- data.table::as.data.table(read.csv(url))
  write_out(dat, 'tomquisel')
  invisible(dat)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hattiesburg <- function() {
  update_time <- NULL
  url <- 'https://data.hattiesburgamerican.com/media/jsons/smpj/covid19_r2.json?v='
  page <- jsonlite::fromJSON(url)
  page_raw <- jsonlite::toJSON(page)
  raw <- data.table::as.data.table(page$features$properties)
  geo <- data.table::as.data.table(
    page$features$geometry[,-length(names(page$features$geometry))])
  coords <- page$features$geometry$coordinates
  dat <- data.table::as.data.table(cbind(raw, unlist_coordinates(coords)))
  names(dat) <- c('country', 'cases', 'deaths', 'recovered', 'active', 'unkown',
                  'update_time', 'something', 'lat', 'lon')
  # ud <- unique(dat[['update_time']])
  # dummy_date <- as.integer(0)
  # class(dummy_date) <- c('POSIXlt', 'POSIXt')
  # dat[, update_date := ]
  # for (d in ud) {
  #   subdat <- dat[update_time == d,]
  #   repeats <- nrow(subdat)
  #   print(subdat)
  #   print(repeats)
  #   nrow(subdat)
  #   dat[udpate_time == d,
  #       update_date := rep(lubridate::as_datatime(update_time,
  #                                            format = '%B %d',
  #                                            tz = 'utc'), repeats)]
  # }
  d <- dat[, date := lubridate::as_datetime(update_time,
                                            format = '%B %d',
                                            tz = 'UTC'),
           by = c('update_time')]
  write_out(d, 'hattiesburg')
  invisible(d)
}


#' @title       scrape NYT counties
#' @export
scrape_nyt_counties <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties.csv'
  d <- read.csv(url)
  write_out(d, 'nyt_counties')
  invisible(d)
}

#' @title       scrape NYT states
#' @export
scrape_nyt_states <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv'
  d <- read.csv(url)
  write_out(d, 'nyt_states')
  invisible(d)
}
