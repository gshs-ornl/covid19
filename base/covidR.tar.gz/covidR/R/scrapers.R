#' @title       Scrape the Alabama Website
#' @description Scrape the Alabama public health website for information about
#'               coronavirus
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR to do with url
scrape_alabama <- function() {
  state <- NULL
  state_name <- 'Alabama'
  timezone <- 'America/Chicago'
  # parsed_url <- covidR::urls[state == state_name][['url']]
  parse_url <- 'https://www.alabamapublichealth.gov/infectiousdiseases/2019-coronavirus.html'
  page <- get_page(parse_url)
  state_info <- rvest::html_text(rvest::html_node(page,
                                                  xpath = '//*[@id="navbar-example"]/p'))
  #state_url <- 'https://www.wvtm13.com/article/coronavirus-map-alabama/31919956#'
  # state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233180907/'
  state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233181585/'
  # state_url <- paste('https://e.infogram.com/api/live/data/368965865/', ceiling(R.utils::currentTimeMillis.System())-18000, sep="")
    # county_url <- 'https://e.infogram.com/api/live/data/368965865/1584753987108/'
  county_url <- 'https://e.infogram.com/api/live/data/368965865/1585233181585/'
  st_death_url <- 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=CONFIRMED%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22DIED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  st_deaths <- jsonlite::fromJSON(st_death_url)$features$attributes$value
  st_pos_url <- 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=CONFIRMED%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22CONFIRMED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  st_pos <- jsonlite::fromJSON(st_pos_url)$features$attributes$value
  c_page <- jsonlite::fromJSON(county_url)
  s_page <- jsonlite::fromJSON(state_url)
  county <- as.matrix(jsonlite::fromJSON(county_url)$data)
  state <- as.matrix(jsonlite::fromJSON(state_url)$data)
  counties <- county[1:67]
  c_cases <- county[70:135]
  ud <- lubridate::as_datetime(c_page$updated, tz = timezone)
  d2 <- unique(make_dat(state = state_name, url = state_url,
                 tested = gsub(',', '', state[2]),
                 deaths = st_deaths, page = s_page,
                 cases = st_pos))
  d1 <- make_dat(state = state_name, url = county_url, page = c_page,
                county = counties, cases = c_cases)
  # d <- rbindlist(list(d1, d2), fill = TRUE)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'alabama')
  invisible(d)
}

#' @title        Scrape the Alaskan URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR TO DO WITH 'make_dat', something about state_tests not being present. But data is correctly collected
scrape_alaska <- function() {
  state_name <- 'Alaska'
  timezone <- 'America/Anchorage'
  # urls <- covidR::urls[state == state_name][['url']]
  url <- 'http://dhss.alaska.gov/dph/Epi/id/Pages/COVID-19/monitoring.aspx'
  page <- xml2::read_html(trimws(url))
  page_raw <- rvest::html_text(page)
  sd <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="ctl00_PlaceHolderMain_PageContent__ControlWrapper_RichHtmlField"]/div[2]/div[1]'
  ))
  sds <- strsplit(sd, '\r\n\r\n', fixed = TRUE)[[1]]
  s_death <- stringr::str_extract(sds[2], '(?<=\\s{2}).*')
  s_hosp <- stringr::str_extract(sds[1], '(?<=\\s{2}).*')
  ud <- stringr::str_extract(page_raw, '(?<=Updated )\\w{1,} \\d{1,}, \\d{4,}')
  ud <- lubridate::as_date(paste(ud, '17'), tz = timezone,
                           format = '%B %d, %Y %H')
  tbls <- rvest::html_table(page, header = FALSE, fill = TRUE)
  cdat <- tbls[[1]][-1,]
  cdat <- cdat[-nrow(cdat),]
  sdat <- tbls[[1]][nrow(tbls[[1]]),]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = trimws(sdat[,6]), pending_tests = trimws(sdat[,5]),
                 update_date = ud, deaths = s_death, hospitalized = s_hosp)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = trimws(cdat[,6]),
                county = trimws(cdat[,1]),
                pending_tests = trimws(cdat[,5]),
                update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'alaska')
  invisible(d)
}

#' @title        Scrape the Arizona URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arizona <- function() {
  state <- NULL
  state_name <- 'Arizona'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- xml2::read_html(trimws(parse_url))
  access_time <- Sys.time()
  print('Arizona requires further development with Selenium')
}

#' @title        Scrape the Arizona URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arkansas <- function() {
  state_name <- 'Arkansas'
  timezone <- 'America/Chicago'
  base_url <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/ArcGIS/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=county_nam%20asc&outSR=102100&resultOffset=0&resultRecordCount=100&cacheHint=true'
  page <- jsonlite::fromJSON(base_url)
  dat <- page$features$attributes
  d1 <- make_dat(state = state_name, url = base_url, page = page,
                county = dat[2:nrow(dat), 'county_nam'],
                cases = dat[2:nrow(dat), 'positive'],
                negative_tests = dat[2:nrow(dat), 'negative'],
                pending_tests = dat[2:nrow(dat), 'pending'],
                tested = dat[2:nrow(dat), 'total_tests'],
                recovered = dat[2:nrow(dat), 'Recoveries'],
                deaths = dat[2:nrow(dat), 'deaths'],
                lab = c('private', 'state'),
                lab_tests = c(dat[1,'lab_prvt'], dat[1, 'lab_pub']))
  d2 <- make_dat(state = state_name, url = base_url, page = page,
                 cases = dat[1, 'positive'],
                 negative_tests = dat[1, 'negative'],
                 pending_tests = dat[1, 'pending'],
                 tested = dat[1, 'total_tests'],
                 recovered = dat[1, 'Recoveries'],
                 deaths = dat[1, 'deaths'])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'arkansas')
  invisible(d)
}

#' @title      scrape la times from california
#' @description scrapes data from the LA Times from the Case by county table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR TO DO WITH 'make_dat', something about state_tests not being present. But data is correctly collected
scrape_california <- function() {
  state <- NULL
  state_name <- 'California'
  parse_url <- covidR::urls[state == state_name][['url']][2]
  state_url <- 'https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/Immunization/ncov2019.aspx'
  page <- xml2::read_html(trimws(parse_url))
  spage <- get_page(state_url)
  s_raw <- rvest::html_text(spage)
  s_gender <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/ul[2]'))
  s_age <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/ul[1]'
  ))
  s_sex_v <- stringr::str_split(s_gender, 'cases')[[1]]
  sex_st <- strsplit(s_sex_v, ':')
  sex_dt <- data.table::data.table(
    sex = c(sex_st[[1]][1], sex_st[[2]][1], sex_st[[3]][1]),
    cases = c(as.integer(gsub(',', '', stringr::str_trim(sex_st[[1]][2]))),
              as.integer(gsub(',', '', stringr::str_trim(sex_st[[2]][2]))),
              as.integer(gsub(',', '', stringr::str_trim(sex_st[[3]][2]))))
  )
  s_age_v <- strsplit(stringr::str_split(
    s_age, 'cases')[[1]], ':', fixed = TRUE)
  age_dt <- data.table::data.table(
    age_range = c(s_age_v[[1]][1], s_age_v[[2]][1], s_age_v[[3]][1],
                  s_age_v[[4]][1], s_age_v[[5]][1]),
    age_cases = c(text_to_num(s_age_v[[1]][2]),
                  text_to_num(s_age_v[[2]][2]),
                  text_to_num(s_age_v[[3]][2]),
                  text_to_num(s_age_v[[4]][2]),
                  text_to_num(s_age_v[[5]][[2]]))
  )
  s_tot <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/p[3]'
  ))
  s_date <- anytime::anytime(stringr::str_extract(
    s_tot, '(?<=As of ).*(?=, there are)'))
  tbls <- rvest::html_table(page, header = TRUE, trim = TRUE, fill = TRUE)
  cdat <- tbls[[2]]
  sdat <- data.table::as.data.table(tbls[[4]])
  sdat <- sdat[State == 'CaliforniaCalif.']
  page_raw <- rvest::html_text(page)
  health_url <- covidR::urls[state == state_name][['url']][1]
  h_page <- get_page(health_url)
  h_dem <- rvest::html_text(rvest::html_node(
    h_page, xpath = '//*[@id="WebPartWPQ12"]/div[1]/div[1]/ul[2]'
  ))
  # h_dem <- gsub('cases', '', h_dem, fixed = TRUE)
  dem <- strsplit(h_dem, split = 'cases',
                  fixed = TRUE)[[1]]
  dems <- gsub('Age', '', dem, fixed = TRUE)
  demos <- strsplit(dems, ':', fixed = TRUE)
  age_ranges = c()
  age_cases = c()
  for (v in demos) {
    age_ranges <- c(age_ranges, trimws(v[1]))
    age_cases <- c(age_cases, gsub('(\\s{1,}|,)', '', v[2], perl = TRUE))
  }
  timezone = 'America/Los_Angeles'
  scases <- gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[1]/p[1]'
  )), fixed = TRUE)
  sdeaths <- gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[2]/p[1]'
  )))
  update_date <- rvest::html_node(page,
                                  xpath = '/html/body/article/header/p[2]/time')
  update_date <- gsub(' Pacific', '', rvest::html_text(update_date),
                      ignore.case = FALSE, fixed = TRUE)
  update_date <- lubridate::as_datetime(convert_am_pm(update_date),
                                        format = '%B %d, %I:%M %p',
                                        tz = timezone)
  st_tests <- stringr::str_extract(rvest::html_text(rvest::html_node(
    page, xpath = '/html/body/article/div[3]/section[2]/p[2]'
  )), '(?<=total was ).*')
  st_tests <- stringr::str_extract_all(st_tests, '\\d{1,}')[[1]]
  st_tests <- paste0(st_tests, collapse = '')
  updated <- update_date
  num_counties <- nrow(tbls[[2]])
  counties <- cdat[,1]
  num_cases <- trimws(gsub(',', '', cdat[,2], fixed = TRUE))
  num_deaths <- trimws(cdat[,3])
  state_cases <- text_to_num(stringr::str_extract(
    s_tot, '(?<=total of ).*(?=positive)'))
  state_deaths <- text_to_num(stringr::str_extract(
    s_tot, '(?<=and ).*(?= deaths)'
  ))
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                county = counties, cases = num_cases, update_date = updated,
                deaths = num_deaths)
  d2 <- make_dat(state = state_name, counties = num_counties, cases = scases,
                 deaths = sdeaths, tested = st_tests, age_range = age_ranges,
                 age_cases = age_cases)
  d3 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 cases = as.integer(gsub(',', '', sdat[['Cases']])),
                 deaths = as.integer(gsub(',', '', sdat[['Deaths']])))
  d4 <- make_dat(state = state_name, url = state_url, page = s_raw,
                 sex = sex_dt[['sex']], sex_counts = sex_dt[['cases']],
                 update_date = s_date)
  d5 <- make_dat(state = state_name, url = state_url, page = s_raw,
                 age_range = age_dt[['age_range']],
                 age_cases = age_dt[['age_cases']], update_date = s_date)
  d6 <- make_dat(state = state_name, url = state_url, page = s_raw,
                 cases = state_cases, deaths = state_deaths)
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6), fill = TRUE)
  write_out(d, 'california')
  invisible(d)
}

#' @title      scrape la times from colorado
#' @description scrapes data from the LA Times from the Case by county table
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
# ERROR TO DO WITH 'make_dat', something about state_tests not being present. But data is correctly collected
scrape_colorado <- function() {
  state_name <- 'Colorado'
  parse_url <- 'https://www.kktv.com/content/news/BREAKING--568535251.html'
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  timezone <- 'America/Denver'
  county_url <- 'https://opendata.arcgis.com/datasets/fbae539746324ca69ff34f086286845b_0.csv?outSR=%7B%22latestWkid%22%3A3857%2C%22wkid%22%3A102100%7D'
  dat <- read.csv(county_url)
  names(dat) <- toupper(names(dat))
  page_text <- rvest::html_text(
    rvest::html_node(page, xpath = '//*[@id="articlebody"]/p[8]'))
  page_data <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="articleBody"]/p[1]/b'
  ))
  update_date <- gsub('Data through ', '',
                      unique(dat[['DATE_DATA_LAST_UPDATED']]))
  update_date <- lubridate::as_datetime(paste(update_date, '16'),
                                        format = '%B %d, %Y %H',
                                        tz = timezone)
  updated <- update_date
  d1 <- make_dat(state = state_name, url = as.character(parse_url),
                page = page_raw, cases = unique(dat[['STATE_POS_CASES']]),
                update_date = updated, deaths = unique(dat[['STATE_DEATHS']]),
                tested = unique(dat[['STATE_NUMBER_TESTED']]),
                counties = unique(dat[['STATE_NUMBER_OF_COUNTIES_POS']]),
                hospitalized = unique(dat[['STATE_NUMBER_HOSPITALIZATIONS']]))
  d2 <- make_dat(state = state_name, url = county_url,
                 page = paste0(as.character(dat), collapse = '\n'),
                 county = dat[['LABEL']], cases = dat[['COUNTY_POS_CASES']])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'colorado')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_dc <- function() {
  state <- NULL
  state_name <- 'District of Columbia'
  timezone <- 'America/New_York'
  # parse_url <- 'https://coronavirus.dc.gov/release/coronavirus-data-update-march-'
  day <- lubridate::day(Sys.Date())
  # if (lubridate::hour(Sys.time()) >= 21) {
  #   parse_url <- paste0(parse_url, day)
  # } else {
  #   parse_url <- paste0(parse_url, day - 1)
  # }
  parse_url <- 'https://coronavirus.dc.gov/page/coronavirus-data'

  page_data <- readxl::read_xlsx("https://coronavirus.dc.gov/sites/default/files/dc/sites/coronavirus/page_content/attachments/COVID19_DCHealthStatisticsDataV2%20%282%29.xlsx")

  page_values <- page_data[,ncol(page_data)]
  names(page_values) <- page_data[,2]

  people_tested <- page_values["People tested overall"]
  confirmed_cases <- page_values["PHL positives"]+page_values["Commercial lab positives"]
  negative_cases <- page_values["PHL negatives"]+page_values["Commercial lab negatives"]
  deaths <- page_values["Number of deaths"]
  recovered <- page_values["People recovered"]

  other_names_and_values <- c(page_values[names(page_values)[10]], page_values[names(page_values)[11]], page_values[names(page_values)[12]], page_values[names(page_values)[13]])
  other_names <- toString(names(other_names_and_values))
  other_names_values <- toString(as.numeric(other_names_and_values))

  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  update_date <- lubridate::as_datetime(
    paste(lubridate::month(Sys.Date()), day, '2020', '20:30', sep = ' '),
                                        format = '%m %d %Y %H:%M',
                                        tz = timezone)
  # cases <- stringr::str_extract(page_raw, '(?<=case total to )\\d{1,}')

  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = confirmed_cases, deaths = deaths, tested = people_tested,
                negative_tests = negative_cases, recovered = recovered,
                update_date = update_date,
                other = other_names, other_value = other_names_values)
  write_out(d, 'dc')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_florida <- function() {
  state <- NULL
  state_name <- 'Florida'
  timezone <- 'America/New_York'
  parse_url <- 'https://fdoh.maps.arcgis.com/apps/opsdashboard/index.html#/8d0de33f260d444c852a615dc7837c86'
  dat <- jsonlite::fromJSON(parse_url)
  page_raw <- as.character(dat)
  fdat <- dat$features$attributes
  # florida datestamp nonsensical, make our own
  update_date <- make_access_time()
  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = fdat[['T_positive']], county = fdat[['County_1']],
                tested = fdat[['T_total']],
                negative_tests = fdat[['T_negative']],
                deaths = fdat[['FLandNonFLDeaths']],
                pending_tests = fdat[['T_pending']])
  write_out(d, 'florida')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_georgia <- function() {
  state <- NULL
  state_name <- 'Georgia'
  timezone <- 'America/New_York'
  # parse_url <- covidr::urls[state == state_name][['url']]
  state_url <- 'https://dph.georgia.gov/covid-19-daily-status-report'
  parse_url <- 'https://d20s4vd27d0hk0.cloudfront.net/?initialWidth=569&amp;childId=covid19dashdph&amp;parentTitle=COVID-19%20Daily%20Status%20Report%20%7C%20Georgia%20Department%20of%20Public%20Health&amp;parentUrl=https%3A%2F%2Fdph.georgia.gov%2Fcovid-19-daily-status-report%22'
  page <- get_page(parse_url)
  state_page <- get_page(state_url)
  state_raw <- rvest::html_text(state_page)
  stbls <- rvest::html_table(state_page)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  ud <- stringr::str_extract(page_raw, 'as of \\d{1,}\\/\\d{1,}\\/\\d{4} \\d{1,}:\\d{1,}:\\d{1,}')
  update_date <- lubridate::as_datetime(ud,
                                        format = 'as of %m/%d/%Y %H:%M:%S',
                                        tz = timezone)
  updated <- update_date
  lab_df <- data.table::data.table(
    lab = tbls[[8]][-1,1],
    pos = sanitize_integer(tbls[[8]][-1,2]),
    test = sanitize_integer(tbls[[8]][-1,3])
  )
  tested <- sum(lab_df[['test']])
  dem <- data.table::as.data.table(tbls[[9]])
  names(dem) <- as.character(dem[1,])
  dem <- dem[-1,]
  age_ranges <- unique(dem[['Age']])
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 update_date = update_date,
                 cases = stringr::str_extract(tbls[[6]][2,2],
                                              '\\d{1,}(?=.*\\()'),
                 hospitalized = stringr::str_extract(tbls[[6]][3,2],
                                              '\\d{1,}(?=.*\\()'),
                 deaths = stringr::str_extract(tbls[[6]][4,2],
                                              '\\d{1,}(?=.*\\()'),
                 lab = lab_df[['lab']], lab_positive = lab_df[['pos']],
                 lab_tests = lab_df[['test']], tested = tested)
  cdf <- tbls[[7]][2:nrow(tbls[[7]]) - 1,]
  names(cdf) <- cdf[1,]
  cdf <- cdf[-1,]
  gend <- tbls[[10]]
  names(gend) <- gend[1,]
  gend <- data.table::as.data.table(gend[-1,])
  # cdf <- cdf[-1,]
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = cdf[,2], county = cdf[,1], deaths = cdf[,3],
                update_date = updated)
  d3 <- make_dat(state = state_name, update_date = updated, url = parse_url,
                 page = page_raw, cases = dem[['Cases']],
                 other = 'Race', other_value = dem[['Race']])
  d4 <- make_dat(state = state_name, update_date = updated, url = parse_url,
                 page = page_raw, cases = dem[['Cases']],
                 other = 'Race', other_value = dem[['Race']])
  d5 <- make_dat(state = state_name, update_date = updated, url = parse_url,
                 page = page_raw, cases = dem[['Cases']],
                 other = 'Ethnicity', other_value = dem[['Ethnicity']])
  d6 <- make_dat(state = state_name, update_date = updated, url = parse_url,
                 page = page_raw,
                 cases = as.integer(stringr::str_extract(tbls[[6]][2,2],
                                                         '\\d{1,}(?= )')),
                 hospitalized = as.integer(stringr::str_extract(tbls[[6]][3,2],
                                                                '\\d{1,}(?= )')),
                 deaths = as.integer(stringr::str_extract(tbls[[6]][4,2],
                                                          '\\d{1,}(?= )')))
  d7 <- make_dat(state = state_name, update_date = updated, url = parse_url,
                 page = page_raw, age_range = gend[['Age']], cases = 1,
                 sex = gend[['Gender']],
                 county = snakecase::to_title_case(gend[['County']]),
                 other = 'Underlying Conditions',
                 other_value = gend[['Underlying']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7), fill = TRUE)
  write_out(d, 'georgia')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hawaii <- function() {
  state <- NULL
  state_name <- 'Hawaii'
  timezone <- 'Pacific/Honolulu'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  cases <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[1]/dl'
  ))
  hosp <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[1]'
  ))
  death <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[2]'
  ))
  cases <- strsplit(cases, '\n', fixed = TRUE)[[1]]
  stc <- stringr::str_extract(cases[1], '(?<=Total cases: ).*(?=\\s\\()')
  sth <- stringr::str_extract(hosp, '(?<=Hospitalization: ).*(?=\\s\\()')
  std <- stringr::str_extract(death, '(?<=deaths: ).*(?=\\s\\()')
  stp <- stringr::str_extract(cases[5], '(?<=Pending: ).*(?=\\s\\()')
  ud <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[3]'
  ))
  ud <- lubridate::as_datetime(
    convert_am_pm(ud), format = 'Cumulative totals as of %I:%M%p on%B %d, %Y',
    tz = timezone)
  cc <- stringr::str_extract(cases[-c(1,6)], '^.*(?=\\sCounty:)')
  cn <- stringr::str_extract(cases[-c(1,6)], '(?<=County: ).*(?=\\s\\()')
  # update_date <- unique(names(table))
  # update_date <- convert_am_pm(stringr::str_extract(
  #   update_date, '(\\d{1,}:\\d{2}\\w{2} on \\w+ \\d{1,}, \\d{4})'))
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%i:%m%p on %b %d, %y',
  #                                       tz = timezone)
  # updated <- update_date
  # table <- table[c(-1, -2, -3),]
  # table <- table[1:nrow(table) - 1,]
  # names(table) <- c('county', 'cases')
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = stc, hospitalized = sth, deaths = std,
                update_date = ud)
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 county = cc, cases = cn, update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'hawaii')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_idaho <- function() {
  state <- county <- NULL
  state_name <- 'Idaho'
  timezone <- 'America/Denver'
  # parse_url <- covidR::urls[state == state_name][['url']]
  parse_url <- 'https://coronavirus.idaho.gov/'
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  county <- tbls[[1]][-nrow(tbls[[1]]),]
  ud <- rvest::html_text(rvest::html_node(page, xpath = '//*[@id="post-326"]/div/div[2]/div[1]/p[4]/sup'))
  ud <- stringr::str_extract(ud, '(?<=data updated at ).*(?=\\. State)')
  ud <- convert_am_pm(gsub(' MT', '', ud))
  ud <- lubridate::as_datetime(ud, format = '%I:%M %p, %m/%d/%Y',
                               tz = timezone)
  labs <- tbls[[2]]
  sdat <- tbls[[3]]
  # d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
  #                cases = tbls[[1]][18,3], deaths = tbls[[1]][18,4],
  #                hospitalized = tbls[[5]][1,2],
  #                state_tests = gsub(',', '', tbls[[2]][,1]),
  #                private_tests = gsub(',', '', tbls[[2]][,2]),
  #                age_range = tbls[[3]][,1], age_cases = tbls[[3]][,2],
  #                cases_male = tbls[[4]][2,2], cases_female = tbls[[4]][1,2])
  # d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
  #                county = tbls[[1]][,2], cases = tbls[[1]][,3],
  #                deaths = tbls[[1]][,4])
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 cases = county$Cases, county = county$County,
                 deaths = county$Deaths)
  d2 <- make_dat(state = state_name, cases = sdat[1,2], age_range = sdat[3:6,1],
                 age_cases = sdat[3:6,2], sex = sdat[8:9, 1],
                 sex_counts = sdat[8:9, 2], hospitalized = sdat[12, 2],
                 icu = sdat[14, 2], other = 'Healthcare Worker Cases',
                 other_value = sdat[12, 2])
  d3 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 lab = labs[[,1]], lab_tests = gsub(',', '', labs[[,2]]))
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'idaho')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_louisiana <- function() {
  state <- NULL
  state_name <- 'Louisiana'
  base_url <- 'http://ldh.la.gov/Coronavirus/'
  url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Deaths%20desc%2CCases%20desc%2CParish%20asc&outSR=102100&resultOffset=0&resultRecordCount=65&cacheHint=true'
  page <- jsonlite::fromJSON(url)
  tbl <- page$features$attributes
  d1 <- make_dat(state = state_name, url = url, county = tbl$Parish,
                cases = tbl$Cases, deaths = tbl$Deaths, lat = tbl$Latitude,
                lon = tbl$Longitude, fips = tbl$PFIPS)
  tests_url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  td <- jsonlite::fromJSON(tests_url)
  td <- td$features$attributes$value
  cd <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value2%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cd <- cd$features$attributes$value
  counties <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=(Cases%20%3E%200)%20AND%20(PFIPS%20%3C%3E%200)%20AND%20(PFIPS%20%3C%3E%2099999)&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22count%22%2C%22onStatisticField%22%3A%22FID%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cs <- counties$features$attributes$value
  cases <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cases <- cases$features$attributes$value
  deaths <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Deaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  st_cases <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  deaths <- deaths$features$attributes$value
  d2 <- make_dat(state = state_name, url = base_url, tested = td + cd,
                 counties = cs, deaths = cd,
                 cases = st_cases$features$attributes$value,
                 private_tests = cd, state_tests = td)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'louisiana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maine <- function() {
  state <- NULL
  state_name <- 'Maine'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)

  update_date <- gsub('Updated: ', '', unique(tbls[[2]][1,1]))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %y at %I:%M %p',
                                        tz = timezone)
  state_cases <- tbls[[2]]
  county_cases <- tbls[[3]][-1:-2,]
  d1 <- make_dat(state = state_name, url = url, county = county_cases[,1],
                 cases = county_cases[,2], page = page_raw,
                 recovered = county_cases[,3], update_date = update_date)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 resolution = 'state',
                 cases = gsub(',', '', state_cases[3,1]),
                 deaths = gsub(',','', state_cases[3,2]),
                 cases_male = tbls[[5]][2,3], cases_female = tbls[[5]][2,4],
                 negative_tests = gsub(',', '', state_cases[3,3]),
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'maine')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maryland <- function() {
  print('requries selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_massachusetts <- function() {
  state <- NULL
  state_name <- 'Massachusetts'
  print('requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_michigan <- function() {
  state_name <- 'Michigan'
  timezone <- 'America/Chicago'
  url <-
    'https://www.michigan.gov/coronavirus/0,9753,7-406-98163-520743--,00.html'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tables <- rvest::html_table(page, fill = TRUE)
  county_cases <- tables[[1]]
  names(county_cases) <- county_cases[1,]
  county_cases <- county_cases[-1,]
  update_date <- paste0(format(Sys.Date(),
                               format = '%Y-%m-%d'), ' 2:00 PM')
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%Y-%m-%d %I:%M %p',
                                        tz = timezone)
  if (length(tables) > 3) {
    state_data <- tables[[4]]
    d1 <- make_dat(state = state_name, url = url, page = page_raw,
                   county = county_cases$county, cases = county_cases$cawses,
                   update_date = update_date)
    d2 <- make_dat(state = state_name, url = url, page = page_raw,
                   hospitalized = state_data$Hospitalized,
                   cases = state_data$Number)
    d <- data.table::rbindlist(list(d1, d2), fill = TRUE)

  } else {
    d <- make_dat(state = state_name, url = url, page = page_raw,
                 county = county_cases$county, cases = county_cases$cawses,
                 update_date = update_date)
  }
  write_out(d, 'michigan')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_minnesota <- function() {
  state_name <- 'Minnesota'
  url <- 'https://www.health.state.mn.us/diseases/coronavirus/situation.html'
  timezone <- 'America/Chicago'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  update_date <- stringr::str_extract(page_raw,
                                      '(?<=As of )\\w{1,} \\d{1,}, \\d{4}')
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  print('needs selenium for county results')
  state_cases <- as.integer(gsub(',', '',
                                 stringr::str_extract(page_raw,
                                                      '(?<=Positive: )\\d{1,}'))
                            )
  tested <- as.integer(gsub(',', '',
                            stringr::str_extract(page_raw,
                                                 '(?<=Lab: )\\d{1,}')))
  d <- make_dat(state = state_name, url = url, update_date = update_date,
                cases = state_cases, tested = tested)
  write_out(d, 'minnesota')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_mississippi <- function() {
  state_name <- 'Mississippi'
  page <- get_page('https://msdh.ms.gov/msdhsite/_static/14,0,420.html')
  page_raw <- rvest::html_text(page)
  cases <- rvest::html_node(page, xpath = '//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[2]/transform/div/div[3]/visual-modern/div/svg/g[1]/text/tspan')
  print('needs selenium')
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_missouri <- function() {
  httr::set_config(httr::config(ssl_verifypeeer = 0L))
  state_name <- 'Missouri'
  timezone <- 'America/Chicago'
  # st_url <- covidR::urls[state == state_name][['url']]
  st_url <- 'https://health.mo.gov/living/healthcondiseases/communicable/novel-coronavirus/results.php'
  st_page <- get_page(st_url)
  st_page_raw <- rvest::html_text(st_page)
  tbls <- rvest::html_table(st_page, fill = TRUE)
  county <- tbls[[1]]
  county_deaths <- tbls[[2]]
  age <- tbls[[3]]
  sex <- tbls[[5]]
  total_cases <- sum(tbls[[4]][,2])
  deaths <- sum(tbls[[2]][,2])
  ud <- rvest::html_text(rvest::html_node(st_page, xpath = '//*[@id="main-content"]/p[4]'))
  ud <- convert_am_pm(strsplit(ud, '\r\n\\s{1,}')[[1]][1])
  updated <- lubridate::as_datetime(ud, format = 'As of %I:%M %p CT, %B %d',
                                    tz = timezone)
  d1 <- make_dat(state = state_name, url = st_url, page = st_page_raw,
                 cases = total_cases, update_date = updated,
                 deaths = deaths, age_range = age[,1], age_cases = age[,2],
                 sex = sex[,1], sex_counts = sex[,2],
                 pending_tests = tbls[[4]][4,2])
  d2 <- make_dat(state = state_name, url = url, page = st_page_raw,
                 county = county[,1], cases = county[,2],
                 lab = names(county)[3:4],
                 lab_positive = county[,3],
                 update_date = updated)
  d3 <- make_dat(state = state_name, url = st_url, page = st_page_raw,
                 county = county_deaths[,1], deaths = county_deaths[,2],
                 update_date = updated)
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'missouri')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_montana <- function() {
  state_name <- 'Montana'
  timezone <- 'America/Denver'
  tccr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Total%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  tcc <- tccr$features$attributes$value
  dr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalDeaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  deaths <- dr$features$attributes$value
  recr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalRecovered%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  rec <- recr$features$attributes$value
  ttj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Total_Tests_Completed%20desc&outSR=102100&resultOffset=0&resultRecordCount=1&cacheHint=true')
  tt_tests <- ttj$features$attributes$Total_Tests_Completed
  mfj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_0_9%22%2C%22outStatisticFieldName%22%3A%22F_0_9%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_10_19%22%2C%22outStatisticFieldName%22%3A%22F_10_19%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_20_29%22%2C%22outStatisticFieldName%22%3A%22F_20_29%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_30_39%22%2C%22outStatisticFieldName%22%3A%22F_30_39%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_40_49%22%2C%22outStatisticFieldName%22%3A%22F_40_49%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_50_59%22%2C%22outStatisticFieldName%22%3A%22F_50_59%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_60_69%22%2C%22outStatisticFieldName%22%3A%22F_60_69%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_70_79%22%2C%22outStatisticFieldName%22%3A%22F_70_79%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_80_89%22%2C%22outStatisticFieldName%22%3A%22F_80_89%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_90_99%22%2C%22outStatisticFieldName%22%3A%22F_90_99%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_100%22%2C%22outStatisticFieldName%22%3A%22F_100%22%7D%5D&outSR=102100&cacheHint=true')
  fd <- data.table::data.table(
    sex = 'Female',
    age_range = gsub('F_', '', names(mfj$features$attributes)),
    age_cases = t(mfj$features$attributes[,1:length(names(mfj$features$attributes))])
  )
  hospj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22HospitalizationCount%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ccj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true')
  cc <- data.table::data.table(
    county = ccj$features$attributes$NAMELABEL,
    cases = ccj$features$attributes$Total,
    deaths = ccj$features$attributes$TotalDeaths,
    hosp = ccj$features$attributes$HospitalizationCount,
    rec = ccj$features$attributes$TotalRecovered
  )
  mdd <- ccj$features$attributes
  male_names <- stringr::str_extract_all(names(mdd), '^M\\_.*')
  male_names <- unlist(Filter(length, male_names))
  mddd <- mdd[,c(male_names)]
  md <- data.table::data.table(
    sex = 'Male',
    age_range = gsub('M_', '', names(mddd)),
    age_cases = colSums(mddd)
  )

  ud <- as.POSIXct(paste(paste(Sys.Date()), '10:00'), tz = timezone)

  d1 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Total%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 cases = tcc, page = as.character(tccr), update_date = ud)
  d2 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalDeaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 deaths = deaths, page = as.character(dr), update_date = ud)
  d3 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalRecovered%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 update_date = ud, recovered = rec, page = as.character(recr))
  d4 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Total_Tests_Completed%20desc&outSR=102100&resultOffset=0&resultRecordCount=1&cacheHint=true',
                 tested = tt_tests, page = as.character(ttj), update_date = ud)
  d5 <- make_dat(state = state_name, update_date = ud, sex = fd[,1],
                 age_range = fd[,2], age_cases = fd[,3])
  d6 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22HospitalizationCount%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true',
                 update_date = ud, hospitalized = hospj$features$attributes$value,
                 page = as.character(hospj))
  d7 <- make_dat(state = state_name, update_date = ud, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true',
                 county = cc$county, cases = cc$cases, deaths = cc$deaths,
                 hospitalized = cc$hosp, recovered = cc$rec)
  d8 <- make_dat(state = state_name, update_date = ud, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true',
                 sex = md$sex, age_range = md$age_range, age_cases = md$age_cases,
                 page = as.character(mdd))
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8), fill = TRUE)
  write_out(d, 'montana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nebraska <- function() {
  state_name <- 'Nebraska'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name,][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  cases <- as.integer(stringr::str_extract(
    page_raw, '(?<=cases – )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  negative <- as.integer(stringr::str_extract(
    page_raw, '(?<= negative - )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  update_date <- stringr::str_extract(
    page_raw, '(?<=Updated: )\\w{1,} \\d{1,}, \\d{4}'
  )
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases, negative_tests = negative,
                update_date = update_date)
  write_out(d, 'nebraska')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nevada <- function() {
  state_name <- 'Nevada'
  timezone <- 'America/Los_Angeles'
  url <- 'http://dpbh.nv.gov/coronavirus/'
  url <- 'https://app.powerbigov.us/view?r=eyJrIjoiMjA2ZThiOWUtM2FlNS00MGY5LWFmYjUtNmQwNTQ3Nzg5N2I2IiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  # tbl <- rvest::html_table(page)[[1]]
  # update_date <- lubridate::as_datetime(
  #   gsub('last updated ', '', tbl[2,1]), format = '%m/%d/%y, %i:%m %p',
  #   tz = timezone)
  # make_dat(state = state_name, url = url, page = page_raw,
  #          update_date = update_date, cases = tbl[3, 2],
  #          presumptive_positive = tbl[4, 2], negative_tests = tbl[5, 2],
  #          monitored = tbl[9,2])
  print('Nevada needs selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_hampshire <- function() {
  print('County data is in a picture')
  state <- NULL
  state_name <- 'New Hampshire'
  timezone <- 'America/New_York'
  url <- 'https://nh.gov/covid19/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_table(page)[[1]]
  update_date <- gsub('updated', '', stringr::str_extract(rvest::html_text(
    rvest::html_node(
      page, xpath = '//*[@id="bodycontainer"]/main/div[3]/section[1]/h4')),
    '\\(([^\\)]+)\\)'
    ))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '( %B %d, %Y, %I:%M %p',
                                        tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = tbl[1,2], pending_tests = tbl[2,2], tested = tbl[3,2],
                monitored = tbl[4,2], update_date = update_date)
  write_out(d, 'new_hampshire')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @importFrom magrittr %>%
#' @export
scrape_new_jersey <- function() {
  state <- NULL
  state_name <- 'New Jersey'
  timezone <- 'America/New_York'
  url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Counties/FeatureServer/0/query?f=json&returnGeometry=true&spatialRel=esriSpatialRelIntersects&geometry=%7B%22xmin%22%3A-8766409.899972958%2C%22ymin%22%3A5009377.085700976%2C%22xmax%22%3A-8140237.764260961%2C%22ymax%22%3A5635549.2214129735%2C%22spatialReference%22%3A%7B%22wkid%22%3A102100%7D%7D&geometryType=esriGeometryEnvelope&inSR=102100&outFields=*&outSR=102100&resultType=tile'
  page <- jsonlite::fromJSON(url)
  page_raw <- jsonlite::toJSON(page)
  tbl <- data.table::as.data.table(page$features$attributes)
  tbl[, county := snakecase::to_title_case(COUNTY)]
  url2 <- 'https://maps.arcgis.com/sharing/rest/content/items/84737ef7f760486293b6afa536f028e0?f=json'
  call_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/survey123_4b4d331a233d419abbcc52ab45158b56/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22max%22%2C%22onStatisticField%22%3A%22total_calls_%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  page <- jsonlite::fromJSON(url2)
  county_data_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&resultOffset=0&resultRecordCount=25&cacheHint=true'
  cd <- jsonlite::fromJSON(county_data_url)
  url3 <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&outSR=102100&resultOffset=0&resultRecordCount=25&cacheHint=true'
  ccd <- data.table::as.data.table(jsonlite::fromJSON(url3)$features$attributes)
  # d1 <- make_dat(state = state_name, url = url, page = page_raw,
  #               county = snakecase::to_title_case(cd$features$attributes$COUNTY),
  #               cases = cd$features$attributes$TOTAL_CASES, deaths = cd$features$attributes$TOTAL_DEATHS,
  #               update_date = ud)
  # d2 <- make_dat(state = state_name)
  vvd <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/nj_cases_time/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=ObjectId%2Ccases%2Cdate&orderByFields=date%20asc&resultOffset=0&resultRecordCount=2000&cacheHint=true')$features$attributes
  ud <- max(anytime::anytime(vvd$date/1000))
  d1 <- make_dat(state = state_name, url = url3, page = as.character(paste0(ccd, collapse = '')),
                 county = snakecase::to_title_case(ccd[['COUNTY']]),
                 cases = ccd[['TOTAL_CASES']], deaths = ccd[['TOTAL_DEATHS']],
                 other = 'New Cases', other_value = ccd[['NEW_CASES']],
                 update_date = ud)
  d2 <- make_dat(state = state_name, url = url3, page = as.character(paste0(ccd, collapse = '')),
                 county = snakecase::to_title_case(ccd[['COUNTY']]),
                 other = 'New Deaths', other_value = ccd[['NEW_DEATHS']],
                 update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_jersey')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_mexico <- function() {
  state <- NULL
  state_name <- 'New Mexico'
  timezone <- 'America/Denver'
  url <- 'https://nmhealth.org/news/alert/2020/3/?view=856'
  print('url contains a date element, may need to evaluate after march')
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  st_total <- stringr::str_extract(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content"]/p[3]')),
    '(?<=total of )\\d{1,}')
  st_total <- rvest::html_text(rvest::html_node(page, xpath = '//*[@id="content"]/p[3]'))
  ud <- strsplit(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content"]/div[2]/em')), ' - ', fixed = TRUE)[[1]][1]
  ud <- lubridate::as_datetime(paste(ud, '12:00'), format = '%B %d, %Y %H:%M',
                               tz = timezone)
  cc <- rvest::html_text(rvest::html_node(page,
                                          xpath = '//*[@id="content"]/ul[2]'))
  cc <- strsplit(cc, '\r\n', fixed = TRUE)[[1]]
  counties <- c()
  cases <- c()
  for (c in cc) {
    cs <- strsplit(c, ': ', fixed = TRUE)[[1]]
    counties <- append(counties, gsub(' County', '', cs[1]))
    cases <- append(cases, cs[2])
  }
  st_page_url <- 'https://cv.nmhealth.org/'
  sp <- get_page(st_page_url)
  stbls <- rvest::html_table(sp)
  state_raw <- rvest::html_text(sp)
  st_total <- gsub(',', '', stbls[[1]][3,2])
  st_neg <- gsub(',', '', stbls[[1]][3,2])
  st_pos <- gsub(',', '', stbls[[1]],1,2)
  s_cases <- rvest::html_text(rvest::html_node(
    sp, xpath = '//*[@id="et-boc"]/div/div/div[2]/div/div[2]/div[1]/div/div/h2/span'
  ))
  d1 <- make_dat(state = state_name, url = url, page = state_raw,
                 cases = st_total, update_date = ud, negative_tests = st_neg,
                 tested = st_total)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = counties, cases = cases, update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_mexico')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_york <- function() {
  state_name <- 'New York'
  timezone <- 'America/New_York'
  csv_url <- 'https://health.data.ny.gov/api/views/xdss-u53e/rows.csv?accessType=DOWNLOAD'
  cdat <- data.table::fread(csv_url)
  cdat[, date := anytime::anydate(`Test Date`)]
  url <- 'https://health.data.ny.gov/Health/New-York-State-Statewide-COVID-19-Testing/xdss-u53e'
  raw_page <- rvest::html_text(get_page(url))
  ud <- max(cdat[['date']])
  d1 <- make_dat(state = state_name, url = csv_url, page = raw_page,
                update_date = cdat[['date']], county = cdat[['County']],
                cases = cdat[['Cumulative Number of Positives']],
                tested = cdat[['Cumulative Number of Tests Performed']],
                other = 'New Positives', other_value = cdat[['New Positives']])
  d2 <-  make_dat(state = state_name, url = csv_url, page = raw_page,
                  update_date = cdat[['date']], county = cdat[['County']],
                  other = 'tested_daily',
                  other_value = cdat[['Total number of Tests Performed']])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_york')
  return(d)
}



#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_north_carolina <- function() {
  state_name <- 'North Carolina'
  url <- ' https://www.ncdhhs.gov/covid-19-case-count-nc'
  timezone <- 'America/New_York'
  print('County data will need selenium')
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbl <- rvest::html_table(page)[[1]]
  cases <- tbl[2,1]
  deaths <- tbl[2,2]
  tested <- tbl[2,3]
  update_date <- convert_am_pm(stringr::str_extract(page_raw,
                                                    '(?<=Last updated ).*\\.'))
  update_date <- gsub('a\\.m\\.', 'AM', update_date)
  update_date <- gsub('p\\.m\\.', 'PM', update_date)
  udpate_date <- lubridate::as_datetime(update_date,
                                        format = '%I:%M%p, %B %d, %Y.',
                                        tz = timezone)
  d <- make_dat(state = state_name, cases = cases, deaths = deaths, url = url,
                page = page_raw, update_date = update_date)
  write_out(d, 'north_carolina')
  warning('North Carolina county data requries selenium')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_north_dakota <- function() {
  state_name <- 'North Dakota'
  print('ND has data in images, will need selenium and OCR to scrape')
}

#' @title      scrape Ohio
#' @description scrapes urls for Ohio
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_ohio <- function() {
  state_name <- 'Ohio'
  url <- covidR::urls[state == state_name][['url']]
  state_url <- 'https://coronavirus.ohio.gov/wps/portal/gov/covid-19/home'
  timezone <- 'America/New_York'
  page <- get_page(state_url)
  page_raw <- rvest::html_text(page)
  csv_url <- 'https://coronavirus.ohio.gov/static/COVIDSummaryData.csv'
  cd <- data.table::as.data.table(read.csv(csv_url,
                                           stringsAsFactors = FALSE,
                                           strip.white = TRUE))
  cd[, `:=`(Case.Count = as.integer(gsub(',', '', Case.Count)),
            Hospitalized.Count = as.integer(gsub(',', '', Hospitalized.Count)),
            Death.Count = as.integer(gsub(',','',Death.Count)))]
  sd <- cd[nrow(cd),]
  cd <- cd[-nrow(cd),]
  sd_age <- cd[,.(cases = sum(Case.Count),
                  deaths = sum(Death.Count),
                  hospt = sum(Hospitalized.Count)), by = 'Age.Range']
  cd_cases <- cd[,.(case_sum = sum(Case.Count)), by = 'County']
  cd_deaths <- cd[,.(death_sum = sum(Death.Count)), by = 'County']
  cd_hospitalized <- cd[,.(hospitalized = sum(Hospitalized.Count)), by = 'County']
  age_range_cases <- cd[,.(age_cases = sum(Case.Count),
                           age_deaths = sum(Death.Count),
                           age_hosp = sum(Hospitalized.Count)), by = c('County',
                                                                'Age.Range')]
  age_range_sex_cases <- cd[,.(hosp = sum(Hospitalized.Count),
                               cases = sum(Case.Count),
                               deaths = sum(Death.Count)),
                            by = c('County', 'Age.Range', 'Sex')]
  age_range_hospitalized <- cd[, .(age_hosp = sum(Hospitalized.Count)),
                               by = c('County', 'Age.Range')]
  age_range_deaths <- cd[,.(age_death = sum(Death.Count)), by = 'County']
  sex_cases <- cd[, .(cases = sum(Case.Count),
                      death = sum(Death.Count),
                      hosp = sum(Hospitalized.Count)), by = 'Sex']
  scbc <- cd[, .(cases = sum(Case.Count),
                      death = sum(Death.Count),
                      hosp = sum(Hospitalized.Count)), by = c('Sex', 'County')]
  county_cases <- cd[,.(cases = sum(Case.Count),
                        death = sum(Death.Count),
                        hosp = sum(Hospitalized.Count)), by = 'County']
  icu <- as.integer(gsub(',', '', trimws(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[1]/div[2]/div[1]/div'
  )))))
  median <- as.integer(gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[2]/div[2]/div[1]/div'
  ))))
  d1 <- make_dat(state = state_name, url = csv_url,
                 county = county_cases[['County']],
                 cases = county_cases[['cases']],
                 hospitalized = county_cases[['hosp']],
                 deaths = county_cases[['death']]
                 )
  d2 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 cases = gsub(',','', sd[['Case.Count']]),
                 deaths = gsub(',', '', sd[['Death.Count']]),
                 hospitalized = gsub(',', '', sd[['Hospitalized.Count']]),
                 icu = icu, other = 'Median Age', other_value = median,
                 sex = sex_cases[['Sex']], sex_counts = sex_cases[['cases']])
  d3 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 sex = sex_cases[['Sex']], other = 'Sex Deaths',
                 other_value = sex_cases[['death']])
  d4 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 sex = sex_cases[['Sex']], other = 'Sex Hospitalized',
                 other_value = sex_cases[['hosp']])
  d5 <- make_dat(state = state_name, url = csv_url, page = as.character(cd),
                 sex = scbc[['Sex']], county = scbc[['County']],
                 sex_counts = scbc[['cases']])
  d6 <- make_dat(state = state_name, url = csv_url,
                 county = age_range_cases[['County']],
                 age_range = age_range_cases[['Age.Range']],
                 age_cases = age_range_cases[['age_cases']],
                 age_deaths = age_range_cases[['age_deaths']],
                 age_hospitalized = age_range_cases[['age_hosp']])
  d7 <- make_dat(state = state_name, url = csv_url, page = page_raw,
                 sex = scbc[['Sex']], county = scbc[['County']],
                 other = 'Sex Deaths', other_value = scbc[['death']])
  d8 <- make_dat(state = state_name, url = csv_url, page = page_raw,
                 county = scbc[['County']],
                 sex = scbc[['Sex']], other = 'Sex Hospitalized',
                 other_value = scbc[['hosp']])
  d9 <- make_dat(state = state_name, url = csv_url,
                 county = age_range_sex_cases[['County']],
                 age_range = age_range_sex_cases[['Age.Range']],
                 sex = age_range_sex_cases[['Sex']],
                 cases = age_range_sex_cases[['cases']],
                 other = 'Sex Hospitalized',
                 other_value = age_range_sex_cases[['hosp']])
  d10 <- make_dat(state = state_name, url = csv_url,
                 county = age_range_sex_cases[['County']],
                 age_range = age_range_sex_cases[['Age.Range']],
                 sex = age_range_sex_cases[['Sex']],
                 cases = age_range_sex_cases[['cases']],
                 other = 'Sex Deaths',
                 other_value = age_range_sex_cases[['deaths']])
  d11 <- make_dat(state = state_name, url = csv_url,
                  age_range = sd_age[['Age.Range']],
                  age_cases = sd_age[['cases']],
                  age_deaths = sd_age[['deaths']],
                  age_hospitalized = sd_age[['hospt']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d10, d11),
                             fill = TRUE)
  write_out(d, 'ohio')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oklahoma <- function() {
  state_name <- 'Oklahoma'

  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  update_date <- rvest::html_text(
    rvest::html_node(
      page,
      xpath = '/html/body/div[2]/main/div/div/div[5]/div[1]/div/div[5]/div/p[2]/em'
      ))
  update_date <- stringr::str_extract(
    update_date,
    '\\d{4}-\\d{1,}-\\d{1,} at \\d{1,}:\\d{1,}\\s\\w{1,}')
  update_date <- gsub(' at', '', update_date, fixed = TRUE)
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%Y-%m-%d %I:%M %p',
                                        tz = timezone)
  tbls <- rvest::html_table(page)
  state_tbl <- tbls[[1]]
  county_tbl <- tbls[[5]]
  state_cases <- state_tbl[1,2] + state_tbl[2,2]
  state_negative <- state_tbl[3,2]
  state_pending <- state_tbl[4,2]
  state_hospitalized <- state_tbl[5,2]
  state_deaths <- state_tbl[6,2]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = state_cases, negative_tests = state_negative,
                 pending_tests = state_pending, update_date = update_date,
                 hospitalized = state_hospitalized, deaths = state_deaths,
                 state_tests = tbls[[2]][1,2],
                 private_tests = tbls[[2]][2,2] + tbls[[2]][3,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = county_tbl[,2], county = county_tbl[,1],
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'oklahoma')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oregon <- function() {
  state_name <- 'Oregon'
  timezone <- 'America/Los_Angeles'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- unique(names(tbls[[1]]))
  update_date <- stringr::str_extract(
    update_date, '\\d{1,}/\\d{1,}/\\d{1,}, \\d{1,}:\\d{1,} \\w\\.\\w.')
  update_date <- gsub('a.m.', 'AM', update_date)
  update_date <- gsub('p.m.', 'PM', update_date)
  update_date <- lubridate::as_datetime(
    update_date, format = '%m/%d/%Y, %I:%M %p', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], update_date = update_date,
                 hospitalized = tbls[[4]][1,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[2]][,1], cases = tbls[[2]][,2],
                 deaths = tbls[[2]][,3], negative_tests = tbls[[2]][,4],
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'oregon')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_pennsylvania <- function() {
  state_name <- 'Pennsylvania'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  url <- 'https://www.health.pa.gov/topics/disease/coronavirus/Pages/Cases.aspx'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="ctl00_PlaceHolderMain_PageContent__ControlWrapper_RichHtmlField"]/p/span'
  ))
 ud <- stringr::str_extract(update_date,
                                     '(?<=counts last updated at ).*$')
 update_date <- convert_am_pm(ud)
 update_date <- lubridate::as_datetime(update_date,
                                       format = '%I:%m %p on %m/%d/%Y',
                                       tz = timezone)
 d1 <- make_dat(state = state_name, update_date = update_date,
                cases = tbls[[1]][2,2], negative_tests = tbls[[1]][2,1],
                deaths = tbls[[1]][2,3],
                age_range = gsub('<U+200B>', '',
                                 tbls[[2]][2:nrow(tbls[[2]]), 1], fixed = TRUE),
                age_percent = gsub('<U+200B>', '',
                                 tbls[[2]][2:nrow(tbls[[2]]), 2], fixed = TRUE),
               url = url, page = page_raw)
 d2 <- make_dat(state = state_name, update_date = update_date, page = page_raw,
                county = tbls[[4]][,1], cases = tbls[[4]][,2],
                deaths = tbls[[4]][,3])
 d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
 write_out(d, 'pennsylvania')
 d
}

#' @title       scrape Puerto Rico
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_puerto_rico <- function() {
  state_name <- 'Puerto Rico'
  timezone <- 'Atlantic/Bermuda'
  url <- 'http://www.salud.gov.pr/Pages/coronavirus.aspx'
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # tbls <- rvest::html_table(page, fill = TRUE)
  # tbl <- tbls[[1]]
  # update_date <- rvest::html_text(
  #   rvest::html_node(
  #     page, xpath = '//*[@id="WebPartWPQ6"]/div[1]/h3[2]'))
  # update_date <- gsub(')', '', gsub('de', '', gsub('\\s{1,}', '',
  #                                    gsub('(Datos al', '', update_date,
  #                                                         fixed = TRUE))))
  # update_date <- convert_month_language(update_date)
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%d%B%Y,%H:%M',
  #                                       tz = timezone)
  # d <- make_dat(state = state_name, url = url, page = page_raw,
  #               tested = tbl[3,2], cases = tbl[3,3],
  #               negative_tests = tbl[3,4], update_date = update_date,
  #               pending_tests = tbl[3,4])
  # write_out(d, 'puerto_rico')
  # invisible(d)
  warning('Puerto Rico requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_rhode_island <- function() {
  state_name <- 'Rhode Island'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  # url_spreadsheet <- 'https://docs.google.com/spreadsheet/tq?key=1n-zMS9Al94CPj_Tc3K7Adin-tN9x1RSjjx2UzJ4SV7Q&headers=0&range=A2%3AB5&gid=0&tqx=reqId%3A1'
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # js <- gsub('/*O_o*/\ngoogle.visualization.Query.setResponse(', '', page_raw,
  #            fixed = TRUE)
  # js <- gsub(');', '', js, fixed = TRUE)
  # tbl <- unlist(jsonlite::fromJSON(js)$table$rows$c)
  # d1 <- make_dat(state = state_name, url = url, page = page_raw,
  #               cases = tbl[[2]], negative_tests = tbl[[8]],
  #               pending_tests = tbl[[10]], quarantined = tbl[[14]])
  # write_out(d, 'rhode_island')
  # invisible(d)
  warning('Rhode Island needs selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_carolina <- function() {
  state_name <- 'South Carolina'
  url <- 'https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/monitoring-testing-covid-19'
  page <- get_page(url)
  raw_page <- rvest::html_text(page)
  county_url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/Covid19_Cases_Centroid_SharingView/FeatureServer/0/query?f=json&where=Confirmed%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Confirmed%20desc&resultOffset=0&resultRecordCount=1000&cacheHint=true'
  page <- jsonlite::fromJSON(county_url)
  cdat <- page$features$attributes
  update_date <- anytime::anytime(cdat[['Date_']]/1000)
  # tbls <- rvest::html_table(page)
  # cdat <- jsonlite::fromJSON(county_url)$features$attributes
  # d1 <- make_dat(state = state_name, url = url, page = raw_page,
  #               update_date = update_date, negative_tests = tbl[1,2],
  #               cases = tbl[2,2])
  d <- make_dat(state = state_name, url = url, page = raw_page, county = cdat$NAME,
                cases = cdat$Confirmed, recovered = cdat$Recovered,
                deaths = cdat$Death, lat = cdat$Lat, lon = cdat$Long_,
                active = cdat$Active, update_date = update_date)
  write_out(d, 'south_carolina')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_dakota <- function() {
  state_name <- 'South Dakota'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content_block"]/p[5]/text()[2]'))
  ud <- convert_am_pm(gsub('\\s', '', update_date, perl = TRUE))
  ud <- gsub('Lastupdated:', '', ud, fixed = TRUE)
  update_date <- lubridate::as_datetime(
    ud, format = '%I:%M%p;%B%d,%Y', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], deaths = tbls[[2]][2,2],
                 update_date = update_date, resolution = 'state',
                 recovered = tbls[[2]][3,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[3]][-8, ][,2], county = tbls[[3]][-8,][,1],
                 resolution = 'county', update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'south_dakota')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_tennessee <- function() {
  state_name <- 'Tennessee'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  ud <- lubridate::as_datetime(paste(Sys.Date(), '14:00'),
                               format = '%Y-%m-%d %H:%M', tz = timezone)
  st_tsts <- sum(as.integer(gsub(',','',tbls[[1]][1:2,2])))
  st_neg <- sum(as.integer(gsub(',', '', tbls[[1]][1:2,3])))
  st_css <- sum(as.integer(gsub(',', '', tbls[[1]][3,3])))
  d1 <- make_dat(state = state_name, tested = tbls[[1]][1,2],
                 cases = st_tsts, deaths = tbls[[2]][2,2],
                 update_date = ud, url = url, page = page_raw)
  d2 <- make_dat(state = state_name, page = page_raw,
                 county = gsub(' County', '', tbls[[5]][,1]),
                 cases = tbls[[5]][,2], update_date = ud,
                 url = url)
  out <- data.table::data.table(county = tbls[[4]][,1],
                                cases = tbls[[2]][, 2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'tennessee')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_texas <- function() {
  state_name <- "Texas"
  timezone <- 'America/Chicago'
  url <- 'https://www.dshs.state.tx.us/coronavirus/TexasCOVID19CaseCountData.xlsx'
  texas_xlsx <- tempfile(fileext = '.xlsx')
  download.file(url = url, texas_xlsx, 'curl', extra = c('--insecure'))
  county <- readxl::read_xlsx(texas_xlsx, sheet = 1, skip = 1,
                                col_names = TRUE)
  state <- county[nrow(county),]
  county <- county[-nrow(county),]
  update_date <- readxl::read_xlsx(texas_xlsx, sheet = 1, n_max = 1,
                                     col_names = FALSE)[1,1]
  tests <- readxl::read_xlsx(texas_xlsx, sheet = 2, skip = 1)
  tests <- tests[-3,]
  ud <- stringr::str_extract(update_date, '(?<=as of ).*(?= CST)')
  ud <- lubridate::as_datetime(paste(ud, '2020'), format = '%m/%d at %I %p %Y',
                               tz = timezone)
  ages <- readxl::read_xlsx(texas_xlsx, sheet = 3, skip = 1, n_max = 15)
  sex <- readxl::read_xlsx(texas_xlsx, sheet = 4, skip = 1,
                             n_max = 5)
  d1 <- make_dat(state = state_name, url = url, cases = county$Positive,
                 county = county$County, deaths = county$Fatalities,
                 update_date = ud)
  d2 <- make_dat(state = state_name, url = url, lab = tests$Location,
                 lab_tests = tests$No..of.People, update_date = ud)
  d3 <- make_dat(state = state_name, url = url, update_date = ud,
                 cases = state$Positive, deaths = state$Fatalities)
  d4 <- make_dat(state = state_name, url = url, update_date = ud,
                 age_range = ages$Age.Group, age_cases = ages$Count)
  d5 <- make_dat(state = state_name, url = url, sex = sex$Gender,
                 sex_counts = sex$Count, sex_percent = sex$Percentage,
                 update_date = ud)
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5), fill = TRUE)
  write_out(d, 'texas')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_utah <- function() {
  state_name <- 'Utah'
  timezone <- 'America/Denver'
  url <- 'https://coronavirus.utah.gov/case-counts/'
  url <- 'https://coronavirus-dashboard.utah.gov/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  print('No Data available without Selenium for Utah')

}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_vermont <- function() {
  state_name <- 'Vermont'
  timezone <- 'America/New_York'
  url <- 'https://vcgi.maps.arcgis.com/apps/opsdashboard/index.html#/6128a0bc9ae14e98a686b635001ef7a7'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  cases <- jsonlite::fromJSON('https://services1.arcgis.com/BkFxaEFNwHqX3tAw/arcgis/rest/services/VT_Counties_Cases/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  cases <- cases$features$attributes$value
  cnty <- jsonlite::fromJSON('https://services1.arcgis.com/BkFxaEFNwHqX3tAw/arcgis/rest/services/VT_Counties_Cases/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Cases%20desc&outSR=102100&resultOffset=0&resultRecordCount=25&cacheHint=true')
  c <- data.table::as.data.table(cnty$features$attributes)
  c[, CNTYNAME := snakecase::to_title_case(CNTYNAME)]
  c[, date := anytime::anytime(DateUpd/1000)]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases, update_date = unique(c[['date']]))
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = c[['CNTYNAME']], cases = c[['Cases']],
                 deaths = c[['Deaths']], update_date = c[['date']],
                 other = 'new_cases', other_value = c[['new_cases']])
  d3 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = c[['CNTYNAME']], update_date = c[['date']],
                 other = 'casesPer1000', other_value = c[['CasesPer10x']])
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'vermont')
  warning('vermont county data needs Selenium and picture recognition')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_virginia <- function() {
  state_name <- 'Virgina'
  print('Virginia scraping requires selenium')
}
#' @title      scrape washington
#' @description scrapes urls for washington
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_washington <- function() {
  state_name <- 'Washington'
  timezone <- 'America/Los_Angeles'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus/010101010100e803ab2663a90d0000210068747470733a2f2f72652e73656375726974792e66356161732e636f6d2f72652f'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  neg <- as.integer(gsub(',', '', tbls[[2]][1,2]))
  pos <- as.integer(gsub(',', '', tbls[[2]][2,2]))
  t_tests <- neg + pos
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[1]][1:nrow(tbls[[1]]) - 1,1],
                 cases = tbls[[1]][1:nrow(tbls[[1]]) - 1,2],
                 deaths = tbls[[1]][1:nrow(tbls[[1]]) - 1,3])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = pos, negative_tests = neg,
                 tested = t_tests)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'washington')
  invisible(d)
}
#' @title       scrape west virginia
#' @description scrapes urls for west virginia
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_west_virginia <- function() {
  state_name <- 'West Virgina'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  state_dat <- tbls[[4]][1,1]
  county_dat <- tbls[[4]][4,2]
  ud <- paste0(stringr::str_extract(
    state_dat, '(?<=Updated: )\\d{1,}/\\d{1,}/\\d{4}'), '12:00')
  ud <- lubridate::as_datetime(ud, format = '%m/%d/%Y %H:%M',
                               tz = timezone)
  state_dat <- gsub('\r\n', '', state_dat)
  st_cases <- stringr::str_extract(state_dat, '(?<=Positive Cases)\\d{1,}')
  st_negs <- stringr::str_extract(state_dat, '(?<=Negative Cases)\\d{1,}')
  st_deaths <- stringr::str_extract(state_dat, '(?<=Deaths)\\d{1,}')
  st_pending <- stringr::str_extract(state_dat, '(?<=Pending)\\d{1,}')
  d1 <- make_dat(state = state_name, cases = st_cases, negative_tests = st_negs,
                 deaths = st_deaths, pending_tests = st_pending, url = url,
                 page = page_raw)
  county_dat <- extract_county_number_to_df(strsplit(
    gsub('Counties with positive cases: ', '', tbls[[7]][[1]]), ',')[[1]])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = county_dat[,1],
                 cases = county_dat[,2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'west_virginia')
  invisible(d)
}
#' @title       scrape wisconsin
#' @description scrapes url for wisconsin
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wisconsin <- function() {
  state_name <- 'Wisconsin'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  county_url <- 'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=true&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=POSITIVE%20DESC&outSR=102100&resultOffset=0&resultRecordCount=1000'
  cj <- jsonlite::fromJSON(county_url)$features$attributes
  ud <- lubridate::as_datetime(paste(unique(cj$DATE), '14:00'),
                               format = '%m/%d/%Y %H:%M', tz = timezone)
  sj <- jsonlite::fromJSON(
    'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/2/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&resultType=none&distance=0.0&units=esriSRUnit_Meter&returnGeodetic=false&outFields=NEGATIVE%2CPOSITIVE%2CDEATHS%2CDATE&returnHiddenFields=false&returnGeometry=true&featureEncoding=esriDefault&multipatchOption=xyFootprint&maxAllowableOffset=&geometryPrecision=&outSR=&datumTransformation=&applyVCSProjection=false&returnIdsOnly=false&returnUniqueIdsOnly=false&returnCountOnly=false&returnExtentOnly=false&returnQueryGeometry=false&returnDistinctValues=false&cacheHint=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&having=&resultOffset=&resultRecordCount=&returnZ=false&returnM=false&returnExceededLimitFeatures=true&quantizationParameters=&sqlFormat=none&f=pjson&token=9khYV8ELTHK1P3ES04DSnCtAqj8bQtfI69A91SPr4vedIc8kWlNLppwF3IMBZvPKoyIQMpeQT7Az_YtQdKUQLpW6OC2W1w8BWm66NGn19cQFjAMh7eSZDLnhuRVkSqzYrFeDUtBPtLjPWvSMymC55d5GVLzh-nZq8fA8E-WYtxPwLZHiA8OZP2s6x17GkZ6au5yhBy-9eOkE8AXjFmqDt0ds-HGDWKZvt03XfnUxnpQ.'
    )$features$attributes
  page_raw <- rvest::html_text(page)
  cnty_raw <- as.character(cj)
  tbls <- rvest::html_table(page, fill = TRUE)[[1]]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = sj[,2], deaths = sj[,3], update_date = ud,
                 negative_tests = sj[,1])
  d2 <- make_dat(state = state_name, url = county_url, page = cnty_raw,
                 cases = cj$POSITIVE, deaths = cj$DEATHS, county = cj$NAME,
                 update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'wisconsin')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wyoming <- function() {
  state_name <- 'Wyoming'
  timezone <- 'America/Denver'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  ccc <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[2]/div/div/p[2]'))
  ud <- stringr::str_extract(tn, '^\\d{1,}\\/\\d{1,}\\/\\d{1,}')
  ud <- lubridate::as_datetime(paste(ud, '15'), format = '%m/%d/%y%H',
                               tz = timezone)
  st_pos <- stringr::str_extract(pos, '\\d{1,}')
  cc <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[3]/div[2]/div/div/p'
  ))
  wyoming_counties <- c('Albany', 'Big Horn', 'Campbell', 'Converse',
                        'Crook', 'Fremont', 'Goshen', 'Hot Springs',
                        'Johnnson', 'Laramie', 'Natrona', 'Niobrara',
                        'Park', 'Platte', 'Sheridan', 'Sublette',
                        'Sweetwater', 'Tenton', 'Uinta', 'Washakie',
                        'Weston')
  cregx <- paste0('(', paste0(wyoming_counties, collapse = '|'),
                  '): \\d{1,}')
  county_cases <- stringr::str_extract_all(ccc, cregx)[[1]]
  ccc <- strsplit(county_cases, ':', fixed = TRUE)
  counties <- c()
  cases <- c()
  for (p in ccc) {
    counties <- append(counties, p[1])
    cases <- append(cases, trimws(p[2], 'l'))
  }
  updated <- trimws(trimws(
    rvest::html_text(rvest::html_node(
      page,
      xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[1]/div[1]/div/p[1]'))
    ))
  ud <- as.POSIXct(paste(stringr::str_extract(
    updated, '.*(?= \\()'), '15:00'), format = '%m/%d/%y %H:%M',
    tz = timezone)
  labst <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[1]/div[1]/div/p[2]'
  ))
  lt <- strsplit(labst, 'Test')[[1]]
  tl <- strsplit(lt, ': ')
  labs = c('Wyoming Public Health Laboratory', 'CDC Lab', 'commercial labs')
  labtests <- data.table::data.table(
    labs = labs,
    tests = c(tl[[2]][2], tl[[2]][2], tl[[3]][2])
  )
  labtests[, tests := gsub(',', '', tests)]
  sdt <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[1]/div[2]/div/div/blockquote/p[2]'
  ))
  scases <- stringr::str_extract(sdt, '[0-9]+(\\.[0-9][0-9]?)?(?= lab)')
  sp <- stringr::str_extract(sdt, '[0-9]+(\\.[0-9][0-9]?)?(?= probabl)')
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = cases, county = counties, update_date = ud)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 lab = labtests[['labs']], lab_tests = labtests[['tests']])
  d3 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = scases, presumptive_positive = sp)
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'wyoming')
  invisible(d)
}

#' @title       scrape the hopkins data
#' @description scrapes the timeseries data from john hopkins's github
#' @return      a data.table ready for export
#' @export
scrape_hopkins_timeseries <- function() {
  url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv'
  dat <- as.data.table(read.csv(url))
  write_out(dat, 'hopkins_timeseries')
  invisible(dat)
}

#' @title       scrape hopkins daily reports once
#' @description scrape all hopkins reports
#' @return      a data.table ready for export
#' @export
scrape_hopkins_daily_once <- function() {
  date_trips <- c()
  urls <- c()
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  cur_month <- lubridate::month(Sys.Date())
  months <- as.character(seq(1, cur_month))
  for (month in months) {
    days <- lubridate::days_in_month(lubridate::month(as.integer(month)))[[1]]
    if (nchar(month) == 1) {
      char_month <- paste0('0', month)
      months[months == month] <- char_month
    } else {
      char_month <- month
    }
    for (day in seq(1, days)) {
      day <- as.character(day)
      if (nchar(day) == 1) {
        day <- paste0('0', day)
      }
      csv_date <- paste0(paste(char_month, day, '2020', sep = '-'), '.csv')
      date_trips <- c(date_trips, csv_date)
      urls <- c(urls, paste0(base_url, csv_date))
    }
  }
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  d <- make_dat(state = dat[['Province.State']],
                country = dat[['Country.Region']],
                provider = 'hopkins', url = urls,
                update_date = dat[['Last.Updated']],
                deaths = dat[['Deaths']],
                region = dat[['Country_Region']],
                cases = dat[['Confirmed']], recovered = dat[['Recovered']],
                lat = dat[['lat']])
  write_out(dat, 'hopkins_daily_once_raw')
  write_out(d, 'hopkins_daily_once')
  invisible(d)
}


#' @title       scrape the hopkins daily data
#' @description scrapes the current date for daily data
#' @return       a data.table ready for export
#' @export
scrape_hopkins_daily <- function() {
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  target <- paste0(format(Sys.Date(), format = '%m_%d_%Y'), '.csv')
  url <- paste0(base_url, target)
  dat <- as.data.table(read.csv(url))
  d <- make_dat(state = dat[['Province.State']],
                country = dat[['Country.Region']],
                provider = 'hopkins', url = urls,
                update_date = dat[['Last.Updated']],
                deaths = dat[['Deaths']],
                region = dat[['Country_Region']],
                cases = dat[['Confirmed']], recovered = dat[['Recovered']],
                lat = dat[['lat']])
  write_out(dat, 'hopkins_daily_raw')
  write_out(d, 'hopkins_daily')
  invisible(d)
}

#' @title       scrapes the tomquisel covid19 data once
#' @description the one off to grab all raw data from tomquisel data set
#' @return      a data.table ready for export
#' @export
scrape_tomquisel_once <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  start_date <- as.Date('2020-03-14')
  cur_date <- Sys.Date()
  valid_dates <- seq(start_date, cur_date, by = 'days')
  urls <- paste0(base_url, valid_dates, '.csv')
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  write_out(dat, 'tomq_once_raw')
  d <- make_dat(provider = 'tomquisel', state = dat[['State_Name']],
                county = dat[['County_Name']], cases = dat[['Confirmed']],
                deaths = dat[['Death']], other = 'Fatality_Rate',
                other_value = dat[['Fatality_Rate']],
                update_date = dat[['Last_Update']],
                lat = dat[['Latitude']], lon = dat[['Longitude']])
  write_out(d, 'tomquisel_once')
  invisible(d)
}

#' @title       scrapes the tomquisel data for today's data
#' @description gets the csv from the github repo daily
#' @return       a data.table ready for export
#' @export
scrape_tomquisel <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  cur_date <- Sys.Date()
  url <- paste0(base_url, cur_date, '.csv')
  dat <- data.table::as.data.table(read.csv(url))
  write_out(dat, 'tomq_raw')
  d <- make_dat(provider = 'tomquisel', state = dat[['State_Name']],
                county = dat[['County_Name']], cases = dat[['Confirmed']],
                deaths = dat[['Death']], other = 'Fatality_Rate',
                other_value = dat[['Fatality_Rate']],
                update_date = dat[['Last_Update']],
                lat = dat[['Latitude']], lon = dat[['Longitude']])
  write_out(d, 'tomquisel')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hattiesburg <- function() {
  update_time <- NULL
  url <- 'https://data.hattiesburgamerican.com/media/jsons/smpj/covid19_r2.json?v='
  page <- jsonlite::fromJSON(url)
  page_raw <- jsonlite::toJSON(page)
  raw <- data.table::as.data.table(page$features$properties)
  geo <- data.table::as.data.table(
    page$features$geometry[,-length(names(page$features$geometry))])
  coords <- page$features$geometry$coordinates
  dat <- data.table::as.data.table(cbind(raw, unlist_coordinates(coords)))
  names(dat) <- c('country', 'cases', 'deaths', 'recovered', 'active', 'unkown',
                  'update_time', 'something', 'lat', 'lon')
  write_out(dat, 'hattiesburg_raw')
  # ud <- unique(dat[['update_time']])
  # dummy_date <- as.integer(0)
  # class(dummy_date) <- c('POSIXlt', 'POSIXt')
  # dat[, update_date := ]
  # for (d in ud) {
  #   subdat <- dat[update_time == d,]
  #   repeats <- nrow(subdat)
  #   print(subdat)
  #   print(repeats)
  #   nrow(subdat)
  #   dat[udpate_time == d,
  #       update_date := rep(lubridate::as_datatime(update_time,
  #                                            format = '%B %d',
  #                                            tz = 'utc'), repeats)]
  # }
  d <- make_dat(provider = 'hattiesburg', url = url, country = dat[['country']],
                cases = dat[['cases']], recovered = dat[['recovered']],
                pending_tests = dat[['unknown']], other = 'active',
                other_value = dat[['active']],
                lat = dat[['lat']], lon = dat[['lon']])
  write_out(d, 'hattiesburg')
  invisible(d)
}


#' @title       scrape NYT counties
#' @export
scrape_nyt_counties <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties.csv'
  dat <- data.table::as.data.table(read.csv(
    url, stringsAsFactors = FALSE, strip.white = TRUE))
  # write_out(dat, 'nyt_counties_raw')
  dates <- data.table::data.table(date = unique(dat[['date']]))
  dates[, ud := anytime::anytime(paste(date, '17:00'))]
  dat <- data.table::merge.data.table(dat, dates, by = 'date', all.x = TRUE)
  d <- make_dat(provider = 'nyt', state = dat[['state']],
                update_date = dat[['ud']], url = url, county = dat[['county']],
                cases = dat[['cases']], deaths = dat[['deaths']],
                other = 'fips', other_value = dat[['fips']])
  write_out(d, 'nyt_counties')
  invisible(d)
}

#' @title       scrape NYT states
#' @export
scrape_nyt_states <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv'
  dat <- data.table::as.data.table(read.csv(
    url, stringsAsFactors = FALSE, strip.white = TRUE))
  # write_out(dat, 'nyt_states_raw')
  dates <- data.table::data.table(date = unique(dat[['date']]))
  dates[, ud := anytime::anytime(paste(date, '17:00'))]
  dat <- data.table::merge.data.table(dat, dates, by = 'date', all.x = TRUE)
  d <- make_dat(provider = 'nyt_states', state = dat[['state']],
                update_date = dat[['ud']], cases = dat[['cases']],
                deaths = dat[['deaths']])
  write_out(d, 'nyt_states')
  invisible(d)
}

scrape_ihme <- function() {
  url <- 'https://ihmecovid19storage.blob.core.windows.net/latest/ihme-covid19.zip'
  zip_file <- tempfile(fileext = '.zip')
  download.file(url, zip_file)
  zipdf <- unzip(zip_file)
  csv_file <- zipdf[grepl('.csv', zipdf)]
  dat <- fread(csv_file)
  d <- data.table::melt(dat[, -1], id.vars = c('location_name', 'date'),
                        variable.name = 'other', value.name = 'other_value')
  # write_out(dat, 'healthdata_raw')
  d <- make_dat(provider = 'ihme', state = d[['location_name']],
                update_date = as.Date(d[['date']]), other = d[['other']],
                other_value = d[['other_value']])
  write_out(d, 'ihme')
  invisible(dat)
}

scrape_dh <- function() {
  url <- 'https://opendata.arcgis.com/datasets/1044bb19da8d4dbfb6a96eb1b4ebf629_0.csv'
  d <- data.table::fread(url)
  d[, `:=`(OBJECTID = NULL,
           STATE_FIPS = NULL,
           CNTY_FIPS = NULL)]
  dm <- data.table::melt(d, id.vars = c('X', 'Y', 'COUNTY_NAME', 'STATE_NAME'),
                         variable.name = 'other', value.name = 'other_value')
  dat <- make_dat(provider = 'definitive_healthcare', url = url,
                  lat = d[['X']], lon = d[['Y']], other = dm[['other']],
                  other_value = dm[['other_value']])
  write_out(dat, 'definitive_healthcare')
  invisible(dat)
}

scrape_capacity_predictor <- function() {
  url <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/8DEEDC28EC7644C287092D35E2531332-0:0/views/14854958574850990019_6086303216675469576?csv=true'
  download.file(url, basename(url))
  states <- data.table::data.table(
    name = datasets::state.name,
    abb = datasets::state.abb
  )
  d <- data.table::as.data.table(read.csv(basename(url),
                                          fileEncoding = 'UTF-16', sep = '\t'))
  dm <- data.table::melt(d, id.vars = c('Case.Date', 'COUNTY', 'County.Name',
                                    'Fips', 'State'), variable.name = 'other',
                         value.name = 'other_value')
  dms <- data.table::merge.data.table(dm, states, by.x = 'State', by.y = 'abb')
  dms[, `:=`(State = NULL, state = name, name = NULL,
             COUNTY = stringr::str_trim(gsub('County', '', COUNTY,
                                             ignore.case = TRUE)))]
  d1 <- dms[!is.na(other_value),]
  dt <- make_dat(provider = 'capacity_predictor', url = url,
                 update_date = anytime::anytime(d1[['Case.Date']]),
                 state = d1[['state']], county = d1[['COUNTY']],
                 fips = d1[['Fips']], other = d1[['other']],
                 other_value = d1[['other_value']])
  write_out(dt, 'capacity_predictor')
}
