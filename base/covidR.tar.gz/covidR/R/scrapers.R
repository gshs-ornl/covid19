#' @title       Scrape the Alabama Website
#' @description Scrape the Alabama public health website for information about
#'               coronavirus
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR to do with url
scrape_alabama <- function() {
  state <- NULL
  state_name <- 'Alabama'
  timezone <- 'America/Chicago'
  # # parsed_url <- covidR::urls[state == state_name][['url']]
  # parse_url <- 'https://www.alabamapublichealth.gov/infectiousdiseases/2019-coronavirus.html'
  # page <- get_page(parse_url)
  # state_info <- rvest::html_text(rvest::html_node(page,
  #                                                 xpath = '//*[@id="navbar-example"]/p'))
  # #state_url <- 'https://www.wvtm13.com/article/coronavirus-map-alabama/31919956#'
  # # state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233180907/'
  # state_url <- 'https://e.infogram.com/api/live/data/368957735/1585233181585/'
  # # state_url <- paste('https://e.infogram.com/api/live/data/368965865/', ceiling(R.utils::currentTimeMillis.System())-18000, sep="")
  #   # county_url <- 'https://e.infogram.com/api/live/data/368965865/1584753987108/'
  # county_url <- 'https://e.infogram.com/api/live/data/368965865/1585233181585/'
  # st_death_url <- 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=CONFIRMED%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22DIED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  # st_deaths <- jsonlite::fromJSON(st_death_url)$features$attributes$value
  # st_pos_url <- 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=CONFIRMED%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22CONFIRMED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  # st_pos <- jsonlite::fromJSON(st_pos_url)$features$attributes$value
  # c_page <- jsonlite::fromJSON(county_url)
  # s_page <- jsonlite::fromJSON(state_url)
  # county <- as.matrix(jsonlite::fromJSON(county_url)$data)
  # state <- as.matrix(jsonlite::fromJSON(state_url)$data)
  # counties <- county[1:67]
  # c_cases <- county[70:135]
  # ud <- lubridate::as_datetime(c_page$updated, tz = timezone)
  # d2 <- unique(make_dat(state = state_name, url = state_url,
  #                tested = gsub(',', '', state[2]),
  #                deaths = st_deaths, page = s_page,
  #                cases = st_pos))
  # d1 <- make_dat(state = state_name, url = county_url, page = c_page,
  #               county = counties, cases = c_cases)
  # d <- rbindlist(list(d1, d2), fill = TRUE)
  url <- 'https://alpublichealth.maps.arcgis.com/apps/opsdashboard/index.html#/6d2771faa9da4a2786a509d82c8cf0f7'
  scj <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22CONFIRMED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  scdi <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22DIED%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  srd <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22REPORTED_DEATH%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  srt <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22LabTestCount%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  sic <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22CLN_ICU%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  svt <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22CLN_VENT%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  shc <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22HCW%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  lte <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22LTCF_Employee%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ltr <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22LTCF_Resident%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  sho <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22hospitalized%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ages <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=AgeGroup&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22AgeGroup_Counts%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ehn <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=Ethnicity&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Ethnicity_Counts%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  scs <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/2/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=Gender&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Gender_Counts%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  state_cases <- scj$features$attributes$value
  state_died_from_illness <- scdi$features$attributes$value
  state_deaths <- srd$features$attributes$value
  state_tested <- srt$features$attributes$value
  state_icu <- sic$features$attributes$value
  state_vent <- svt$features$attributes$value
  state_hcw <- shc$features$attributes$value
  ltce <- lte$features$attributes$value
  ltcr <- ltr$features$attribtues$value
  sthosp <- sho$features$attributes$value
  adf <- data.table::as.data.table(ages$features$attributes)
  dem <- data.table::as.data.table(ehn$features$attributes)
  sex <- data.table::as.data.table(scs$features$attributes)
  demo <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/3/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=Racecat&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Race_Counts%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  cd <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Dashboard_ReadOnly/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outSR=102100&resultOffset=0&resultRecordCount=68&cacheHint=true')
  udj <- jsonlite::fromJSON('https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/COV19_Public_Statewide_Summary2/FeatureServer/1?f=json')
  ud <- anytime::anytime(udj$editingInfo$lastEditDate/1000)
  cdd <- data.table::as.data.table(cd$features$attributes)
  page_raw <- paste0(as.character(scj), as.character(scdi), as.character(srd),
                     as.character(srt), as.character(sic), as.character(svt),
                     as.character(shc), as.character(lte), as.character(ltr),
                     as.character(ages), as.character(ehn), as.character(cd),
                     as.character(demo), collapse = '|')
  dev <- data.table::as.data.table(demo$features$attributes)
  d1 <- make_dat(state = state_name, url = url, cases = state_cases,
                 page = page_raw, other = 'Died from Illness',
                 tested = state_tested, icu = state_icu, hospitalized = sthosp,
                 other_value = state_died_from_illness, deaths = state_deaths,
                 update_date = ud
                 )
  d3 <- make_dat(state = state_name, url = url, other = 'On Ventilator',
                 page = page_raw,other_value = state_vent,
                 update_date = ud)
  d4 <- make_dat(state = state_name, url = url, other = 'Healthcare Workers Confirmed',
                 page = page_raw,other_value = state_hcw,
                 update_date = ud)
  d5 <- make_dat(state = state_name, url = url, page = page_raw,
                 other = 'Long-Term Care: Employee', other_value = ltce,
                 update_date = ud)
  d6 <- make_dat(state = state_name, url = url,
                 page = page_raw,other = 'Long-Term Care: Resident', other_value = ltcr,
                 update_date = ud)
  d7 <- make_dat(state = state_name, url = url, age_range = adf[['AgeGroup']],
                 age_cases = adf[['value']],
                 update_date = ud)
  d8 <- make_dat(state = state_name, url = url, page = page_raw, cases = dem$value,
                 other = 'Ethnicity', other_value = dem$Ethnicity,
                 update_date = ud)
  d9 <- make_dat(state = state_name, url = url, page = page_raw,
                 sex = sex[['Gender']], sex_counts = sex[['value']],
                 update_date = ud)
  d2 <- make_dat(state = state_name, url = url, county = cdd[['CNTYNAME']],
                 cases = cdd[['CONFIRMED']], deaths = cdd[['DIED']],
                 other = 'Reported Death', tested = cdd[['LabTestCount']],
                 other_value = cdd[['REPORTED_DEATH']], page = page_raw,
                 update_date = ud)
  d10 <- make_dat(state = state_name, url = url, page = page_raw,
                  other = 'Race', other_value = dev$Racecat, cases = dev$value,
                  update_date = ud)
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10),
                             fill = TRUE)
  write_out(d, 'alabama')
  invisible(d)
}

#' @title        Scrape the Alaskan URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR TO DO WITH 'make_dat', something about state_tests not being present. But data is correctly collected
scrape_alaska <- function() {
  state_name <- 'Alaska'
  timezone <- 'America/Anchorage'
  # urls <- covidR::urls[state == state_name][['url']]
  url <- 'http://dhss.alaska.gov/dph/Epi/id/Pages/COVID-19/monitoring.aspx'
  page <- xml2::read_html(trimws(url))
  page_raw <- rvest::html_text(page)
  sd <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="ctl00_PlaceHolderMain_PageContent__ControlWrapper_RichHtmlField"]/div[2]/div[1]'
  ))
  sds <- strsplit(sd, '\r\n\r\n', fixed = TRUE)[[1]]
  s_death <- stringr::str_extract(sds[2], '(?<=\\s{2}).*')
  s_hosp <- stringr::str_extract(sds[1], '(?<=\\s{2}).*')
  ud <- stringr::str_extract(page_raw, '(?<=Updated )\\w{1,} \\d{1,}, \\d{4,}')
  ud <- lubridate::as_date(paste(ud, '17'), tz = timezone,
                           format = '%B %d, %Y %H')
  tbls <- rvest::html_table(page, header = FALSE, fill = TRUE)
  cdat <- tbls[[1]][-1,]
  cdat <- cdat[-nrow(cdat),]
  sdat <- tbls[[1]][nrow(tbls[[1]]),]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = trimws(sdat[,6]), pending_tests = trimws(sdat[,5]),
                 update_date = ud, deaths = s_death, hospitalized = s_hosp)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = trimws(cdat[,6]),
                county = trimws(cdat[,1]),
                pending_tests = trimws(cdat[,5]),
                update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'alaska')
  invisible(d)
}

#' @title        Scrape the Arizona URLs
#' @description Alaska has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arizona <- function() {
  state <- NULL
  state_name <- 'Arizona'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- xml2::read_html(trimws(parse_url))
  access_time <- Sys.time()
  print('Arizona requires further development with Selenium')
}

#' @title        Scrape the Arkansas URLs
#' @description Arkansas has two URLs, one with the total cases, this script
#'              parses both URLs and returns a single data.table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
scrape_arkansas <- function() {
  state_name <- 'Arkansas'
  timezone <- 'America/Chicago'
  url <- 'https://www.healthy.arkansas.gov/programs-services/topics/novel-coronavirus'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  sd <- tbls[[3]]
  ud <- lubridate::as_datetime(
    gsub('a.m.', 'AM', gsub('p.m.', 'PM', names(sd)[1])),
    format = 'Updated as of %m/%d/%Y, %I:%M %p',
                  tz = timezone)
  stopifnot(!is.na(ud))  # make sure we grab an update date
  d1 <- make_dat(state = state_name, update_date = ud, url = url,
                 page = page_raw,
                 cases = gsub(',', '', sd[2,2]))
  d2 <- make_dat(state = state_name, update_date = ud, url = url,
                 page = page_raw,
                 lab = gsub(' positive test results', '', sd[3:4, 1]),
                 lab_positive = gsub(',', '', sd[3:4, 2]))
  md <- data.table::as.data.table(tbls[[4]])
  d3 <- make_dat(state = state_name, update_date = ud, url = url,
                 page = page_raw,
                 hospitalized = md[2, 2][[1]],
                 other = 'On Ventilator', other_value = md[3, 2][[1]])
  d4 <- make_dat(state = state_name,  update_date = ud, url = url,
                 page = page_raw, other = 'Total Nursing Home Residents',
                 other_value = md[3,2][[1]])
  d12 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = ud, other = tbls[[4]][2:6,1],
                  other_value = tbls[[4]][2:6,2])
  gd <- md[7,2][[1]]
  mpp <- strsplit(gsub('Male', '', gsub('\n\t\t\tFemale', '', gd, fixed = TRUE),
              fixed = TRUE), ' = ')[[1]][-1]
  mdd <- data.table::data.table(gender = c('Male', 'Female'),
                                percent = mpp)
  d5 <- make_dat(state = state_name,  update_date = ud, url = url,
                 page = page_raw, sex = mdd[['gender']],
                 sex_percent = mdd[['percent']])
  rd <- tbls[[4]][9,2]
  rdd <- strsplit(rd, '(: |\n\t\t\t)', perl = TRUE)[[1]]
  races <- rdd[seq(1, length(rdd), by = 2)]
  race_values <- gsub(',', '', rdd[seq(2, length(rdd), by = 2)])
  d6 <- make_dat(state = state_name,  update_date = ud, url = url,
                 page = page_raw, race = races, cases = race_values)
  url1 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22positive%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  pos_tests <- jsonlite::fromJSON(url1)$features$attributes$value
  url2 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22deaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  deaths <- jsonlite::fromJSON(url2)$features$attributes$value
  url3 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Recoveries%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  recovered <- jsonlite::fromJSON(url3)$features$attribtues$value
  url4 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22total_tests%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  tests <- jsonlite::fromJSON(url4)$features$attributes$value
  url5 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22positive%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  cases <- jsonlite::fromJSON(url5)$features$attributes$value
  url6 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22negative%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&resultType=standard&cacheHint=true'
  negative_tests <- jsonlite::fromJSON(url6)$features$attributes$value
  d7 <- make_dat(state = state_name, update_date = ud,
                 url = paste(url1, url2, url3, url4, url5, sep = '|'),
                 other = 'Positive Tests', other_value = pos_tests,
                 deaths = deaths, recovered = recovered, tested = tests,
                 cases = cases, negative_tests = negative_tests)
  url7 <- 'https://services.arcgis.com/PwY9ZuZRDiI5nXUB/arcgis/rest/services/ADH_COVID19_Positive_Test_Results/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=county_nam%20asc&outSR=102100&resultOffset=0&resultRecordCount=76&resultType=standard&cacheHint=true'
  cc <- data.table::as.data.table(jsonlite::fromJSON(url7)$features$attributes)
  d8 <- make_dat(state = state_name, url = url7, update_date = ud,
                 county = cc[['county_nam']], cases = cc[['positive']],
                 negative_tests = cc[['negative']],
                 pending_tests = cc[['pending']],
                 recovered = cc[['Recoveries']], active = cc[['active_cases']],
                 deaths = cc[['deaths']], tested = cc[['total_tests']])
  cl <- cc[,c('county_nam', 'lab_prvt', 'lab_pub')]
  d9 <- make_dat(state = state_name, url = url7, update_date = ud,
                 county = cl[['county_nam']], private_tests = cl[['lab_prvt']],
                 other = 'Public Tests', other_value = cl[['lab_pub']])
  ccm <- data.table::melt.data.table(cc[,-c('OBJECTID', 'fhwa_numbe',
                                            'positive', 'negative', 'pending',
                                            'Recoveries', 'deaths',
                                            'total_tests', 'lcase_name',
                                            'lab_prvt', 'lab_pub',
                                            'active_cases')],
                                     id.vars = c('county_nam'))
  d10 <- make_dat(state = state_name, url = url7, update_date = ud,
                 county = ccm[['county_nam']], other = ccm[['variable']],
                 other_value = ccm[['value']], region = 'LTC/Hospitalized')
  ar <- strsplit(tbls[[4]][8,2], '\n\t\t\t', fixed = TRUE)[[1]]
  arr <- unlist(strsplit(ar, ': ', fixed = TRUE))
  age_ranges <- data.table::data.table(age = arr[seq(1, length(arr), by = 2)],
                                       cases = arr[seq(2, length(arr), by = 2)])
  d11 <- make_dat(state = state_name, url = url, update_date = ud,
                  age_range = age_ranges[['age']],
                  age_cases = age_ranges[['cases']])
  hd <- md[2:4,]
  d12 <- make_dat(state = state_name, url = url, resolution = 'Hospitals',
                  update_date = ud, page = page_raw,
                  hospitalized = hd[1,2][[1]])
  d13 <- make_dat(state = state_name, url = url, update_date = ud,
                  page = page_raw,
                  resolution = 'LTC Facilities', other_value = hd[3,2][[1]],
                  other = 'Total Nursing Home Residents')
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11,
                                  d12, d13),
                             fill = TRUE)
  write_out(d, 'arkansas')
  invisible(d)
}

#' @title      scrape la times from california
#' @description scrapes data from the LA Times from the Case by county table
#' @return      a data.table ready for use or import into database
#' @importFrom data.table :=
#' @export
# ERROR TO DO WITH 'make_dat', something about state_tests not being present. But data is correctly collected
scrape_california <- function() {
  state <- NULL
  state_name <- 'California'
  timezone <- 'America/Los_Angeles'
  state_url <- 'https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/Immunization/ncov2019.aspx'
  spage <- get_page(state_url)
  s_raw <- rvest::html_text(spage)
  s_gender <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/ul[2]'))
  s_age <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/ul[1]'
  ))
  s_sex_v <- stringr::str_split(s_gender, 'cases')[[1]]
  sex_st <- strsplit(s_sex_v, ':')
  sex_dt <- data.table::data.table(
    sex = c(sex_st[[1]][1], sex_st[[2]][1], sex_st[[3]][1]),
    cases = c(as.integer(gsub(',', '', stringr::str_trim(sex_st[[1]][2]))),
              as.integer(gsub(',', '', stringr::str_trim(sex_st[[2]][2]))),
              as.integer(gsub(',', '', stringr::str_trim(sex_st[[3]][2]))))
  )
  s_age_v <- strsplit(stringr::str_split(
    s_age, 'cases')[[1]], ':', fixed = TRUE)
  age_dt <- data.table::data.table(
    age_range = c(s_age_v[[1]][1], s_age_v[[2]][1], s_age_v[[3]][1],
                  s_age_v[[4]][1], s_age_v[[5]][1]),
    age_cases = c(text_to_num(s_age_v[[1]][2]),
                  text_to_num(s_age_v[[2]][2]),
                  text_to_num(s_age_v[[3]][2]),
                  text_to_num(s_age_v[[4]][2]),
                  text_to_num(s_age_v[[5]][[2]]))
  )
  s_tot <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/p[3]'
  ))
  s_date <- anytime::anytime(stringr::str_extract(
    s_tot, '(?<=As of ).*(?=, there are)'))
  health_url <- covidR::urls[state == state_name][['url']][2]
  h_page <- get_page(health_url)
  htbls <- rvest::html_table(h_page, fill = TRUE)
  h_dem <- rvest::html_text(rvest::html_node(
    h_page, xpath = '//*[@id="WebPartWPQ12"]/div[1]/div[1]/ul[2]'
  ))
  cc <- data.table::as.data.table(htbls[[1]])
  # h_dem <- gsub('cases', '', h_dem, fixed = TRUE)
  dem <- strsplit(h_dem, split = 'cases',
                  fixed = TRUE)[[1]]
  dems <- gsub('Age', '', dem, fixed = TRUE)
  demos <- strsplit(dems, ':', fixed = TRUE)
  age_ranges = c()
  age_cases = c()
  for (v in demos) {
    age_ranges <- c(age_ranges, trimws(v[1]))
    age_cases <- c(age_cases, gsub('(\\s{1,}|,)', '', v[2], perl = TRUE))
  }
  timezone = 'America/Los_Angeles'
  scases <- gsub(',', '', rvest::html_text(rvest::html_node(
    spage, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[1]/p[1]'
  )), fixed = TRUE)
  sdeaths <- gsub(',', '', rvest::html_text(rvest::html_node(
    spage, xpath = '/html/body/article/div[1]/section[2]/div[1]/div[2]/p[1]'
  )))
  update_date <- rvest::html_text(rvest::html_node(
    spage, xpath = '//*[@id="WebPartWPQ4"]/div[1]/p[3]/text()'))
  sud <- anytime::anytime(
    stringr::str_extract(update_date, '(?<=As of ).*(?=, there)'),
    tz = timezone)
  st_tests <- stringr::str_extract(rvest::html_text(rvest::html_node(
    spage, xpath = '/html/body/article/div[3]/section[2]/p[2]'
  )), '(?<=total was ).*')
  st_tests <- stringr::str_extract_all(st_tests, '\\d{1,}')[[1]]
  st_tests <- paste0(st_tests, collapse = '')
  updated <- sud
  d2 <- make_dat(state = state_name, url = state_url, page = s_raw,
                 sex = sex_dt[['sex']], sex_counts = sex_dt[['cases']],
                 update_date = s_date)
  d3 <- make_dat(state = state_name, url = state_url, page = s_raw,
                 age_range = age_dt[['age_range']],
                 age_cases = age_dt[['age_cases']], update_date = s_date)
  d <- data.table::rbindlist(list(d2, d3),
                             fill = TRUE)
  write_out(d, 'california')
  invisible(d)
}

#' @title      scrape la times
#' @export
scrape_latimes <- function() {
  state_name <- 'California'
  la_url <- 'https://www.latimes.com/projects/california-coronavirus-cases-tracking-outbreak/'
  timezone <- 'America/Los_Angeles'
  la <- get_page(la_url)
  la_raw <- rvest::html_text(la)
  latbls <- rvest::html_table(la, fill = TRUE)
  laud <- gsub(' Pacific', '', convert_am_pm(rvest::html_text(rvest::html_node(
    la, xpath = '/html/body/article/header/p[2]/time'))), ignore.case = TRUE)
  laud <- lubridate::as_datetime(gsub('a.m.', 'AM', laud), tz = timezone,
                                 format = '%B %d, %I:%M %p')


  ctdat <- data.table::as.data.table(latbls[[1]])
  counties <- data.table::as.data.table(latbls[[2]])[[1]]
  county_regex <- paste0('(', paste0(counties, collapse = '|'), ')')
  names(ctdat)[1] <- 'county_str'
  ctdat[, county := stringr::str_extract(county_str, county_regex)]

  sdat <- data.table::as.data.table(latbls[[3]])
  states <- c(datasets::state.name, 'Puerto Rico')
  state_regex <- paste0('(', paste0(states, collapse = '|'), ')')
  names(sdat)[1] <- 'state_str'
  sdat[, state := stringr::str_extract(state_str, state_regex)]

  # sdat[, state := state_names]
  icutbl <- data.table::as.data.table(latbls[[5]])
  names(icutbl)[1] <- 'city'
  icutbl <- data.table::melt.data.table(icutbl[,-4],
                                        id.vars = c('city'))

  d1 <- make_dat(provider = 'latimes', url = la_url, page = la_raw,
                 update_date = laud, state = state_name,
                 deaths = ctdat[['Total Deaths']], cases = ctdat[['Total Cases']],
                 county = ctdat[['county']], other = 'Cases Per 100k',
                 other_value = ctdat[[3]])

  d2 <- make_dat(provider = 'latimes', url = la_url, page = la_raw,
                 update_date = laud, state = state_name,
                 deaths = ctdat[['Total Deaths']], cases = ctdat[['Total Cases']],
                 county = ctdat[['county']], other = 'Deaths Per 100k',
                 other_value = ctdat[[6]])

  d3 <- make_dat(provider = 'latimes', url = la_url, page = la_raw,
                 update_date = laud, state = sdat[['state']],
                 cases = sdat[['Total Cases']],
                 deaths = sdat[['Total Deaths']], other = 'Cases per 100k',
                 other_value = sdat[[3]])
  d4 <- make_dat(provider = 'latimes', url = la_url, page = la_raw,
                 update_date = laud, state = sdat[['state']],
                 cases = sdat[['Total Cases']],
                 deaths = sdat[['Total Deaths']], other = 'Deaths per 100k',
                 other_value = sdat[[6]])

  d5 <- make_dat(provider = 'latimes', url = la_url, page = la_raw,
                 update_date = laud, state = 'California', resolution = 'city',
                 region = icutbl[['city']], other = icutbl[['variable']],
                 other_value = icutbl[['value']])

  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5),
                             fill = TRUE)
  write_out(d, 'latimes')
  invisible(d)
}
#' @title      scrape colorado
#' @description scrapes data from the LA Times from the Case by county table
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_colorado <- function() {
  state_name <- 'Colorado'
  url <- "https://drive.google.com/drive/folders/11ulhC5FwnRhiKqxDl6_9PnSMOjCWnLPB/"
  tz <- "America/Denver"
  googledrive::drive_deauth()
  drive_folder <- googledrive::drive_ls(url)
  drive_folder <- drive_folder %>% dplyr::mutate(date = lubridate::as_date(stringr::str_extract(drive_folder[[1]], "(?<=covid19_case_summary_)[^.]+")))
  #drive_folder <- drop_na(drive_folder[['date']])
  file_ids <- drive_folder[grepl(max(drive_folder$name), drive_folder$name), 2][[1]] # get latest day data. Change to specific date if desired
  ud =  drive_folder[grepl(max(drive_folder$name), drive_folder$name),][['date']][[1]]
  raw <- read.csv(sprintf("https://docs.google.com/uc?id=%s&export=download", file_ids[[1]]))
  #for (i in 2:length(file_ids)){
  #  current_id <- file_ids[[i]]
  #  raw <- data.table::rbindlist(list(raw, read.csv(sprintf("https://docs.google.com/uc?id=%s&export=download", current_id))), fill=TRUE)
  #}

  ## Statewide data
  sep_data <- split(raw, raw$description) # Get data by description

  state_data <- split(sep_data[["State Data"]], sep_data[["State Data"]]$attribute)[['Statewide']]
  state_data <- state_data %>% tidyr::spread(metric, value) # Note not obvious what per 100,000 means

  d1 <- make_dat(state = state_name, update_date =  ud,
                 url = url, cases = state_data$Cases, deaths = state_data$Deaths,
                 tested = state_data$`People Tested`, hospitalized = state_data$Hospitalizations)

  ### Age data
  age_data <- sep_data[["COVID-19 in Colorado by Age Group"]] %>% dplyr::filter(attribute != 'Note')
  age_data <- age_data %>% tidyr::spread(metric, value) # Didn't use Percent of Population Colorado
  d2 <- make_dat(state = state_name, url = url, update_date = ud,
                 age_range = age_data[['attribute']],
                 age_percent = age_data[['Percent of Cases']],
                 age_deaths_percent = age_data[['Percent of Deaths']])

  age_data2 <- sep_data[["Cases of COVID-19 Reported in Colorado by Age Group, Hospitalization, and Outcome"]] %>%
    dplyr::filter(attribute != 'Note') %>%
    dplyr::mutate(ages = stringr::str_extract(attribute, "[:digit:]+-[:digit:]+"),
           status = stringr::str_extract(attribute, "(?<=, )[:alpha:]+[ ]*[:alpha:]*")) %>%
    tidyr::spread(status, value) %>%
    dplyr::mutate(ages = replace_na(ages, 'Unknown'),
           Deaths = replace_na(Deaths, 0),
           Hospitalized = replace_na(Hospitalized, 0)) %>%
    dplyr::group_by(ages) %>%
    dplyr::summarise(Deaths = sum(Deaths),
              Hospitalized = sum(Hospitalized))
  d3 <- make_dat(state = state_name, url = url, update_date = ud,
                 age_range = age_data2[['ages']],
                 age_deaths =  age_data2[['Deaths']],
                 age_hospitalized = age_data2[['Hospitalized']])


  race_data <- sep_data[["COVID-19 in Colorado by Race & Ethnicity"]] %>%
    dplyr::filter(metric == 'Percent of Deaths')
  d4 <- make_dat(state = state_name, url = url, update_date = ud,
                 race = race_data[['attribute']],
                 other = 'Percent of Deaths',
                 other_value = race_data[['value']])

  sex_data <- sep_data[["COVID-19 in Colorado by Sex"]] %>%
    tidyr::spread(metric, value)
  d5 <- make_dat(state = state_name, url = url, update_date = ud,
                 sex = sex_data[['attribute']],
                 sex_percent = sex_data$`Percent of Cases`,
                 other = 'Percentage of Deaths',
                 other_value= sex_data$`Percent of Deaths`)


  # county_cases <- sep_data[["Colorado Case Counts by County"]]
  # county_deaths <- sep_data[["Number of Deaths by County"]]
  # county_total_testing <- sep_data[["Total COVID-19 Tests Performed in Colorado by County"]]
  # county_cases_per100000 <- sep_data[["Case Rates Per 100,000 People in Colorado by County"]]
  # county_testing_per100000 <- sep_data[["Total Testing Rate Per 100,000 People in Colorado by County"]]
  #
  # case_status <- sep_data[["Case Status for Cases & Deaths"]]
  #
  # daily_serology <- sep_data[["Daily Serology Data From Clinical Laboratories"]]
  # labs <- sep_data[["Positivity Data from Clinical Laboratories"]]
  #
  # date_cases_illness_offset <- sep_data[["Cases of COVID-19 in Colorado by Date of Illness Onset"]]
  # date_cases <- sep_data[["Cases of COVID-19 in Colorado by Date Reported to the State"]]
  # date_cases_illness_offset_cumulative <- sep_data[["Cumulative Number of Cases of COVID-19 in Colorado by Date of Illness Onset"]]
  # date_cases_cumulative <- sep_data[["Cumulative Number of Cases of COVID-19 in Colorado by Date Reported to the State"]]
  # date_death <- sep_data[["Cumulative Number of Deaths From COVID-19 in Colorado by Date of Death"]]
  # date_death_illness_offset <- sep_data[["Cumulative Number of Deaths From COVID-19 in Colorado by Date of Illness"]]
  # date_death_cumulative <- sep_data[["Cumulative Number of Deaths From COVID-19 in Colorado by Date Reported to the State"]]
  # date_death_illness_offset_cumulative <- sep_data[["Cumulative Number of Hospitalized Cases of COVID-19 in Colorado by Date of Illness Onset"]]
  # date_hospital_cumulative <- sep_data[["Cumulative Number of Hospitalized Cases of COVID-19 in Colorado by Date Reported to the State"]]
  # date_death_number <- sep_data[["Number of Deaths From COVID-19 in Colorado by Date of Death"]]
  # date_death_number_per_day <- sep_data[["Number of Deaths From COVID-19 in Colorado by Date of Death - By Day"]]


  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5), fill = TRUE)
  write_out(d, 'colorado')
  invisible(d)
}

scrape_colorado_all <- function() {

}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_dc <- function() {
  state <- NULL
  state_name <- 'District of Columbia'
  timezone <- 'America/New_York'
  # parse_url <- 'https://coronavirus.dc.gov/release/coronavirus-data-update-march-'
  day <- lubridate::day(Sys.Date())
  # if (lubridate::hour(Sys.time()) >= 21) {
  #   parse_url <- paste0(parse_url, day)
  # } else {
  #   parse_url <- paste0(parse_url, day - 1)
  # }
  parse_url <- 'https://coronavirus.dc.gov/page/coronavirus-data'

  page_data <- readxl::read_xlsx("https://coronavirus.dc.gov/sites/default/files/dc/sites/coronavirus/page_content/attachments/COVID19_DCHealthStatisticsDataV2%20%282%29.xlsx")

  page_values <- page_data[,ncol(page_data)]
  names(page_values) <- page_data[,2]

  people_tested <- page_values["People tested overall"]
  confirmed_cases <- page_values["PHL positives"]+page_values["Commercial lab positives"]
  negative_cases <- page_values["PHL negatives"]+page_values["Commercial lab negatives"]
  deaths <- page_values["Number of deaths"]
  recovered <- page_values["People recovered"]

  other_names_and_values <- c(page_values[names(page_values)[10]], page_values[names(page_values)[11]], page_values[names(page_values)[12]], page_values[names(page_values)[13]])
  other_names <- toString(names(other_names_and_values))
  other_names_values <- toString(as.numeric(other_names_and_values))

  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  update_date <- lubridate::as_datetime(
    paste(lubridate::month(Sys.Date()), day, '2020', '20:30', sep = ' '),
                                        format = '%m %d %Y %H:%M',
                                        tz = timezone)
  # cases <- stringr::str_extract(page_raw, '(?<=case total to )\\d{1,}')

  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = confirmed_cases, deaths = deaths, tested = people_tested,
                negative_tests = negative_cases, recovered = recovered,
                update_date = update_date,
                other = other_names, other_value = other_names_values)
  write_out(d, 'dc')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_florida <- function() {
  state <- NULL
  state_name <- 'Florida'
  timezone <- 'America/New_York'
  parse_url <- 'https://fdoh.maps.arcgis.com/apps/opsdashboard/index.html#/8d0de33f260d444c852a615dc7837c86'
  dat <- jsonlite::fromJSON(parse_url)
  page_raw <- as.character(dat)
  fdat <- dat$features$attributes
  # florida datestamp nonsensical, make our own
  update_date <- make_access_time()
  d <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = fdat[['T_positive']], county = fdat[['County_1']],
                tested = fdat[['T_total']],
                negative_tests = fdat[['T_negative']],
                deaths = fdat[['FLandNonFLDeaths']],
                pending_tests = fdat[['T_pending']])
  write_out(d, 'florida')
  invisible(d)
}

#' @title      scrape Georgia
#' @description scrapes urls for Georgia
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_georgia <- function() {
  cases <- County <- Gender <- NULL
  state_name <- 'Georgia'
  timezone <- 'America/New_York'
  # parse_url <- covidr::urls[state == state_name][['url']]
  state_url <- 'https://d20s4vd27d0hk0.cloudfront.net/'
  parse_url <- 'https://d20s4vd27d0hk0.cloudfront.net/?initialWidth=569&amp;childId=covid19dashdph&amp;parentTitle=COVID-19%20Daily%20Status%20Report%20%7C%20Georgia%20Department%20of%20Public%20Health&amp;parentUrl=https%3A%2F%2Fdph.georgia.gov%2Fcovid-19-daily-status-report%22'
  page <- get_page(parse_url)
  state_page <- get_page(state_url)
  state_raw <- rvest::html_text(state_page)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  ud <- stringr::str_extract(page_raw, 'as of \\d{1,}\\/\\d{1,}\\/\\d{4} \\d{1,}:\\d{1,}:\\d{1,}')
  updated <- lubridate::as_datetime(ud,
                                        format = 'as of %m/%d/%Y %H:%M:%S',
                                        tz = timezone)
  gend_age <- data.table::as.data.table(tbls[[13]])
  names(gend_age) <- as.character(gend_age[1,])
  gend_age <- gend_age[-1,]
  gend_age[, `:=`(County = snakecase::to_title_case(County),
                  Gender = snakecase::to_title_case(Gender))]
  lab_df <- data.table::data.table(
    lab = tbls[[11]][-1,1],
    pos = sanitize_integer(tbls[[11]][-1,2]),
    test = sanitize_integer(tbls[[11]][-1,3])
  )
  tested <- sum(lab_df[['test']])
  sdat <- data.table::as.data.table(tbls[[9]])
  names(sdat) <- c('type', 'cases')
  sdat <- sdat[-1,]
  sdat[, cases := stringr::str_extract(cases, '\\d{1,}(?= )')]
  cdat <- data.table::as.data.table(tbls[[10]])
  names(cdat) <- as.character(cdat[1,])
  dem <- data.table::as.data.table(tbls[[12]])
  names(dem) <- as.character(dem[1,])
  dem <- dem[-1,]
  d1 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, tested = tested,
                 cases = sdat[1,2], hospitalized = sdat[2,2],
                 deaths = sdat[3,2])
  d2 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, age_cases = 1,
                 age_range = gend_age[['Age']], county = gend_age[['Gender']],
                 other = 'Underlying Conditions',
                 other_value = gend_age[['Underlying']])
  d3 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, county = cdat[,1], cases = cdat[,2])
  d4 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, lab = lab_df[['lab']],
                 lab_positive = lab_df[['pos']], lab_tests = lab_df[['test']])
  d5 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, other = 'Race',
                 other_value = dem[['Race']], cases = dem[['Cases']],
                 deaths = dem[['Deaths']])
  d6 <- make_dat(state = state_name, url = state_url, page = state_raw,
                 update_date = updated, other_value = dem[['Ethnicity']],
                 cases = dem[['Cases']], deaths = dem[['Deaths']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6), fill = TRUE)
  write_out(d, 'georgia')
  invisible(d)
}

#' @title      scrape Hawaii
#' @description scrapes urls for Hawaii
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hawaii <- function() {
  state <- NULL
  state_name <- 'Hawaii'
  timezone <- 'Pacific/Honolulu'
  parse_url <- covidR::urls[state == state_name][['url']]
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  cases <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[1]/dl'
  ))
  hosp <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[1]'
  ))
  death <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[2]'
  ))
  cases <- strsplit(cases, '\n', fixed = TRUE)[[1]]
  stc <- stringr::str_extract(cases[1], '(?<=Total cases: ).*(?=\\s\\()')
  sth <- stringr::str_extract(hosp, '(?<=Hospitalization: ).*(?=\\s\\()')
  std <- stringr::str_extract(death, '(?<=deaths: ).*(?=\\s\\()')
  stp <- stringr::str_extract(cases[5], '(?<=Pending: ).*(?=\\s\\()')
  ud <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[2]/div[1]/div/div[1]/div[2]/dl/dd[3]'
  ))
  ud <- lubridate::as_datetime(
    convert_am_pm(ud), format = 'Cumulative totals as of %I:%M%p on%B %d, %Y',
    tz = timezone)
  cc <- stringr::str_extract(cases[-c(1,6)], '^.*(?=\\sCounty:)')
  cn <- stringr::str_extract(cases[-c(1,6)], '(?<=County: ).*(?=\\s\\()')
  # update_date <- unique(names(table))
  # update_date <- convert_am_pm(stringr::str_extract(
  #   update_date, '(\\d{1,}:\\d{2}\\w{2} on \\w+ \\d{1,}, \\d{4})'))
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%i:%m%p on %b %d, %y',
  #                                       tz = timezone)
  # updated <- update_date
  # table <- table[c(-1, -2, -3),]
  # table <- table[1:nrow(table) - 1,]
  # names(table) <- c('county', 'cases')
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                cases = stc, hospitalized = sth, deaths = std,
                update_date = ud)
  d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 county = cc, cases = cn, update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'hawaii')
  invisible(d)
}

#' @title      scrape Idaho
#' @description scrapes urls for Idaho
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_idaho <- function() {
  county <- NULL
  state_name <- 'Idaho'
  timezone <- 'America/Denver'
  # parse_url <- covidR::urls[state == state_name][['url']]
  parse_url <- 'https://coronavirus.idaho.gov/'
  page <- get_page(parse_url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  county <- tbls[[1]][-nrow(tbls[[1]]),]
  ud <- rvest::html_text(rvest::html_node(page, xpath = '//*[@id="post-326"]/div/div[2]/div[1]/p[4]/sup'))
  ud <- stringr::str_extract(ud, '(?<=data updated at ).*(?=\\. State)')
  ud <- convert_am_pm(gsub(' MT', '', ud))
  ud <- lubridate::as_datetime(ud, format = '%I:%M %p, %m/%d/%Y',
                               tz = timezone)
  labs <- tbls[[2]]
  sdat <- tbls[[3]]
  # d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
  #                cases = tbls[[1]][18,3], deaths = tbls[[1]][18,4],
  #                hospitalized = tbls[[5]][1,2],
  #                state_tests = gsub(',', '', tbls[[2]][,1]),
  #                private_tests = gsub(',', '', tbls[[2]][,2]),
  #                age_range = tbls[[3]][,1], age_cases = tbls[[3]][,2],
  #                cases_male = tbls[[4]][2,2], cases_female = tbls[[4]][1,2])
  # d2 <- make_dat(state = state_name, url = parse_url, page = page_raw,
  #                county = tbls[[1]][,2], cases = tbls[[1]][,3],
  #                deaths = tbls[[1]][,4])
  d1 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 cases = county$Cases, county = county$County,
                 deaths = county$Deaths)
  d2 <- make_dat(state = state_name, cases = sdat[1,2], age_range = sdat[3:6,1],
                 age_cases = sdat[3:6,2], sex = sdat[8:9, 1],
                 sex_counts = sdat[8:9, 2], hospitalized = sdat[12, 2],
                 icu = sdat[14, 2], other = 'Healthcare Worker Cases',
                 other_value = sdat[12, 2])
  d3 <- make_dat(state = state_name, url = parse_url, page = page_raw,
                 lab = labs[[,1]], lab_tests = gsub(',', '', labs[[,2]]))
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'idaho')
  invisible(d)
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_louisiana <- function() {
  state <- NULL
  state_name <- 'Louisiana'
  # base_url <- 'http://ldh.la.gov/Coronavirus/'
  # url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Deaths%20desc%2CCases%20desc%2CParish%20asc&outSR=102100&resultOffset=0&resultRecordCount=65&cacheHint=true'
  # page <- jsonlite::fromJSON(url)
  # tbl <- page$features$attributes
  # d1 <- make_dat(state = state_name, url = url, county = tbl$Parish,
  #               cases = tbl$Cases, deaths = tbl$Deaths, lat = tbl$Latitude,
  #               lon = tbl$Longitude, fips = tbl$PFIPS)
  # tests_url <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  # td <- jsonlite::fromJSON(tests_url)
  # td <- td$features$attributes$value
  # cd <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Testing%20%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value2%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  # cd <- cd$features$attributes$value
  # counties <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=(Cases%20%3E%200)%20AND%20(PFIPS%20%3C%3E%200)%20AND%20(PFIPS%20%3C%3E%2099999)&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22count%22%2C%22onStatisticField%22%3A%22FID%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  # cs <- counties$features$attributes$value
  # cases <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  # cases <- cases$features$attributes$value
  # deaths <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Deaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  # st_cases <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish_2/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  # deaths <- deaths$features$attributes$value
  # d2 <- make_dat(state = state_name, url = base_url, tested = td + cd,
  #                counties = cs, deaths = cd,
  #                cases = st_cases$features$attributes$value,
  #                private_tests = cd, state_tests = td)
  # d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  cURL <- 'https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=true&spatialRel=esriSpatialRelIntersects&outFields=LDHH%2CParish%2CCases%2CDeaths%2CCommercial_Tests%2CState_Tests%2CFID&orderByFields=FID%20ASC&outSR=102100'
  cd <- jsonlite::fromJSON(cURL)
  cdd <- data.table::as.data.table(cd$features$attributes)
  ld <- data.table::melt.data.table(
    cdd[,-c('LDHH', 'Cases', 'Deaths', 'FID')], id.vars = 'Parish',
    variable.name = 'lab', value.name = 'tests')
  d1 <- make_dat(state = state_name, url = cURL, page = as.character(cd),
                 county = cdd$Parish, cases = cdd$Cases, deaths = cdd$Deaths)
  d2 <- make_dat(state = state_name, url = cURL, page = as.character(cd),
                 county = ld$Parish, lab = ld$lab, lab_tests = ld$lab)
  ca <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=(Cases%20%3E%200)%20AND%20(PFIPS%20%3C%3E%2099999)%20AND%20(PFIPS%20%3C%3E%200)&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22count%22%2C%22onStatisticField%22%3A%22FID%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  cr <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  dd <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=PFIPS%20%3C%3E%2099999&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Deaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  td <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22State_Tests%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ct <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Cases_by_Parish/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Commercial_Tests%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  st <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_2/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Age%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outSR=102100&resultOffset=0&resultRecordCount=1000&cacheHint=true')
  state_lab_tests <- td$features$attributes$value
  commercial_lab_tests <- td$features$attributes$value
  counties <- ca$features$attributes$value
  cases <- cr$features$attributes$value
  deaths <- dd$features$attributes$value
  d3 <- make_dat(state = state_name, url = cURL, page = as.character(ca),
                 cases = cases, counties = counties, deaths = deaths)
  std <- data.table::as.data.table(st$features$attributes)
  d4 <- make_dat(state = state_name, url = cURL, page = as.character(st),
                 age_cases = std[['Value']], age_deaths = std[['Value2']],
                 age_range = std[['Category']])
  sext <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/State_Level_Information_1/FeatureServer/0/query?f=json&where=Grouping%20%3D%20%27Gender%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=Category&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Value%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  se <- data.table::as.data.table(sext$features$attributes)
  d5 <- make_dat(state = state_name, url = cURL, page = as.character(sext),
                 sex = se[['Category']], sex_counts = se[['value']])
  ua <- jsonlite::fromJSON('https://services5.arcgis.com/O5K6bb5dZVZcTo5M/arcgis/rest/services/Louisiana_Vent_and_Bed_Report/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&groupByFieldsForStatistics=LDH_Region%2CCategory&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Bed%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  uad <- data.table::as.data.table(ua$features$attributes)
  uad <- uad[, LDHH := as.integer(gsub('Region ', '', LDH_Region))]
  ccl <- cdd[, c('LDHH', 'Parish')]
  d <- data.table::merge.data.table(uad, ccl, by = 'LDHH', all = TRUE,
                                    allow.cartesian = TRUE)
  vd <- d[!is.na(Category) | !is.na(LDHH),]
  uv_use <- vd[Category == 'In Use',]
  uv_ava <- vd[Category != 'In Use',]
  d6 <- make_dat(state = state_name, url = cURL, page = as.character(ua),
                 county = uv_use[['Parish']], other = 'Ventialltors In Use',
                 other_value = uv_use[['value']])
  d7 <- make_dat(state = state_name, url = cURL, page = as.character(ua),
                 county = uv_ava[['Parish']], other = 'Ventillators Available',
                 other_value = uv_ava[['value']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7), fill = TRUE)
  write_out(d, 'louisiana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maine <- function() {
  state <- NULL
  state_name <- 'Maine'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)

  update_date <- gsub('Updated: ', '', unique(tbls[[2]][1,1]))
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %y at %I:%M %p',
                                        tz = timezone)
  state_cases <- tbls[[2]]
  county_cases <- tbls[[3]][-1:-2,]
  d1 <- make_dat(state = state_name, url = url, county = county_cases[,1],
                 cases = county_cases[,2], page = page_raw,
                 recovered = county_cases[,3], update_date = update_date)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 resolution = 'state',
                 cases = gsub(',', '', state_cases[3,1]),
                 deaths = gsub(',','', state_cases[3,2]),
                 cases_male = tbls[[5]][2,3], cases_female = tbls[[5]][2,4],
                 negative_tests = gsub(',', '', state_cases[3,3]),
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'maine')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_maryland <- function() {
  print('requries selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_massachusetts <- function() {
  state <- NULL
  state_name <- 'Massachusetts'
  print('requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_michigan <- function() {
  state_name <- 'Michigan'
  timezone <- 'America/Chicago'
  url <-
    'https://www.michigan.gov/coronavirus/0,9753,7-406-98163-520743--,00.html'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE, header = FALSE)
  cd <- data.table::as.data.table(tbls[[1]])
  names(cd) <- c('county', 'cases', 'deaths')
  sd <- cd[nrow(cd),]
  cd <- cd[-nrow(cd),]
  update_date <- paste0(format(Sys.Date(),
                               format = '%Y-%m-%d'), ' 2:00 PM')
  ud <- lubridate::as_datetime(update_date, format = '%Y-%m-%d %I:%M %p',
                               tz = timezone)
  d1 <- make_dat(state = state_name, page = page_raw, url = url,
                 update_date = ud, county = cd[['county']],
                 cases = cd[['cases']],
                 deaths = cd[['deaths']])
  d2 <- make_dat(state = state_name, page = page_raw, url = url,
                 update_date = ud, cases = sd[['cases']],
                 deaths = sd[['deaths']])
  url5 <- 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173_99207---,00.html'
  page <- get_page(url5)
  page_raw <- rvest::html_text(page)
  tbl <- data.table::as.data.table(rvest::html_table(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[3]/div[2]/div[1]/div/div/table[1]'
  )))
  cd <- tbl
  cd <- cd[-nrow(tbl),]
  sd <- cd[nrow(tbl),]
  rd <- data.table::copy(cd)
  rdm <- data.table::melt.data.table(rd, id.vars = 'Date')
  sdm <- rdm[variable == 'Grand Total',]
  rdm <- rdm[variable != 'Grand Total',]
  d24 <- make_dat(state = state_name, url = url5, page = page_raw,
                  update_date = lubridate::as_datetime(paste(sdm[['Date']],
                                                             '12:00'),
                                                       format = '%d-%b %H:%M',
                                                       tz = timezone),
                  cases = sdm[['value']])
  d25 <- make_dat(state = state_name, url = url5, page = page_raw,
                  update_date = lubridate::as_datetime(paste(rdm[['Date']],
                                                             '12:00'),
                                         format = '%d-%b %H:%M',
                                         tz = timezone),
                  cases = rdm[['value']], region = rdm[['variable']])
  url2 <- 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173---,00.html'
  page <- get_page(url2)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, header = FALSE, trim = TRUE, fill = TRUE)
  sexd <- data.table::as.data.table(tbls[[4]])
  names(sexd) <- as.character(sexd[1,])
  sexd <- sexd[-1,]
  sexm <- data.table::melt.data.table(sexd, id.vars = 'Sex')
  agd <- data.table::as.data.table(tbls[[5]])
  names(agd) <- as.character(agd[1,])
  agd <- agd[-1,]
  agm <- data.table::melt.data.table(agd, id.vars = 'Age')
  raced <- data.table::as.data.table(tbls[[6]])
  names(raced) <- as.character(raced[1,])
  raced <- raced[-1,]
  ram <- data.table::melt.data.table(raced, id.vars = 'Race')
  eds <- data.table::as.data.table(tbls[[7]])
  names(eds) <- as.character(eds[1,])
  eds <- eds[-1,]
  edm <- data.table::melt.data.table(eds, id.vars = 1)
  ads <- data.table::as.data.table(tbls[[8]])
  names(ads) <- as.character(ads[1,])
  ads <- ads[-1,]
  adm <- data.table::melt.data.table(ads, id.vars = 1)
  dd <- data.table::as.data.table(tbls[[3]])
  d3 <- make_dat(state = state_name, url = url2, page = page_raw,
                 update_date = ud, region = rdm[['variable']],
                 cases = rdm[['value']], other = 'Onset Date',
                 other_value = rdm[['Date']])
  d4 <-  make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, cases = sd[1,2], deaths = sd[1,3])
  d17 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, other = paste('Deaths', dd[['X1']]),
                  other_value = dd[['X2']])
  d18 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, other = 'Fatality Rate',
                  other_value = tbls[[3]][1,2])
  d19 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, sex = sexm[['Sex']],
                  other = sexm[['variable']], other_value = sexm[['value']])
  d20 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, age_range = agm[['Age']],
                  other = agm[['variable']], other_value = agm[['value']])
  d21 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, race = ram[['Race']],
                  other = ram[['variable']], other_value = ram[['value']])
  d22 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, ethnicity = edm[[names(edm)[1]]],
                  other = edm[['variable']], other_value = edm[['value']])
  d23 <- make_dat(state = state_name, url = url2, page = page_raw,
                  update_date = ud, ethnicity = adm[[names(adm)[1]]],
                  other = adm[['variable']], other_value = adm[['value']])
  url3 <- 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173_99225---,00.html'
  page <- get_page(url3)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE, trim = TRUE)
  sl <- data.table::as.data.table(tbls[[1]])
  sl[, region := 'Michigan']
  r1 <- data.table::as.data.table(tbls[[2]])
  r1[, region := 'Region 1']
  r2 <- data.table::as.data.table(tbls[[3]])
  r2[, region := 'Region 2 North']
  r3 <- data.table::as.data.table(tbls[[4]])
  r3[, region := 'Region 2 South']
  r4 <- data.table::as.data.table(tbls[[5]])
  r4[, region := 'Region 3']
  r5 <- data.table::as.data.table(tbls[[6]])
  r5[, region := 'Region 5']
  r6 <- data.table::as.data.table(tbls[[7]])
  r6[, region := 'Region 6']
  r7 <- data.table::as.data.table(tbls[[8]])
  r7[, region := 'Region 7']
  r8 <- data.table::as.data.table(tbls[[9]])
  r8[, region := 'Region 8']
  stst <- data.table::rbindlist(list(r1, r2, r3, r4, r5, r6, r7, r8),
                                fill = TRUE)
  d7 <- make_dat(state = state_name, url = url3, page = page_raw,
                 update_date = lubridate::as_datetime(sl[['Date']],
                                                      format = '%m/%d/%Y',
                                                      tz = timezone),
                 tested = gsub(',', '', sl[['Total Tests']]),
                 cases = gsub(',', '', sl[['Positive Tests']]),
                 negative_tests = gsub(',', '', sl[['Negative Tests']]),
                 other = 'Percent Positive Tests',
                 other_value = sl[['% Positive Tests']])
  d8 <- make_dat(state = state_name, url = url3, page = page_raw,
                 update_date = lubridate::as_datetime(sl[['Date']],
                                                      format = '%m/%d/%Y',
                                                      tz = timezone),
                 cases = stst[['Positive Tests']],
                 negative_tests = stst[['Negative Tests']],
                 tested = stst[['Total Tests']], region = stst[['region']],
                 other = 'Percent Positive Tests',
                 other_value = stst[['% Positive Tests']])
  url4 <- 'https://www.michigan.gov/coronavirus/0,9753,7-406-98159-523641--,00.html'
  page <- get_page(url4)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  hdat <- data.table::as.data.table(tbls[[1]])
  names(hdat) <- snakecase::to_snake_case(names(hdat))
  names(hdat)[1] <- 'Regions'
  hd <- data.table::melt.data.table(hdat, id.vars = 'Regions')
  hdtot <- hd[variable == 'TOTAL',]
  rtot <- hd[variable != 'TOTAL',]

  # Not sure what is supposed to be happening in this block.
  hcdat <- data.table::as.data.table(tbls[[2]])
  hcd <- data.table::melt.data.table(hcdat, id.vars = 'HCC Region')
  rcd <- hcd[`HCC Region` != 'TOTAL',]
  scd <- hcd[`HCC Region` == 'TOTAL',]
  scd[`HCC Region` == '', `HCC Region` := 'Unk']

  t4 <- data.table::as.data.table(tbls[[3]])

  names(t4) <- snakecase::to_snake_case(names(t4))
  names(t4)[1] <- 'Region'
  t4[Region == '', Region := 'Unk']
  tcd <- data.table::melt.data.table(t4, id.vars = 'Region')
  stcd <- tcd[variable == 'Total',]
  rtcd <- tcd[variable != 'Total',]
  hf <- data.table::as.data.table(tbls[[4]])
  hfc <- hf[-nrow(hf),]
  hfs <- hf[nrow(hf)]
  d9 <- make_dat(state = state_name, url = url4, page = page_raw,
                 update_date = ud, other = hdtot[['Regions']],
                 other_value = hdtot[['value']])
  d10 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, region = rtot[['variable']],
                  other = rtot[['Regions']], other_value = rtot[['value']])
  d11 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, other = rcd[['HCC Region']],
                  region = rcd[['variable']], other_value = rcd[['value']])
  d12 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, other = scd[['HCC Region']],
                  other_value = scd[['value']])
  d13 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, region = rtcd[['variable']],
                  other = rtcd[['HCC Region']], other_value = rtcd[['value']])
  d14 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, other = stcd[['HCC Region']],
                  region = stcd[['variable']], other_value = stcd[['value']])
  d15 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, other = 'Facility County',
                  other_value = hfs[[names(hfs)[1]]])
  d16 <- make_dat(state = state_name, url = url4, page = page_raw,
                  update_date = ud, county = hfc[['County']],
                  other = 'Facility County', other_value = hfc[[names(hfc)[1]]])

  # Hmm this url doesn't give region data.
  # Nursing home data. I don't see a place to put this data in the make_dat function
  url = 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173-526911--,00.html'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)

  tbls <- rvest::html_table(page, trim = TRUE, fill = TRUE)
  region <- data.table::as.data.table(tbls[[2]])
  names(region) <- snakecase::to_snake_case(names(region))
  d26 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = ud, county = region[['county']],
                  cases = region[['total_cases']])
  cddm <- data.table::melt.data.table(region[,-'total_cases'],
                                      id.vars = 'county')
  d34 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = ud, county = cddm[['county']],
                  other = cddm[['variable']], other_value = cddm[['value']])

  lt <- data.table::as.data.table(rvest::html_table(rvest::html_node(
    page, xpath = '//*[@id="main"]/div[3]/table[3]'), header = FALSE))
  names(lt) <- c('region', 'cases')
  lt[, tbl_id := cumsum(!nzchar(lt[['region']]))]
  lt[cases == '--', cases := NA_integer_]
  lt <- lt[nzchar(region), ]
  lt_s <- split(as.data.frame(lt)[, -ncol(lt)], lt$tbl_id)
  lts <- list()
  for (i in 1:length(lt_s)) {
    dt <- data.table::as.data.table(lt_s[[i]])
    # dt[!startswith(region, 'ltc'), hosp := region]
    # dt[startswith(region, 'ltc'), county := gsub('ltc - ', '', region)]
    # cc <- dt[!is.na(county),][['county']]
    # dt[is.na(county), county := cc]
    dt[, num_cases := as.integer(cases)]
    # dt[, `:=`(region = null, cases = null)]
    # dtt <- dt[!is.na(hosp),]
    lts[[i]] <- dt
  }
  hc <- data.table::rbindlist(lts)
  d27 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = ud, county = hc[['county']],
                  cases = hc[['num_cases']], other = 'Long Term Care Facility',
                  other_value = hc[['hosp']])
  url <- 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173_99449---,00.html'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, trim = TRUE, fill = TRUE)
  rc <- data.table::melt.data.table(data.table::as.data.table(
    tbls[[1]]), id.vars = 'Date')
  d28 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = anytime::anytime(paste(rc[['Date']], '12:00')),
                  region = rc[['variable']],
                  other = 'Percent Affected', other_value = rc[['value']])
  rc <- data.table::melt.data.table(data.table::as.data.table(
    tbls[[2]]), id.vars = 'Date'
  )
  d29 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = anytime::anytime(paste(rc[['Date']], '12:00')),
                  age_range = rc[['variable']],
                  age_percent = rc[['value']])
  mc <- data.table::as.data.table(tbls[[3]])
  d28 <- make_dat(state = state_name, url = url, page = page_raw,
                  update_date = anytime::anytime(paste(mc[['Date']], '12:00')),
                  other = 'Percent Affected',
                  other_value = mc[['Michigan']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d7, d8, d9, d10, d11,
                                  d12, d13, d14, d15, d16, d17, d18, d19, d20,
                                  d21, d22, d23, d24, d25, d26, d27, d28, d29,
                                  d34),
                             fill = TRUE)
  write_out(d, 'michigan')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_minnesota <- function() {
  state_name <- 'Minnesota'
  url <- 'https://www.health.state.mn.us/diseases/coronavirus/situation.html'
  timezone <- 'America/Chicago'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  update_date <- stringr::str_extract(page_raw,
                                      '(?<=As of )\\w{1,} \\d{1,}, \\d{4}')
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  print('needs selenium for county results')
  state_cases <- as.integer(gsub(',', '',
                                 stringr::str_extract(page_raw,
                                                      '(?<=Positive: )\\d{1,}'))
                            )
  tested <- as.integer(gsub(',', '',
                            stringr::str_extract(page_raw,
                                                 '(?<=Lab: )\\d{1,}')))
  d <- make_dat(state = state_name, url = url, update_date = update_date,
                cases = state_cases, tested = tested)
  write_out(d, 'minnesota')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_mississippi <- function() {
  state_name <- 'Mississippi'
  page <- get_page('https://msdh.ms.gov/msdhsite/_static/14,0,420.html')
  page_raw <- rvest::html_text(page)
  cases <- rvest::html_node(page, xpath = '//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[2]/transform/div/div[3]/visual-modern/div/svg/g[1]/text/tspan')
  print('needs selenium')
}


#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_missouri <- function() {
  httr::set_config(httr::config(ssl_verifypeeer = 0L))
  state_name <- 'Missouri'
  timezone <- 'America/Chicago'
  # st_url <- covidR::urls[state == state_name][['url']]
  st_url <- 'https://health.mo.gov/living/healthcondiseases/communicable/novel-coronavirus/results.php'
  st_page <- get_page(st_url)
  st_page_raw <- rvest::html_text(st_page)
  tbls <- rvest::html_table(st_page, fill = TRUE)
  county <- tbls[[1]]
  county_deaths <- tbls[[2]]
  age <- tbls[[3]]
  sex <- tbls[[5]]
  total_cases <- sum(tbls[[4]][,2])
  deaths <- sum(tbls[[2]][,2])
  ud <- rvest::html_text(rvest::html_node(st_page, xpath = '//*[@id="main-content"]/p[5]'))
  ud <- convert_am_pm(strsplit(ud, '\r\n\\s{1,}')[[1]][1])
  updated <- lubridate::as_datetime(ud, format = 'As of %I:%M %p CT, %B %d',
                                    tz = timezone)
  d1 <- make_dat(state = state_name, url = st_url, page = st_page_raw,
                 cases = total_cases, update_date = updated,
                 deaths = deaths, age_range = age[,1], age_cases = age[,2],
                 sex = sex[,1], sex_counts = sex[,2],
                 pending_tests = tbls[[4]][4,2])
  d2 <- make_dat(state = state_name, url = url, page = st_page_raw,
                 county = county[,1], cases = county[,2],
                 #lab = names(county)[3:4],
                 #lab_positive = county[,3],
                 update_date = updated)
  d3 <- make_dat(state = state_name, url = st_url, page = st_page_raw,
                 county = county_deaths[,1], deaths = county_deaths[,2],
                 update_date = updated)
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'missouri')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_montana <- function() {
  state_name <- 'Montana'
  timezone <- 'America/Denver'
  tccr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Total%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  tcc <- tccr$features$attributes$value
  dr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalDeaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  deaths <- dr$features$attributes$value
  recr <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalRecovered%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  rec <- recr$features$attributes$value
  ttj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Total_Tests_Completed%20desc&outSR=102100&resultOffset=0&resultRecordCount=1&cacheHint=true')
  tt_tests <- ttj$features$attributes$Total_Tests_Completed
  mfj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_0_9%22%2C%22outStatisticFieldName%22%3A%22F_0_9%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_10_19%22%2C%22outStatisticFieldName%22%3A%22F_10_19%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_20_29%22%2C%22outStatisticFieldName%22%3A%22F_20_29%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_30_39%22%2C%22outStatisticFieldName%22%3A%22F_30_39%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_40_49%22%2C%22outStatisticFieldName%22%3A%22F_40_49%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_50_59%22%2C%22outStatisticFieldName%22%3A%22F_50_59%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_60_69%22%2C%22outStatisticFieldName%22%3A%22F_60_69%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_70_79%22%2C%22outStatisticFieldName%22%3A%22F_70_79%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_80_89%22%2C%22outStatisticFieldName%22%3A%22F_80_89%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_90_99%22%2C%22outStatisticFieldName%22%3A%22F_90_99%22%7D%2C%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22F_100%22%2C%22outStatisticFieldName%22%3A%22F_100%22%7D%5D&outSR=102100&cacheHint=true')
  fd <- data.table::data.table(
    sex = 'Female',
    age_range = gsub('F_', '', names(mfj$features$attributes)),
    age_cases = t(mfj$features$attributes[,1:length(names(mfj$features$attributes))])
  )
  hospj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22HospitalizationCount%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  ccj <- jsonlite::fromJSON('https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true')
  cc <- data.table::data.table(
    county = ccj$features$attributes$NAMELABEL,
    cases = ccj$features$attributes$Total,
    deaths = ccj$features$attributes$TotalDeaths,
    hosp = ccj$features$attributes$HospitalizationCount,
    rec = ccj$features$attributes$TotalRecovered
  )
  mdd <- ccj$features$attributes
  male_names <- stringr::str_extract_all(names(mdd), '^M\\_.*')
  male_names <- unlist(Filter(length, male_names))
  mddd <- mdd[,c(male_names)]
  md <- data.table::data.table(
    sex = 'Male',
    age_range = gsub('M_', '', names(mddd)),
    age_cases = colSums(mddd)
  )

  ud <- as.POSIXct(paste(paste(Sys.Date()), '10:00'), tz = timezone)

  d1 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Total%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 cases = tcc, page = as.character(tccr), update_date = ud)
  d2 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalDeaths%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 deaths = deaths, page = as.character(dr), update_date = ud)
  d3 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TotalRecovered%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true',
                 update_date = ud, recovered = rec, page = as.character(recr))
  d4 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/1/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Total_Tests_Completed%20desc&outSR=102100&resultOffset=0&resultRecordCount=1&cacheHint=true',
                 tested = tt_tests, page = as.character(ttj), update_date = ud)
  d5 <- make_dat(state = state_name, update_date = ud, sex = fd[,1],
                 age_range = fd[,2], age_cases = fd[,3])
  d6 <- make_dat(state = state_name, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22HospitalizationCount%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true',
                 update_date = ud, hospitalized = hospj$features$attributes$value,
                 page = as.character(hospj))
  d7 <- make_dat(state = state_name, update_date = ud, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true',
                 county = cc$county, cases = cc$cases, deaths = cc$deaths,
                 hospitalized = cc$hosp, recovered = cc$rec)
  d8 <- make_dat(state = state_name, update_date = ud, url = 'https://services.arcgis.com/qnjIrwR8z5Izc0ij/ArcGIS/rest/services/COVID_Cases_Production_View/FeatureServer/0/query?f=json&where=Total%20%3C%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=NewCases%20desc%2CNAMELABEL%20asc&outSR=102100&resultOffset=0&resultRecordCount=56&cacheHint=true',
                 sex = md$sex, age_range = md$age_range, age_cases = md$age_cases,
                 page = as.character(mdd))
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8), fill = TRUE)
  write_out(d, 'montana')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nebraska <- function() {
  state_name <- 'Nebraska'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name,][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  cases <- as.integer(stringr::str_extract(
    page_raw, '(?<=cases – )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  negative <- as.integer(stringr::str_extract(
    page_raw, '(?<= negative - )(\\d{1,}|\\d{1,},\\d{3})'
  ))
  update_date <- stringr::str_extract(
    page_raw, '(?<=Updated: )\\w{1,} \\d{1,}, \\d{4}'
  )
  update_date <- lubridate::as_datetime(update_date,
                                        format = '%B %d, %Y',
                                        tz = timezone)
  d <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases, negative_tests = negative,
                update_date = update_date)
  write_out(d, 'nebraska')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_nevada <- function() {
  state_name <- 'Nevada'
  timezone <- 'America/Los_Angeles'
  url <- 'http://dpbh.nv.gov/coronavirus/'
  url <- 'https://app.powerbigov.us/view?r=eyJrIjoiMjA2ZThiOWUtM2FlNS00MGY5LWFmYjUtNmQwNTQ3Nzg5N2I2IiwidCI6ImU0YTM0MGU2LWI4OWUtNGU2OC04ZWFhLTE1NDRkMjcwMzk4MCJ9'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  # tbl <- rvest::html_table(page)[[1]]
  # update_date <- lubridate::as_datetime(
  #   gsub('last updated ', '', tbl[2,1]), format = '%m/%d/%y, %i:%m %p',
  #   tz = timezone)
  # make_dat(state = state_name, url = url, page = page_raw,
  #          update_date = update_date, cases = tbl[3, 2],
  #          presumptive_positive = tbl[4, 2], negative_tests = tbl[5, 2],
  #          monitored = tbl[9,2])
  print('Nevada needs selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_hampshire <- function() {
  state <- NULL
  state_name <- 'New Hampshire'
  timezone <- 'America/New_York'
  url <- 'https://nh.gov/covid19/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- rvest::html_text(rvest::html_node(
      page, xpath = '//*[@id="bodycontainer"]/main/div[3]/section[1]/h4'
    ))
  ud <- lubridate::as_datetime(
    gsub('data updated as of ', '',
         gsub('(\\(|\\))', '', update_date, perl = TRUE), fixed = TRUE),
    format = '%B %d, %Y, %I:%M %p', tz = timezone)
  stopifnot(!is.na(ud))
  cases = as.integer(gsub(',', '', tbls[[1]][1,2]))
  recovered = as.integer(gsub(',', '', stringr::str_extract(
    tbls[[1]][2,2], '\\d{1,}(?= )')))
  deaths = as.integer(gsub(',', '', stringr::str_extract(
    tbls[[1]][3, 2], '\\d{1,}(?= )')))
  current_cases = as.integer(gsub(',', '', tbls[[1]][4, 2]))
  hospitalized = as.integer(gsub(',', '', stringr::str_extract(
    tbls[[1]][5, 2], '\\d{1,}(?= )')))
  current_hospitalizaed = as.integer(gsub(',', '', tbls[[1]][6,2]))
  negative = as.integer(gsub(',', '', tbls[[1]][7,2]))
  tests_submitted = as.integer(gsub(',', '', tbls[[1]][8,2]))
  pending = as.integer(gsub(',', '', tbls[[1]][9,2]))
  monitored = as.integer(gsub(',', '', tbls[[1]][10,2]))
  cd <- data.table::as.data.table(tbls[[2]])[-nrow(tbls[[2]]),]
  cd[, Cases := as.integer(gsub(',', '', Cases))]
  hillsborough <- sum(cd[grepl('Hillsborough', County),][['Cases']])
  hb <- data.table::data.table(County = 'Hillsborough', Cases = hillsborough)
  cd <- cd[!grepl('Hillsborough', County),]
  cd <- rbind(hb, cd)
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases,
                tested = tests_submitted, update_date = ud,
                recovered = recovered, deaths = deaths,
                current_cases = current_cases,
                hospitalized = hospitalized,
                current_hospitalizaed = current_hospitalizaed,
                negative_tests = negative,
                pending_tests = pending,
                monitored = monitored)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = cd[['County']],
                 cases = cd[['Cases']])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'new_hampshire')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @importFrom magrittr %>%
#' @export
scrape_new_jersey <- function() {
  state <- NULL
  state_name <- 'New Jersey'
  timezone <- 'America/New_York'
  # url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Counties/FeatureServer/0/query?f=json&returnGeometry=true&spatialRel=esriSpatialRelIntersects&geometry=%7B%22xmin%22%3A-8766409.899972958%2C%22ymin%22%3A5009377.085700976%2C%22xmax%22%3A-8140237.764260961%2C%22ymax%22%3A5635549.2214129735%2C%22spatialReference%22%3A%7B%22wkid%22%3A102100%7D%7D&geometryType=esriGeometryEnvelope&inSR=102100&outFields=*&outSR=102100&resultType=tile'
  # page <- jsonlite::fromJSON(url)
  # page_raw <- jsonlite::toJSON(page)
  # tbl <- data.table::as.data.table(page$features$attributes)
  # tbl[, county := snakecase::to_title_case(COUNTY)]
  # url2 <- 'https://maps.arcgis.com/sharing/rest/content/items/84737ef7f760486293b6afa536f028e0?f=json'
  # call_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/survey123_4b4d331a233d419abbcc52ab45158b56/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22max%22%2C%22onStatisticField%22%3A%22total_calls_%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true'
  # page <- jsonlite::fromJSON(url2)
  # county_data_url <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&resultOffset=0&resultRecordCount=25&cacheHint=true'
  # cd <- jsonlite::fromJSON(county_data_url)
  # url3 <- 'https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&outSR=102100&resultOffset=0&resultRecordCount=25&cacheHint=true'
  # ccd <- data.table::as.data.table(jsonlite::fromJSON(url3)$features$attributes)
  # # d1 <- make_dat(state = state_name, url = url, page = page_raw,
  # #               county = snakecase::to_title_case(cd$features$attributes$COUNTY),
  # #               cases = cd$features$attributes$TOTAL_CASES, deaths = cd$features$attributes$TOTAL_DEATHS,
  # #               update_date = ud)
  # # d2 <- make_dat(state = state_name)
  # vvd <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/nj_cases_time/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=ObjectId%2Ccases%2Cdate&orderByFields=date%20asc&resultOffset=0&resultRecordCount=2000&cacheHint=true')$features$attributes
  # ud <- max(anytime::anytime(vvd$date/1000))
  # d1 <- make_dat(state = state_name, url = url3, page = as.character(paste0(ccd, collapse = '')),
  #                county = snakecase::to_title_case(ccd[['COUNTY']]),
  #                cases = ccd[['TOTAL_CASES']], deaths = ccd[['TOTAL_DEATHS']],
  #                other = 'New Cases', other_value = ccd[['NEW_CASES']],
  #                update_date = ud)
  # d2 <- make_dat(state = state_name, url = url3, page = as.character(paste0(ccd, collapse = '')),
  #                county = snakecase::to_title_case(ccd[['COUNTY']]),
  #                other = 'New Deaths', other_value = ccd[['NEW_DEATHS']],
  #                update_date = ud)
  #
  # d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  url <- 'https://covid19.nj.gov/#live-updates'
  updj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0?f=json')
  ud <- anytime::anytime(updj$editingInfo$lastEditDate/1000)
  hospj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22TOTAL__Hospitalizations%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  critj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22COVID_Critical_Care%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  icuj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22COVID_Intensive_Care%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  medj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22COVID_Medical_Surgical%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  ventj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/Dashboard_Data/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Vented_Patients%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&cacheHint=true')
  cccj <- jsonlite::fromJSON('https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=TOTAL_CASES%20desc&outSR=102100&resultOffset=0&resultRecordCount=25&cacheHint=true')
  hospitalized <- hospj$features$attributes$value
  critical_care <- critj$features$attributes$value
  icu <- icuj$features$attributes$value
  medical_surgical <- medj$features$attributes$value
  ventilators_in_use <- ventj$features$attributes$value
  cc <- data.table::as.data.table(cccj$features$attributes)
  page_raw <- paste0(as.character(hospj), as.character(critj),
                     as.character(icuj), as.character(medj), as.character(cccj),
                     collapse = '|')
  d1 <- make_dat(state = state_name, update_date = ud, page = page_raw,
                 cases = sum(cc$TOTAL_CASES), deaths = sum(cc$TOTAL_DEATHS),
                 icu = icu, hospitalized = hospitalized,
                 other = 'Critical Care', other_value = critical_care)
  d2 <- make_dat(state = state_name, update_date = ud, page = page_raw,
                 other = 'Medical Surgical', other_value = medical_surgical)
  d3 <- make_dat(state = state_name, update_date = ud, page = page_raw,
                 other = 'Ventilators in use', other_value = ventilators_in_use)
  d4 <- make_dat(state = state_name, update_date = ud, page = page_raw,
                 cases = cc$TOTAL_CASES, deaths = cc$TOTAL_DEATHS,
                 county = snakecase::to_title_case(cc$COUNTY),
                 other = 'New Deaths', other_value = cc$NEW_DEATHS)
  d5 <- make_dat(state = state_name, update_date = ud, page = page_raw,
                 other = 'New Cases', other_value = cc$NEW_CASES,
                 county = snakecase::to_title_case(cc$COUNTY))
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5), fill = TRUE)
  write_out(d, 'new_jersey')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_new_mexico <- function() {
  state <- NULL
  state_name <- 'New Mexico'
  timezone <- 'America/Denver'
  url <- 'https://e7p503ngy5.execute-api.us-west-2.amazonaws.com/prod/GetPublicStatewideData'
  sdj <- jsonlite::fromJSON(url)
  sd <- sdj$data
  page_raw <- as.character(sdj)
  ud <- anytime::anytime(sd$updated/1000)
  cases = sd$cases
  tests = sd$tests
  hosp = sd$totalHospitalizations
  cur_hosp = sd$currentHospitalizations
  deaths = sd$deaths
  recovered = sd$recovered
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, cases = cases, tested = tests,
                 hospitalized = hosp, other = 'Current Hospitalizations',
                 other_value = cur_hosp, deaths = deaths, recovered = recovered)
  sex <- names(sd[11:13])
  sex_cases <- unlist(sd[sex])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, sex = sex, cases = sex_cases)
  ages <- names(sd)[15:24]
  age_cases <- unlist(sd[ages])
  d3 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, age_range = ages, age_cases = age_cases)
  race <- names(sd)[25:length(sd)]
  race_cases <- unlist(sd[race])
  d4 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, race = race, cases = race_cases)
  url <- 'https://e7p503ngy5.execute-api.us-west-2.amazonaws.com/prod/GetCounties'
  cdj <- jsonlite::fromJSON(url)
  page_raw <- as.character(cdj)
  cd <- cdj$data
  d4 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = cd$name, cases = cd$cases,
                 deaths = cd$deaths, lat = cd$lat, lon = cd$long,
                 tested = cd$tests)
  sm <- data.table::melt.data.table(data.table::as.data.table(
    cd[,c('name', '0-9', '10-19', '20-29', '30-39', '40-49', '50-59', '60-69',
          '70-79', '80-89', '90+')]), id.vars = 'name')
  d5 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = sm$name, age_range = sm$variable,
                 age_cases = sm$value)
  gm <- cd[, c('name', 'male', 'female')]
  d6 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = gm$name, cases_male = gm$male,
                 cases_female = gm$female)
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6), fill = TRUE)
  write_out(d, 'new_mexico')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_north_dakota <- function() {
  state_name <- 'North Dakota'
  print('ND has data in images, will need selenium and OCR to scrape')
}

#' @title      scrape Ohio
#' @description scrapes urls for Ohio
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_ohio <- function() {
  state <- NULL
  state_name <- 'Ohio'
  state_url <- 'https://coronavirus.ohio.gov/wps/portal/gov/covid-19/home'
  timezone <- 'America/New_York'
  page <- get_page(state_url)
  page_raw <- rvest::html_text(page)
  csv_url <- 'https://coronavirus.ohio.gov/static/COVIDSummaryData.csv'
  cd <- data.table::as.data.table(read.csv(csv_url,
                                           stringsAsFactors = FALSE,
                                           strip.white = TRUE))
  cd[, `:=`(Case.Count = as.integer(gsub(',', '', Case.Count)),
            Hospitalized.Count = as.integer(gsub(',', '', Hospitalized.Count)),
            Death.Count = as.integer(gsub(',','',Death.Count)))]
  ud <- max(anytime::anytime(cd[['Onset.Date']], tz = timezone), na.rm = TRUE)
  sd <- cd[nrow(cd),]
  cd <- cd[-nrow(cd),]
  sd_age <- cd[,.(cases = sum(Case.Count),
                  deaths = sum(Death.Count),
                  hospt = sum(Hospitalized.Count)), by = 'Age.Range']
  cd_cases <- cd[,.(case_sum = sum(Case.Count)), by = 'County']
  cd_deaths <- cd[,.(death_sum = sum(Death.Count)), by = 'County']
  cd_hospitalized <- cd[,.(hospitalized = sum(Hospitalized.Count)), by = 'County']
  age_range_cases <- cd[,.(age_cases = sum(Case.Count),
                           age_deaths = sum(Death.Count),
                           age_hosp = sum(Hospitalized.Count)), by = c('County',
                                                                'Age.Range')]
  age_range_sex_cases <- cd[,.(hosp = sum(Hospitalized.Count),
                               cases = sum(Case.Count),
                               deaths = sum(Death.Count)),
                            by = c('County', 'Age.Range', 'Sex')]
  age_range_hospitalized <- cd[, .(age_hosp = sum(Hospitalized.Count)),
                               by = c('County', 'Age.Range')]
  age_range_deaths <- cd[,.(age_death = sum(Death.Count)), by = 'County']
  sex_cases <- cd[, .(cases = sum(Case.Count),
                      death = sum(Death.Count),
                      hosp = sum(Hospitalized.Count)), by = 'Sex']
  scbc <- cd[, .(cases = sum(Case.Count),
                      death = sum(Death.Count),
                      hosp = sum(Hospitalized.Count)), by = c('Sex', 'County')]
  county_cases <- cd[,.(cases = sum(Case.Count),
                        death = sum(Death.Count),
                        hosp = sum(Hospitalized.Count)), by = 'County']
  icu <- as.integer(gsub(',', '', trimws(rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[1]/div[2]/div[1]/div'
  )))))
  median <- as.integer(gsub(',', '', rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="odx-main-content"]/article/section[2]/div/div[2]/div[2]/div[1]/div'
  ))))
  cndat <- cd[,.(cases = sum(Case.Count, na.rm = TRUE),
                 deaths = sum(Death.Count, na.rm = TRUE),
                 hosp = sum(Hospitalized.Count, na.rm = TRUE)),
              by = 'County']
  csadt <- cd[,.(cases = sum(Case.Count, na.rm = TRUE),
                 deaths = sum(Death.Count, na.rm = TRUE),
                 hosp = sum(Hospitalized.Count, na.rm = TRUE)),
              by = c('County', 'Sex', 'Age.Range', 'Onset.Date')]
  cddt <- cd[,.(deaths = sum(Death.Count, na.rm = TRUE)),
             by = c('County', 'Sex', 'Age.Range', 'Date.Of.Death')]
  cddt <- cd[Date.Of.Death != '',]
  d1 <- make_dat(state = state_name, url = csv_url, update_date = ud,
                 county = county_cases[['County']],
                 cases = county_cases[['cases']],
                 hospitalized = county_cases[['hosp']],
                 deaths = county_cases[['death']]
                 )
  d2 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 cases = gsub(',','', sd[['Case.Count']]), update_date = ud,
                 deaths = gsub(',', '', sd[['Death.Count']]),
                 hospitalized = gsub(',', '', sd[['Hospitalized.Count']]),
                 icu = icu, other = 'Median Age', other_value = median,
                 sex = sex_cases[['Sex']], sex_counts = sex_cases[['cases']])
  d3 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 sex = sex_cases[['Sex']], other = 'Sex Deaths',update_date = ud,
                 other_value = sex_cases[['death']])
  d4 <- make_dat(state = state_name, url = state_url, page = page_raw,
                 sex = sex_cases[['Sex']], other = 'Sex Hospitalized',update_date = ud,
                 other_value = sex_cases[['hosp']])
  d5 <- make_dat(state = state_name, url = csv_url, page = as.character(cd),
                 sex = scbc[['Sex']], county = scbc[['County']],update_date = ud,
                 sex_counts = scbc[['cases']])
  d6 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                 county = age_range_cases[['County']],
                 age_range = age_range_cases[['Age.Range']],
                 age_cases = age_range_cases[['age_cases']],
                 age_deaths = age_range_cases[['age_deaths']],
                 age_hospitalized = age_range_cases[['age_hosp']])
  d7 <- make_dat(state = state_name, url = csv_url, page = page_raw,
                 sex = scbc[['Sex']], county = scbc[['County']],update_date = ud,
                 other = 'Sex Deaths', other_value = scbc[['death']])
  d8 <- make_dat(state = state_name, url = csv_url, page = page_raw,
                 county = scbc[['County']], update_date = ud,
                 sex = scbc[['Sex']], other = 'Sex Hospitalized',
                 other_value = scbc[['hosp']])
  d9 <- make_dat(state = state_name, url = csv_url,
                 county = age_range_sex_cases[['County']],
                 age_range = age_range_sex_cases[['Age.Range']],
                 sex = age_range_sex_cases[['Sex']],update_date = ud,
                 cases = age_range_sex_cases[['cases']],
                 other = 'Sex Hospitalized',
                 other_value = age_range_sex_cases[['hosp']])
  d10 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                 county = age_range_sex_cases[['County']],
                 age_range = age_range_sex_cases[['Age.Range']],
                 sex = age_range_sex_cases[['Sex']],
                 cases = age_range_sex_cases[['cases']],
                 other = 'Sex Deaths',
                 other_value = age_range_sex_cases[['deaths']])
  d11 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                  age_range = sd_age[['Age.Range']],
                  age_cases = sd_age[['cases']],
                  age_deaths = sd_age[['deaths']],
                  age_hospitalized = sd_age[['hospt']])
  d12 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                  county = cndat[['County']], cases = cndat[['cases']],
                  deaths = cndat[['deaths']], hospitalized = cndat[['hosp']])
  d13 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                  county = csadt[['County']], sex = csadt[['Sex']],
                  age_range = csadt[['Age.Range']], other = 'Onset.Date',
                  other_value = csadt[['Onset.Date']], cases = csadt[['cases']],
                  deaths = csadt[['deaths']], hospitalized = csadt[['hosp']])
  d14 <- make_dat(state = state_name, url = csv_url,update_date = ud,
                  county = cddt[['County']], other = 'Date of Death',
                  other_value = cddt[['Date.Of.Death']])
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11,
                                  d12, d13, d14),
                             fill = TRUE)
  write_out(d, 'ohio')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oklahoma <- function() {
  state <- NULL
  state_name <- 'Oklahoma'
  timezone <- 'America/Chicago'
  url <- 'https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_county.csv' #covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  dat <- read.csv(url)
  ud <- lubridate::as_datetime(
    dat$ReportDate[1], #format = '%Y-%m-%d',
    tz = timezone)
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = dat$Cases, update_date = ud,
                 deaths = dat$Deaths, recovered = dat$Recovered)

  #update_date <- rvest::html_text(
  #  rvest::html_node(
  #    page,
  #    xpath = '/html/body/div[2]/main/div/div/div[5]/div[1]/div/div[5]/div/p[2]/em'
  #    ))
  #update_date <- stringr::str_extract(
  #  update_date,
  #  '\\d{4}-\\d{1,}-\\d{1,} at \\d{1,}:\\d{1,}\\s\\w{1,}')
  #update_date <- gsub(' at', '', update_date, fixed = TRUE)
  #update_date <- lubridate::as_datetime(update_date,
  #                                      format = '%Y-%m-%d %I:%M %p',
  #                                      tz = timezone)
  #tbls <- rvest::html_table(page)
  #state_tbl <- tbls[[1]]
  #county_tbl <- tbls[[5]]
  #state_cases <- state_tbl[1,2] + state_tbl[2,2]
  #state_negative <- state_tbl[3,2]
  #state_pending <- state_tbl[4,2]
  #state_hospitalized <- state_tbl[5,2]
  #state_deaths <- state_tbl[6,2]
  #d1 <- make_dat(state = state_name, url = url, page = page_raw,
  #               cases = state_cases, negative_tests = state_negative,
  #               pending_tests = state_pending, update_date = update_date,
  #               hospitalized = state_hospitalized, deaths = state_deaths,
  #               state_tests = tbls[[2]][1,2],
  #               private_tests = tbls[[2]][2,2] + tbls[[2]][3,2])
  #d2 <- make_dat(state = state_name, url = url, page = page_raw,
  #               cases = county_tbl[,2], county = county_tbl[,1],
  #               update_date = update_date)
  #d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d1, 'oklahoma')
  invisible(d1)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_oregon <- function() {
  state <- NULL
  state_name <- 'Oregon'
  timezone <- 'America/Los_Angeles'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  update_date <- unique(names(tbls[[1]]))
  update_date <- stringr::str_extract(
    update_date, '\\d{1,}/\\d{1,}/\\d{1,}, \\d{1,}:\\d{1,} \\w\\.\\w.')
  update_date <- gsub('a.m.', 'AM', update_date)
  update_date <- gsub('p.m.', 'PM', update_date)
  update_date <- lubridate::as_datetime(
    update_date, format = '%m/%d/%Y, %I:%M %p', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], update_date = update_date,
                 hospitalized = tbls[[4]][1,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[2]][,1], cases = tbls[[2]][,2],
                 deaths = tbls[[2]][,3], negative_tests = tbls[[2]][,4],
                 update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'oregon')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_pennsylvania <- function() {
  state_name <- 'Pennsylvania'
  timezone <- 'America/New_York'
  url <- 'https://www.health.pa.gov/topics/disease/coronavirus/Pages/Cases.aspx'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, header = TRUE, trim = TRUE, fill = TRUE)
  ud <- lubridate::as_datetime(convert_am_pm(stringr::str_extract(rvest::html_text(rvest::html_node(
   page, xpath = '//*[@id="ctl00_PlaceHolderMain_PageContent__ControlWrapper_RichHtmlField"]/p[1]/em[1]'
 )), '(?<=updated at ).*')), format = '%I:%M %p on %m/%d/%Y', tz = timezone)
 stopifnot(!is.na(ud))

 # Table 1: Case Counts, Deaths, and Negatives
 state_data <- data.table::as.data.table(tbls[[1]])
 d1 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                cases = state_data[[1]], deaths = state_data[[2]],
                negative_tests = state_data[[3]])

 # Table 2: Positive Cases by Age Range to Date
 state_ages <- data.table::as.data.table(tbls[[2]])
 d2 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                 age_range = state_ages[[1]],
                 age_percent = state_ages[[2]])

 # Table 3: Hospitalization Rates by Age Range to Date
 state_ages_hospital <- data.table::as.data.table(tbls[[3]])
 d3 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                age_range = state_ages_hospital[[1]],
                age_hospitalized_percent = state_ages_hospital[[2]]) # Good as of 4-28

 # Table 4: County Case Counts to Date
 county_data <- data.table::as.data.table(tbls[[4]])
 d4 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                county = county_data[[1]], deaths = county_data[[4]],
                negative_tests = county_data[[3]],
                cases = county_data[[2]])

 # Table 5: Case Counts and Deaths by Sex to Date
 sex_data <- data.table::as.data.table(tbls[[5]])
 d5 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                sex = sex_data[[1]], sex_counts = sex_data[[2]],
                sex_percent = sex_data[[3]],
                deaths = sex_data[[4]])

 # Table 6: Case Counts and Deaths by Race to Date
 race_data <- data.table::as.data.table(tbls[[6]])
 names(race_data) <- c('race', 'cases', 'percent', 'deaths')
 d6 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                race = race_data[['race']], cases = race_data[['cases']],
                deaths = race_data[['deaths']], other = 'Percent of Race Cases',
                other_value = race_data[['percent']])

 # Table 7: Case Counts by Region to Date
 region <- data.table::as.data.table(tbls[[7]])
 d7 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                region = region[['Region']], cases = region[['Positive']],
                negative_tests = region[['Negative']],
                inconclusive = region[['Inconclusive']])

 # Table 8: COVID-19 Cases Associated with Nursing Homes and Personal Care Homes to Date
 hospd <- data.table::as.data.table(tbls[[8]])
 hospd[hospd=="."]<-NA
 hospd <- data.table::melt.data.table(hospd, id.vars = 'Facility County')
 d8 <- make_dat(state = state_name, url = url, page = page_raw, update_date = ud,
                county = hospd[[1]], other = hospd[['variable']],
                other_value = hospd[['value']], resolution = 'Nursing Home')

 d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8), fill = TRUE)
 write_out(d, 'pennsylvania')
 invisible(d)
}

#' @title       scrape Puerto Rico
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_puerto_rico <- function() {
  state_name <- 'Puerto Rico'
  timezone <- 'Atlantic/Bermuda'
  url <- 'http://www.salud.gov.pr/Pages/coronavirus.aspx'
  # page <- get_page(url)
  # page_raw <- rvest::html_text(page)
  # tbls <- rvest::html_table(page, fill = TRUE)
  # tbl <- tbls[[1]]
  # update_date <- rvest::html_text(
  #   rvest::html_node(
  #     page, xpath = '//*[@id="WebPartWPQ6"]/div[1]/h3[2]'))
  # update_date <- gsub(')', '', gsub('de', '', gsub('\\s{1,}', '',
  #                                    gsub('(Datos al', '', update_date,
  #                                                         fixed = TRUE))))
  # update_date <- convert_month_language(update_date)
  # update_date <- lubridate::as_datetime(update_date,
  #                                       format = '%d%B%Y,%H:%M',
  #                                       tz = timezone)
  # d <- make_dat(state = state_name, url = url, page = page_raw,
  #               tested = tbl[3,2], cases = tbl[3,3],
  #               negative_tests = tbl[3,4], update_date = update_date,
  #               pending_tests = tbl[3,4])
  # write_out(d, 'puerto_rico')
  # invisible(d)
  warning('Puerto Rico requires selenium')
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_rhode_island <- function() {
  state <- NULL
  state_name <- 'Rhode Island'
  timezone <- 'America/New_York'
  googlesheets4::sheets_deauth()
  url <- "https://docs.google.com/spreadsheets/d/1n-zMS9Al94CPj_Tc3K7Adin-tN9x1RSjjx2UzJ4SV7Q/htmlview#gid=0"
  summary <- googlesheets4::sheets_read(url, "Summary")
  ud <- lubridate::as_datetime(names(summary)[[2]], format = '%m/%d/%Y', tz = timezone)

  municipal_data <- googlesheets4::sheets_read(url, "Municipality of Cases")
  municipal_data <- municipal_data[1:39,]
  county_data <- make_dat(state = state_name, url = url,  region = municipal_data[[1]],
                         cases = municipal_data[[2]], other = 'Cases Per 100k',
                         other_value = municipal_data[[3]], update_date = ud)

  state_summary_data <- make_dat(state = state_name, url = url, update_date = ud,
                                 cases = summary[[2]][[2]],
                                 negative_tests = summary[[2]][[4]],
                                 current_hospitalizations = summary[[2]][[8]],
                                 deaths = summary[[2]][[12]],
                                 hospitalized = summary[[2]][[6]],
                                 icu=summary[[2]][[9]],
                                 tested = summary[[2]][[5]])

  state_summary_vent <-make_dat(state = state_name, url = url, update_date = ud,
                                    other='Ventilators in use', other_value=summary[[2]][[10]])

  state_summary_new_data <-make_dat(state = state_name, url = url, update_date = ud,
                                    other='tracking', other_value='New data',
                                    cases = summary[[2]][[1]], deaths = summary[[2]][[11]],
                                    negative_tests = summary[[2]][[3]])

  demographics <- googlesheets4::sheets_read(url, "Demographics")

  sex_data <- demographics[2:4,]
  state_summary_sex_data <- make_dat(state = state_name, url = url, update_dat = ud,
                                     sex = sex_data[[1]], sex_counts = sex_data[[2]],
                                     sex_percent = sex_data[[3]])
  age_data <- demographics[6:17,]
  age_data[[1]][2] <- '10-19' # strange it auto read as a date.
  age_data <- age_data[1:11,]
  names(age_data) <- c('Age Range', 'Cases', 'Cases Percentage', 'Hospitalizations', 'Hospitalizations Percentage',
                       'Fatalities', 'Fatalities Percentage')
  age_data <- age_data %>% dplyr::mutate(`Cases Percentage`= sanitize_numeric(gsub('+\\D+','', `Cases Percentage`)), # xx
                                  `Hospitalizations Percentage`= sanitize_numeric(gsub('+\\D+','', `Hospitalizations Percentage`))/100, # .xx
                                  `Fatalities Percentage`= sanitize_numeric(gsub('+\\D+','', `Fatalities Percentage`))/100, # expects .xx
                                  `Cases` = gsub('+\\D+','', `Cases`),
                                  `Hospitalizations` = gsub('+\\D+','', Hospitalizations),
                                  `Fatalities` = gsub('+\\D+','', Fatalities))

  state_summary_age_data <- make_dat(state = state_name, url = url, update_dat = ud,
                                     age_range = age_data[['Age Range']], age_cases = age_data[['Cases']],
                                     age_percent = age_data[['Cases Percentage']],
                                     age_deaths = age_data[['Fatalities']], age_deaths_percent = age_data[['Fatalities Percentage']],
                                     age_hospitalized = age_data[['Hospitalizations']],
                                     age_hospitalized_percent = age_data[[5]])

  race_data <- demographics[19:25,]
  names(race_data)[[1]] <- 'race_str'
  race_regex <- "(Hispanic/Latinx|Black|White|Other|Multiple races|Unknown|Pending further information)"
  race_data <- race_data %>% dplyr::mutate(ethnicity = stringr::str_extract_all(`race_str`, race_regex))
  state_summary_race_data <- make_dat(state = state_name, url = url, update_dat = ud,
                                      ethnicity = race_data[['ethnicity']], cases = race_data[['Cases']],
                                      deaths = race_data[['Fatalities']],
                                      hospitalized = race_data[['Hospitalizations']]
                                     )

  daily_data <- googlesheets4::sheets_read(url, "Trends")
  state_summary_daily_data <- make_dat(state = state_name, url = url, update_date = daily_data$Date,
                                       cases = daily_data$`Total positive labs`,
                                       negative_tests = daily_data$`Total negative labs`,
                                       current_hospitalizations = daily_data$`Currently hospitalized`,
                                       deaths = daily_data$`Total deaths`,
                                       hospitalized = daily_data$`Cumulative hospital admissions`,
                                       tested = daily_data$`Total tested`)
  for (i in 1:length(daily_data[[1]])){
    temp_data = make_dat(state = state_name, url = url, update_date = daily_data$Date[[i]],
                         other='tracking', other_value='New data',
                         cases=daily_data$`New positive labs`[[i]],
                         deaths=daily_data$Deaths[[i]],
                         current_hospitalizations = daily_data$`New hospital admissions`[[i]])

    state_summary_daily_data <- data.table::rbindlist(list(state_summary_daily_data,temp_data), fill = TRUE)
  }


  LTC_data <- googlesheets4::sheets_read(url, "Long term care")
  assisted_living_data <- LTC_data[44:47,]
  LTC_data <- LTC_data[3:42,]
  LTC_data <- data.table::rbindlist(list(LTC_data, assisted_living_data), fill = TRUE)
  names(LTC_data) <- c('Data', 'Cases', 'Deaths')
  LTC_data <- LTC_data %>% dplyr::mutate(temp_region = stringr::str_extract_all(`Data`, "\\([^()]+\\)"),
                                  temp_name = stringr::str_extract_all(`Data`, "(.*)\\("),
                                  count_low = stringr::str_extract(`Cases`, "[:digit:]+"),
                                  count_high = stringr::str_extract(`Cases`, "(?<=to )[:digit:]+"),
                                  death_low = stringr::str_extract(`Deaths`, "[:digit:]+"),
                                  death_high = stringr::str_extract(`Deaths`, "(?<=to )[:digit:]+")) %>%
                           dplyr::mutate(Region = substring(temp_region, 2, nchar(temp_region) - 1),
                                  `Facility name` = substring(`temp_name`, 1, nchar(`temp_name`)-2))

  state_summary_ltc_high <- make_dat(state = state_name, url = url, update_date = ud,
                                    region = LTC_data$Region,
                                    cases = LTC_data$count_high, deaths = LTC_data$death_high,
                                    other='LTC facility (High)', other_value=LTC_data$Data,
                                    resolution = "Upper Bound")

  state_summary_ltc_low <- make_dat(state = state_name, url = url, update_date = ud,
                                    region = LTC_data$Region,
                                    cases = LTC_data$count_low, deaths = LTC_data$death_low,
                                    other='LTC facility', other_value=LTC_data$Data,
                                    resolution = "Lower Bound")

  d <- data.table::rbindlist(list(state_summary_data, county_data,
                                  state_summary_sex_data, state_summary_age_data,
                                  state_summary_vent, state_summary_new_data,
                                  state_summary_race_data, state_summary_ltc_high,
                                  state_summary_ltc_low, state_summary_daily_data), fill = TRUE)

  write_out(d, 'rhode_island')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_carolina <- function() {
  state_name <- 'South Carolina'
  url <- 'https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/monitoring-testing-covid-19'
  page <- get_page(url)
  raw_page <- rvest::html_text(page)
  county_url <- 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/Covid19_Cases_Centroid_SharingView/FeatureServer/0/query?f=json&where=Confirmed%20%3E%200&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Confirmed%20desc&resultOffset=0&resultRecordCount=1000&cacheHint=true'
  page <- jsonlite::fromJSON(county_url)
  cdat <- page$features$attributes
  update_date <- anytime::anytime(cdat[['Date_']]/1000)
  # tbls <- rvest::html_table(page)
  # cdat <- jsonlite::fromJSON(county_url)$features$attributes
  # d1 <- make_dat(state = state_name, url = url, page = raw_page,
  #               update_date = update_date, negative_tests = tbl[1,2],
  #               cases = tbl[2,2])
  d <- make_dat(state = state_name, url = url, page = raw_page, county = cdat$NAME,
                cases = cdat$Confirmed, recovered = cdat$Recovered,
                deaths = cdat$Death, lat = cdat$Lat, lon = cdat$Long_,
                active = cdat$Active, update_date = update_date)
  write_out(d, 'south_carolina')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_south_dakota <- function() {
  state <- NULL
  state_name <- 'South Dakota'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  update_date <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="content_block"]/p[5]/text()[2]'))
  ud <- convert_am_pm(gsub('\\s', '', update_date, perl = TRUE))
  ud <- gsub('Lastupdated:', '', ud, fixed = TRUE)
  update_date <- lubridate::as_datetime(
    ud, format = '%I:%M%p;%B%d,%Y', tz = timezone
  )
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[1]][1,2], negative_tests = tbls[[1]][2,2],
                 pending_tests = tbls[[1]][3,2], deaths = tbls[[2]][2,2],
                 update_date = update_date, resolution = 'state',
                 recovered = tbls[[2]][3,2])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = tbls[[3]][-8, ][,2], county = tbls[[3]][-8,][,1],
                 resolution = 'county', update_date = update_date)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'south_dakota')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_tennessee <- function() {
  state <- NULL
  state_name <- 'Tennessee'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page)
  ud <- lubridate::as_datetime(paste(Sys.Date(), '14:00'),
                               format = '%Y-%m-%d %H:%M', tz = timezone)
  st_tsts <- sum(as.integer(gsub(',','',tbls[[1]][1:2,2])))
  st_neg <- sum(as.integer(gsub(',', '', tbls[[1]][1:2,3])))
  st_css <- sum(as.integer(gsub(',', '', tbls[[1]][3,3])))
  d1 <- make_dat(state = state_name, tested = tbls[[1]][1,2],
                 cases = st_tsts, deaths = tbls[[2]][2,2],
                 update_date = ud, url = url, page = page_raw)
  d2 <- make_dat(state = state_name, page = page_raw,
                 county = gsub(' County', '', tbls[[5]][,1]),
                 cases = tbls[[5]][,2], update_date = ud,
                 url = url)
  out <- data.table::data.table(county = tbls[[4]][,1],
                                cases = tbls[[2]][, 2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'tennessee')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_texas <- function() {
  state_name <- "Texas"
  timezone <- 'America/Chicago'
  url <- 'https://www.dshs.state.tx.us/coronavirus/TexasCOVID19CaseCountData.xlsx'
  texas_xlsx <- tempfile(fileext = '.xlsx')
  download.file(url = url, texas_xlsx, 'curl', extra = c('--insecure'))
  county <- readxl::read_xlsx(texas_xlsx, sheet = 1, skip = 1,
                                col_names = TRUE)
  state <- county[nrow(county),]
  county <- county[-nrow(county),]
  update_date <- readxl::read_xlsx(texas_xlsx, sheet = 1, n_max = 1,
                                     col_names = FALSE)[1,1]
  trends <- readxl::read_xlsx(texas_xlsx, sheet = 2, skip = 2)
  recov <- readxl::read_xlsx(texas_xlsx, sheet = 3, skip = 1, n_max = 1)
  labs <- readxl::read_xlsx(texas_xlsx, sheet = 4, skip = 1, n_max = 2)
  hosp <- readxl::read_xlsx(texas_xlsx, sheet = 5, skip = 1, n_max = 6)
  ages <- readxl::read_xlsx(texas_xlsx, sheet = 6, skip = 1, n_max = 13)
  gend <- readxl::read_xlsx(texas_xlsx, sheet = 7, skip = 1, n_max = 3)
  race <- readxl::read_xlsx(texas_xlsx, sheet = 8 , skip = 1, n_max = 8)
  deaths_age <- readxl::read_xlsx(texas_xlsx, sheet = 9, skip = 1, n_max = 13)
  deaths_sex <- readxl::read_xlsx(texas_xlsx, sheet = 10, skip = 1, n_max = 5)
  deaths_race <- readxl::read_xlsx(texas_xlsx, sheet = 11, skip = 1, n_max = 8)
  ud <- stringr::str_extract(update_date, '(?<=as of ).*(?= CST)')
  ud <- lubridate::as_datetime(paste(ud, '2020'),
                               format = '%m/%d at %I:%M %p %Y',
                               tz = timezone)
  names(trends) <- snakecase::to_snake_case(names(trends))
  d1 <- make_dat(state = state_name, url = url, cases = county$Positive,
                 county = county$County, update_date = ud,
                 deaths = county$Fatalities)
  d2 <- make_dat(state = state_name, url = url, cases = state$Positive,
                 deaths = state$Fatalities, update_date = ud)
  d3 <- make_dat(state = state_name, url = url, update_date = trends$date,
                 cases = trends$cumulative_cases,
                 deaths = trends$cumulative_fatalities,
                 other = 'Daily New Cases', other_value = trends$daily_new_cases)
  d4 <- make_dat(state = state_name, url = url, update_date = trends$date,
                 other = 'Daily New Deaths',
                 other_value = trends$daily_new_fatalities)
  d5 <- make_dat(state = state_name, url = url, update_date = ud,
                 recovered = recov[1,1])
  d6 <- make_dat(state = state_name, url = url, update_date = ud,
                 lab = labs$Location, lab_tests = labs$Count)
  d7 <- make_dat(state = state_name, url = url, update_date = ud,
                 other = hosp$`Hospital data`, other_value = hosp$Count)
  d8 <- make_dat(state = state_name, url = url, update_date = ud,
                 age_range = ages$Age, age_cases = ages$Count,
                 age_percent = ages$Percentage)
  d9 <- make_dat(state = state_name, url = url, update_date = ud,
                 sex = gend$Gender, sex_counts = gend$Count,
                 sex_percent = gend$Percentage)
  d10 <- make_dat(state = state_name, url = url, update_date = ud,
                  other = 'Race', other_value = race$`Race/Ethnicity`,
                  cases = race$Count)
  d11 <- make_dat(state = state_name, url = url, update_date = ud,
                  age_range = deaths_age$Age, age_deaths = deaths_age$Count,
                  age_deaths_percent = deaths_age$Percentage)
  d12 <- make_dat(state = state_name, url = url, update_date = ud,
                  sex = deaths_sex$Gender, deaths = deaths_sex$Count,
                  other_value = deaths_sex$Percentage,
                  other = 'Death Percent by Gender')
  d13 <- make_dat(state = state_name, url = url, update_date = ud,
                  deaths = deaths_race$Count, other = 'Race',
                  other_value = deaths_race$`Race/Ethnicity`)
  d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11,
                                  d12, d13), fill = TRUE)
  write_out(d, 'texas')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_utah <- function() {
  state_name <- 'Utah'
  timezone <- 'America/Denver'
  url <- 'https://coronavirus.utah.gov/case-counts/'
  url <- 'https://coronavirus-dashboard.utah.gov/'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  print('No Data available without Selenium for Utah')

}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_vermont <- function() {
  state_name <- 'Vermont'
  timezone <- 'America/New_York'
  url <- 'https://vcgi.maps.arcgis.com/apps/opsdashboard/index.html#/6128a0bc9ae14e98a686b635001ef7a7'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  cases <- jsonlite::fromJSON('https://services1.arcgis.com/BkFxaEFNwHqX3tAw/arcgis/rest/services/VT_Counties_Cases/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Cases%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&outSR=102100&cacheHint=true')
  cases <- cases$features$attributes$value
  cnty <- jsonlite::fromJSON('https://services1.arcgis.com/BkFxaEFNwHqX3tAw/arcgis/rest/services/VT_Counties_Cases/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=Cases%20desc&outSR=102100&resultOffset=0&resultRecordCount=25&cacheHint=true')
  c <- data.table::as.data.table(cnty$features$attributes)
  c[, CNTYNAME := snakecase::to_title_case(CNTYNAME)]
  c[, date := anytime::anytime(DateUpd/1000)]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                cases = cases, update_date = unique(c[['date']]))
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = c[['CNTYNAME']], cases = c[['Cases']],
                 deaths = c[['Deaths']], update_date = c[['date']],
                 other = 'new_cases', other_value = c[['new_cases']])
  d3 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = c[['CNTYNAME']], update_date = c[['date']],
                 other = 'casesPer1000', other_value = c[['CasesPer10x']])
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'vermont')
  warning('vermont county data needs Selenium and picture recognition')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_virginia <- function() {
  state_name <- 'Virgina'
  print('Virginia scraping requires selenium')
}
#' @title      scrape washington
#' @description scrapes urls for washington
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_washington <- function() {
  state_name <- 'Washington'
  timezone <- 'America/Los_Angeles'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus'
  url <- 'https://www.doh.wa.gov/Emergencies/Coronavirus/010101010100e803ab2663a90d0000210068747470733a2f2f72652e73656375726974792e66356161732e636f6d2f72652f'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  neg <- as.integer(gsub(',', '', tbls[[2]][1,2]))
  pos <- as.integer(gsub(',', '', tbls[[2]][2,2]))
  t_tests <- neg + pos
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 county = tbls[[1]][1:nrow(tbls[[1]]) - 1,1],
                 cases = tbls[[1]][1:nrow(tbls[[1]]) - 1,2],
                 deaths = tbls[[1]][1:nrow(tbls[[1]]) - 1,3])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = pos, negative_tests = neg,
                 tested = t_tests)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'washington')
  invisible(d)
}
#' @title       scrape west virginia
#' @description scrapes urls for west virginia
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_west_virginia <- function() {
  state_name <- 'West Virgina'
  timezone <- 'America/New_York'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  tbls <- rvest::html_table(page, fill = TRUE)
  state_dat <- tbls[[4]][1,1]
  county_dat <- tbls[[4]][4,2]
  ud <- paste0(stringr::str_extract(
    state_dat, '(?<=Updated: )\\d{1,}/\\d{1,}/\\d{4}'), '12:00')
  ud <- lubridate::as_datetime(ud, format = '%m/%d/%Y %H:%M',
                               tz = timezone)
  state_dat <- gsub('\r\n', '', state_dat)
  st_cases <- stringr::str_extract(state_dat, '(?<=Positive Cases)\\d{1,}')
  st_negs <- stringr::str_extract(state_dat, '(?<=Negative Cases)\\d{1,}')
  st_deaths <- stringr::str_extract(state_dat, '(?<=Deaths)\\d{1,}')
  st_pending <- stringr::str_extract(state_dat, '(?<=Pending)\\d{1,}')
  d1 <- make_dat(state = state_name, cases = st_cases, negative_tests = st_negs,
                 deaths = st_deaths, pending_tests = st_pending, url = url,
                 page = page_raw)
  county_dat <- extract_county_number_to_df(strsplit(
    gsub('Counties with positive cases: ', '', tbls[[7]][[1]]), ',')[[1]])
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 update_date = ud, county = county_dat[,1],
                 cases = county_dat[,2])
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'west_virginia')
  invisible(d)
}
#' @title       scrape wisconsin
#' @description scrapes url for wisconsin
#' @importFrom  data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wisconsin <- function() {
  state_name <- 'Wisconsin'
  timezone <- 'America/Chicago'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  county_url <- 'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/0/query?f=json&where=1%3D1&returnGeometry=true&spatialRel=esriSpatialRelIntersects&outFields=*&orderByFields=POSITIVE%20DESC&outSR=102100&resultOffset=0&resultRecordCount=1000'
  cj <- jsonlite::fromJSON(county_url)$features$attributes
  ud <- lubridate::as_datetime(paste(unique(cj$DATE), '14:00'),
                               format = '%m/%d/%Y %H:%M', tz = timezone)
  sj <- jsonlite::fromJSON(
    'https://services1.arcgis.com/ISZ89Z51ft1G16OK/arcgis/rest/services/COVID19_WI/FeatureServer/2/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&resultType=none&distance=0.0&units=esriSRUnit_Meter&returnGeodetic=false&outFields=NEGATIVE%2CPOSITIVE%2CDEATHS%2CDATE&returnHiddenFields=false&returnGeometry=true&featureEncoding=esriDefault&multipatchOption=xyFootprint&maxAllowableOffset=&geometryPrecision=&outSR=&datumTransformation=&applyVCSProjection=false&returnIdsOnly=false&returnUniqueIdsOnly=false&returnCountOnly=false&returnExtentOnly=false&returnQueryGeometry=false&returnDistinctValues=false&cacheHint=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&having=&resultOffset=&resultRecordCount=&returnZ=false&returnM=false&returnExceededLimitFeatures=true&quantizationParameters=&sqlFormat=none&f=pjson&token=9khYV8ELTHK1P3ES04DSnCtAqj8bQtfI69A91SPr4vedIc8kWlNLppwF3IMBZvPKoyIQMpeQT7Az_YtQdKUQLpW6OC2W1w8BWm66NGn19cQFjAMh7eSZDLnhuRVkSqzYrFeDUtBPtLjPWvSMymC55d5GVLzh-nZq8fA8E-WYtxPwLZHiA8OZP2s6x17GkZ6au5yhBy-9eOkE8AXjFmqDt0ds-HGDWKZvt03XfnUxnpQ.'
    )$features$attributes
  page_raw <- rvest::html_text(page)
  cnty_raw <- as.character(cj)
  tbls <- rvest::html_table(page, fill = TRUE)[[1]]
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = sj[,2], deaths = sj[,3], update_date = ud,
                 negative_tests = sj[,1])
  d2 <- make_dat(state = state_name, url = county_url, page = cnty_raw,
                 cases = cj$POSITIVE, deaths = cj$DEATHS, county = cj$NAME,
                 update_date = ud)
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'wisconsin')
  invisible(d)
}
#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_wyoming <- function() {
  state_name <- 'Wyoming'
  timezone <- 'America/Denver'
  url <- covidR::urls[state == state_name][['url']]
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  ccc <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[2]/div/div/p[2]'))
  cc <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[3]/div[2]/div/div/p'
  ))
  wyoming_counties <- c('Albany', 'Big Horn', 'Campbell', 'Converse',
                        'Crook', 'Fremont', 'Goshen', 'Hot Springs',
                        'Johnnson', 'Laramie', 'Natrona', 'Niobrara',
                        'Park', 'Platte', 'Sheridan', 'Sublette',
                        'Sweetwater', 'Tenton', 'Uinta', 'Washakie',
                        'Weston')
  cregx <- paste0('(', paste0(wyoming_counties, collapse = '|'),
                  '): \\d{1,}')
  county_cases <- stringr::str_extract_all(ccc, cregx)[[1]]
  ccc <- strsplit(county_cases, ':', fixed = TRUE)
  counties <- c()
  cases <- c()
  for (p in ccc) {
    counties <- append(counties, p[1])
    cases <- append(cases, trimws(p[2], 'l'))
  }
  updated <- trimws(trimws(
    rvest::html_text(rvest::html_node(
      page,
      xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[1]/div[1]/div/p[1]'))
    ))
  ud <- as.POSIXct(paste(stringr::str_extract(
    updated, '.*(?= \\()'), '15:00'), format = '%m/%d/%y %H:%M',
    tz = timezone)
  labst <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[4]/div[1]/div[1]/div/p[2]'
  ))
  lt <- strsplit(labst, 'Test')[[1]]
  tl <- strsplit(lt, ': ')
  labs = c('Wyoming Public Health Laboratory', 'CDC Lab', 'commercial labs')
  labtests <- data.table::data.table(
    labs = labs,
    tests = c(tl[[2]][2], tl[[2]][2], tl[[3]][2])
  )
  labtests[, tests := gsub(',', '', tests)]
  sdt <- rvest::html_text(rvest::html_node(
    page, xpath = '//*[@id="et-boc"]/div/div/div/div[1]/div[2]/div/div/blockquote/p[2]'
  ))
  scases <- stringr::str_extract(sdt, '[0-9]+(\\.[0-9][0-9]?)?(?= lab)')
  sp <- stringr::str_extract(sdt, '[0-9]+(\\.[0-9][0-9]?)?(?= probabl)')
  d1 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = cases, county = counties, update_date = ud)
  d2 <- make_dat(state = state_name, url = url, page = page_raw,
                 lab = labtests[['labs']], lab_tests = labtests[['tests']])
  d3 <- make_dat(state = state_name, url = url, page = page_raw,
                 cases = scases, presumptive_positive = sp)
  d <- data.table::rbindlist(list(d1, d2, d3), fill = TRUE)
  write_out(d, 'wyoming')
  invisible(d)
}

#' @title       scrape the hopkins data
#' @description scrapes the timeseries data from john hopkins's github
#' @return      a data.table ready for export
#' @export
scrape_hopkins_timeseries <- function() {
  url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv'
  dat <- as.data.table(read.csv(url))
  write_out(dat, 'hopkins_timeseries')
  invisible(dat)
}

#' @title       scrape hopkins daily reports once
#' @description scrape all hopkins reports
#' @return      a data.table ready for export
#' @export
scrape_hopkins_daily_once <- function() {
  date_trips <- c()
  urls <- c()
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  cur_month <- lubridate::month(Sys.Date())
  months <- as.character(seq(1, cur_month))
  for (month in months) {
    days <- lubridate::days_in_month(lubridate::month(as.integer(month)))[[1]]
    if (nchar(month) == 1) {
      char_month <- paste0('0', month)
      months[months == month] <- char_month
    } else {
      char_month <- month
    }
    for (day in seq(1, days)) {
      day <- as.character(day)
      if (nchar(day) == 1) {
        day <- paste0('0', day)
      }
      csv_date <- paste0(paste(char_month, day, '2020', sep = '-'), '.csv')
      date_trips <- c(date_trips, csv_date)
      urls <- c(urls, paste0(base_url, csv_date))
    }
  }
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  d <- make_dat(state = dat[['Province.State']],
                country = dat[['Country.Region']],
                provider = 'hopkins', url = urls,
                update_date = dat[['Last.Updated']],
                deaths = dat[['Deaths']],
                region = dat[['Country_Region']],
                cases = dat[['Confirmed']], recovered = dat[['Recovered']],
                lat = dat[['lat']])
  write_out(dat, 'hopkins_daily_once_raw')
  write_out(d, 'hopkins_daily_once')
  invisible(d)
}


#' @title       scrape the hopkins daily data
#' @description scrapes the current date for daily data
#' @return       a data.table ready for export
#' @export
scrape_hopkins_daily <- function() {
  base_url <- 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_daily_reports/'
  target <- paste0(format(Sys.Date(), format = '%m_%d_%Y'), '.csv')
  url <- paste0(base_url, target)
  dat <- as.data.table(read.csv(url))
  d <- make_dat(state = dat[['Province.State']],
                country = dat[['Country.Region']],
                provider = 'hopkins', url = urls,
                update_date = dat[['Last.Updated']],
                deaths = dat[['Deaths']],
                region = dat[['Country_Region']],
                cases = dat[['Confirmed']], recovered = dat[['Recovered']],
                lat = dat[['lat']])
  write_out(dat, 'hopkins_daily_raw')
  write_out(d, 'hopkins_daily')
  invisible(d)
}

#' @title       scrapes the tomquisel covid19 data once
#' @description the one off to grab all raw data from tomquisel data set
#' @return      a data.table ready for export
#' @export
scrape_tomquisel_once <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  start_date <- as.Date('2020-03-14')
  cur_date <- Sys.Date()
  valid_dates <- seq(start_date, cur_date, by = 'days')
  urls <- paste0(base_url, valid_dates, '.csv')
  dat <- data.table::data.table()
  for (u in urls) {
    d <- tryCatch({
      data.table::as.data.table(read.csv(u))
    },
    warning = function(cond) {
      data.table::as.data.table(read.csv(u))
    },
    error = function(cond) {
      return(data.table::data.table())
    })
    dat <- data.table::rbindlist(list(dat, d), fill = TRUE)
  }
  write_out(dat, 'tomq_once_raw')
  d <- make_dat(provider = 'tomquisel', state = dat[['State_Name']],
                county = dat[['County_Name']], cases = dat[['Confirmed']],
                deaths = dat[['Death']], other = 'Fatality_Rate',
                other_value = dat[['Fatality_Rate']],
                update_date = dat[['Last_Update']],
                lat = dat[['Latitude']], lon = dat[['Longitude']])
  write_out(d, 'tomquisel_once')
  invisible(d)
}

#' @title       scrapes the tomquisel data for today's data
#' @description gets the csv from the github repo daily
#' @return       a data.table ready for export
#' @export
scrape_tomquisel <- function() {
  base_url <- 'https://raw.githubusercontent.com/tomquisel/covid19-data/master/data/csv/'
  cur_date <- Sys.Date()
  url <- paste0(base_url, cur_date, '.csv')
  dat <- data.table::as.data.table(read.csv(url))
  write_out(dat, 'tomq_raw')
  d <- make_dat(provider = 'tomquisel', state = dat[['State_Name']],
                county = dat[['County_Name']], cases = dat[['Confirmed']],
                deaths = dat[['Death']], other = 'Fatality_Rate',
                other_value = dat[['Fatality_Rate']],
                update_date = dat[['Last_Update']],
                lat = dat[['Latitude']], lon = dat[['Longitude']])
  write_out(d, 'tomquisel')
  invisible(d)
}

#' @title      scrape DC
#' @description scrapes urls for DC
#' @importFrom data.table :=
#' @return      a data.table ready for use or import into database
#' @export
scrape_hattiesburg <- function() {
  update_time <- NULL
  url <- 'https://data.hattiesburgamerican.com/media/jsons/smpj/covid19_r2.json?v='
  page <- jsonlite::fromJSON(url)
  page_raw <- jsonlite::toJSON(page)
  raw <- data.table::as.data.table(page$features$properties)
  geo <- data.table::as.data.table(
    page$features$geometry[,-length(names(page$features$geometry))])
  coords <- page$features$geometry$coordinates
  dat <- data.table::as.data.table(cbind(raw, unlist_coordinates(coords)))
  names(dat) <- c('country', 'cases', 'deaths', 'recovered', 'active', 'unkown',
                  'update_time', 'something', 'lat', 'lon')
  write_out(dat, 'hattiesburg_raw')
  # ud <- unique(dat[['update_time']])
  # dummy_date <- as.integer(0)
  # class(dummy_date) <- c('POSIXlt', 'POSIXt')
  # dat[, update_date := ]
  # for (d in ud) {
  #   subdat <- dat[update_time == d,]
  #   repeats <- nrow(subdat)
  #   print(subdat)
  #   print(repeats)
  #   nrow(subdat)
  #   dat[udpate_time == d,
  #       update_date := rep(lubridate::as_datatime(update_time,
  #                                            format = '%B %d',
  #                                            tz = 'utc'), repeats)]
  # }
  d <- make_dat(provider = 'hattiesburg', url = url, country = dat[['country']],
                cases = dat[['cases']], recovered = dat[['recovered']],
                pending_tests = dat[['unknown']], other = 'active',
                other_value = dat[['active']],
                lat = dat[['lat']], lon = dat[['lon']])
  write_out(d, 'hattiesburg')
  invisible(d)
}


#' @title       scrape NYT counties
#' @export
scrape_nyt_counties <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties.csv'
  dat <- data.table::as.data.table(read.csv(
    url, stringsAsFactors = FALSE, strip.white = TRUE))
  # write_out(dat, 'nyt_counties_raw')
  dates <- data.table::data.table(date = unique(dat[['date']]))
  dates[, ud := anytime::anytime(paste(date, '17:00'))]
  dat <- data.table::merge.data.table(dat, dates, by = 'date', all.x = TRUE)
  d <- make_dat(provider = 'nyt', state = dat[['state']],
                update_date = dat[['ud']], url = url, county = dat[['county']],
                cases = dat[['cases']], deaths = dat[['deaths']],
                other = 'fips', other_value = dat[['fips']])
  write_out(d, 'nyt_counties')
  invisible(d)
}

#' @title       scrape NYT states
#' @export
scrape_nyt_states <- function() {
  url <- 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv'
  dat <- data.table::as.data.table(read.csv(
    url, stringsAsFactors = FALSE, strip.white = TRUE))
  # write_out(dat, 'nyt_states_raw')
  dates <- data.table::data.table(date = unique(dat[['date']]))
  dates[, ud := anytime::anytime(paste(date, '17:00'))]
  dat <- data.table::merge.data.table(dat, dates, by = 'date', all.x = TRUE)
  d <- make_dat(provider = 'nyt_states', state = dat[['state']],
                update_date = dat[['ud']], cases = dat[['cases']],
                deaths = dat[['deaths']])
  write_out(d, 'nyt_states')
  invisible(d)
}

#' @title   scrape ihme
#' @export
scrape_ihme <- function() {
  url <- 'https://ihmecovid19storage.blob.core.windows.net/latest/ihme-covid19.zip'
  zip_file <- tempfile(fileext = '.zip')
  download.file(url, zip_file)
  zipdf <- unzip(zip_file)
  csv_file <- zipdf[grepl('.csv', zipdf)]
  dat <- data.table::fread(csv_file)
  d <- data.table::melt(dat, id.vars = c('location_name', 'date'),
                        variable.name = 'other', value.name = 'other_value')
  # write_out(dat, 'healthdata_raw')
  d <- make_dat(provider = 'ihme', state = d[['location_name']],
                update_date = as.Date(d[['date']]), other = d[['other']],
                other_value = d[['other_value']])
  write_out(d, 'ihme')
  invisible(dat)
}

#' @title scrape the definitive healthcare site
#' @export
scrape_dh <- function() {
  url <- 'https://opendata.arcgis.com/datasets/1044bb19da8d4dbfb6a96eb1b4ebf629_0.csv'
  d <- data.table::fread(url)

  dm <- data.table::melt(d, id.vars = c('X', 'Y', 'COUNTY_NAME', 'STATE_NAME'),
                         variable.name = 'other', value.name = 'other_value')
  dat <- make_dat(provider = 'definitive_healthcare', url = url,
                  lat = d[['X']], lon = d[['Y']], other = dm[['other']],
                  other_value = dm[['other_value']], state=dm$STATE_NAME,
                  county = dm$COUNTY_NAME)
  write_out(dat, 'definitive_healthcare')
  invisible(dat)
}

#' @title  scrape capacity predictor website
#' @export
scrape_capacity_predictor <- function() {
  #url <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/8DEEDC28EC7644C287092D35E2531332-0:0/views/14854958574850990019_6086303216675469576?csv=true'
  url <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/B93CD93893F945138A9ED72253F87E8B-0:0/views/14854958574850990019_6086303216675469576?csv=true&summary=true'
  download.file(url, basename(url))
  states <- data.table::data.table(
    name = datasets::state.name,
    abb = datasets::state.abb
  )
  d <- data.table::as.data.table(read.table(basename(url),
                                          fileEncoding = 'UTF-16', sep = '\t'))
  dm <- data.table::melt(d, id.vars = c('Case.Date', 'COUNTY', 'County.Name',
                                    'Fips', 'State'), variable.name = 'other',
                         value.name = 'other_value')
  dms <- data.table::merge.data.table(dm, states, by.x = 'State', by.y = 'abb')
  dms[, `:=`(State = NULL, state = name, name = NULL,
             COUNTY = stringr::str_trim(gsub('County', '', COUNTY,
                                             ignore.case = TRUE)))]
  d1 <- dms[!is.na(other_value),]
  dt <- make_dat(provider = 'capacity_predictor', url = url,
                 update_date = anytime::anytime(d1[['Case.Date']]),
                 state = d1[['state']], county = d1[['COUNTY']],
                 fips = d1[['Fips']], other = d1[['other']],
                 other_value = d1[['other_value']])
  url2 <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/B93CD93893F945138A9ED72253F87E8B-0:0/views/14854958574850990019_6086303216675469576?csv=true'
  download.file(url2, basename(url2))
  d2 <- data.table::as.data.table(read.table(basename(url2),
                                          fileEncoding = 'UTF-16', sep = '\t',
                                          fill = TRUE))
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'capacity_predictor')
  invisible(d)
}

#' @title Capactity Predictor
#' @export
scrape_ctp <- function() {
  surl <- 'https://covidtracking.com/api/v1/states/current.csv'
  shurl <- 'https://covidtracking.com/api/v1/states/daily.csv'
  siurl <- 'https://covidtracking.com/api/v1/states/info.csv'
  ccurl <- 'https://covidtracking.com/api/v1/us/current.csv'
  churl <- 'https://covidtracking.com/api/v1/us/daily.csv'
  curl <- 'https://covidtracking.com/api/v1/counties.csv'
  turl <- 'https://covidtracking.com/api/v1/urls.json'
  wurl <- 'https://covidtracking.com/api/v1/states/screenshots.json'
  purl <- 'https://covidtracking.com/api/v1/press.json'
  scv <- data.table::fread(surl)
  shd <- data.table::fread(shurl)
  si <- data.table::fread(siurl)
  uscv <- data.table::fread(ccurl)
  ushd <- data.table::fread(churl)
  counties <- data.table::fread(curl)
  trackers <- jsonlite::fromJSON(turl)
  sws <- jsonlite::fromJSON(wurl)
  press <- jsonlite::fromJSON(purl)
  d1 <- make_dat(provider = 'COVID_Tracking_Project', state = scv[['state']],
                 cases = scv[['positive']], url = surl,
                 update_date = anytime::anytime(scv[['dateModified']]),
                 deaths = scv[['death']],
                 negative_tests = scv[['negative']],
                 recovered = scv[['recovered']],
                 pending_tests = scv[['pending']],
                 hospitalized = scv[['hospitalized']])
  scvm <- data.table::melt.data.table(scv[,-c('positive', 'negative', 'pending',
                                              'death', 'negative', 'ending',
                                              'recovered')],
                                      id.vars = c('state', 'dateModified'))
  d2 <- make_dat(provider = 'COVID_Tracking_Project', state = scvm[['state']],
                 update_date = anytime::anytime(scvm[['dateModified']]),
                 url = surl,
                 other = scvm[['dateModified']], other_value = scvm[['value']])
  d3 <- make_dat(provider = 'COVID_Tracking_Project',
                 update_date = anytime::anytime(shd[['dateChecked']]),
                 url = shurl, state = shd[['state']],
                 cases = shd[['positive']], deaths = shd[['death']],
                 hospitalized = shd[['hospitalized']],
                 negative_tests = shd[['negative']])
  shdm <- data.table::melt.data.table(shd[,-c('positive', 'negative', 'pending',
                                              'death', 'negative', 'ending',
                                              'recovered')],
                                      id.vars = c('state', 'date'))
  shdm[, ud := anytime::anytime(paste(paste(stringi::stri_sub(date, 1, 4),
                           stringi::stri_sub(date, 5, 6),
                           stringi::stri_sub(date, 7, 8), sep = '-'),
                     '12:00')),
       by = c('state', 'date', 'variable', 'value')]
   d4 <- make_dat(provider = 'COVID_Tracking_Project',
                 update_date = shdm[['ud']], state = shdm[['state']],
                 other = shdm[['variable']], other_value = shdm[['value']])
   sim <- data.table::melt.data.table(si, id.vars = c('state', 'name'))
   d5 <- make_dat(provider = 'COVID_Tracking_Project', state = sim[['name']],
                  other = sim[['variable']], other_value = sim[['value']])
   uscv[, country := 'US']
   uscvm <- data.table::melt.data.table(uscv, id.vars = c('country', 'positive',
                                                          'negative', 'pending',
                                                          'recovered',
                                                          'lastModified'))
   uscvm[, ud :=  anytime::anytime(paste(lastModified, '13:00'))]
   d6 <- make_dat(provider = 'COVID_Tracking_Project',
                  update_date = uscvm[['ud']],
                  cases = uscvm[['positive']],
                  negative_tests = uscvm[['negative']],
                  pending_tests = uscvm[['pending']],
                  recovered = uscvm[['recovered']],
                  other = uscvm[['variable']], other_value = uscvm[['value']])
   ushd[, ud :=  anytime::anytime(paste(
     paste(stringi::stri_sub(date, 1, 4),
           stringi::stri_sub(date, 5, 6),
           stringi::stri_sub(date, 7, 8), sep = '-'),
                                        '12:00'))]
   ushdm <- data.table::melt.data.table(ushd[,-c('date')], id.vars = 'ud')
   d7 <- make_dat(provider = 'COVID_Tracking_Project',
                  update_date = ushdm[['ud']], other = ushdm[['variable']],
                  other_value = ushdm[['value']])
   ccm <- data.table::melt.data.table(counties,
                                      id.vars = c('state', 'county'))
   d8 <- make_dat(provider = 'COVID_Tracking_Project', state = ccm[['state']],
                  county = ccm[['county']], other = ccm[['variable']],
                  other_value = ccm[['value']])
   t <- data.table::as.data.table(trackers)
   tm <- data.table::melt.data.table(t[,-c('kind')], id.vars = c('name',
                                                                 'stateId'))
   d9 <- make_dat(provider = 'COVID_Tracking_Project', state = tm[['name']],
                  other = tm[['variable']], other_value = tm[['value']])
   sw <- data.table::as.data.table(sws)
   swm <- data.table::melt.data.table(sw[, -c('date')],
                                      id.vars = c('state', 'dateChecked'))
   d10 <- make_dat(provider = 'COVID_Tracking_Project', state = swm[['state']],
                   update_date = anytime::anytime(swm[['dateChecked']]),
                   other = swm[['variable']], other_value = swm[['value']])
   p <- data.table::as.data.table(press)
   p[, ud :=  anytime::anytime(paste(
     paste(publishDate, sep = '-'),
     '12:00'))]
   pm <- data.table::melt.data.table(p[, -c('publishDate')],
                                       id.vars = 'ud')
   d11 <- make_dat(provider = 'COVID_Tracking_Project',
                   update_date = pm[['ud']],
                   other = pm[['variable']], other_value = pm[['value']])
   d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10,
                                   d11), fill = TRUE)
   write_out(d, 'ctp')
   invisible(d)
}

#' @title scrape guam
#' @export
scrape_guam <- function() {
  state = 'Guam'
  url <- 'http://dphss.guam.gov/covid-19/'
  timezone <- 'Pacific/Guam'
  page <- get_page(url)
  page_raw <- rvest::html_text(page)
  ud <- anytime::anytime(paste(Sys.Date(), '11:00'), tz = timezone)
  case_count <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27Case%20Count%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attributes$value
  recovered <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27Recovered%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attribtues$value
  deaths <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27Deceased%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attributes$value
  suspected <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27Probable%20cases%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attributes$value
  confirmed <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27Confirmed%20cases%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attributes$value
  new_cases <- jsonlite::fromJSON('https://services2.arcgis.com/FPJlJZYRsD8OhCWA/arcgis/rest/services/Testing_and_Status_Query/FeatureServer/0/query?f=json&where=Variable%3D%27New%20Cases%27&returnGeometry=false&spatialRel=esriSpatialRelIntersects&outFields=*&outStatistics=%5B%7B%22statisticType%22%3A%22sum%22%2C%22onStatisticField%22%3A%22Count%22%2C%22outStatisticFieldName%22%3A%22value%22%7D%5D&resultType=standard&cacheHint=true')$features$attribtues$value
  d <- make_dat(state = state, url = url, page = page_raw, update_date = ud,
                cases = case_count, recovered = recovered, deaths = deaths,
                presumptive_positive = suspected, other = 'New Cases',
                other_value = new_cases
                )
  write_out(d, 'guam')
  invisible(d)
}
