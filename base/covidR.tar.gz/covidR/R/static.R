#' @title       show the static columns and data types
#' @description provides a simple interface for retrieving information about
#'              how the schema is structured
#' @param column the column of the data to retrieve
#' @param value should the value be returned? Default TRUE
#' @param type return column names of a specific type
#' @export
static <- function(column = NULL, value = TRUE, type = NULL) {
  raw_data = c(
    'provider' = 'character',
    'country' = 'character',
    'state' = 'character',
    'region' = 'character',
    'url' = 'character',
    'page' = 'character',
    'access_time' = 'datetime',
    'county' = 'character',
    'cases' = 'integer',
    'updated' = 'integer',
    'deaths' = 'integer',
    'presumptive' = 'integer',
    'recovered' = 'integer',
    'tested' = 'integer',
    'hospitalized' = 'integer',
    'negative' = 'integer',
    'counties' = 'integer',
    'severe' = 'integer',
    'lat' = 'numeric',
    'lon' = 'numeric',
    'fips' = 'character',
    'monitored' = 'integer',
    'no_longer_monitored' = 'integer',
    'pending' = 'integer',
    'active' = 'integer',
    'inconclusive' = 'integer',
    'quarantined' = 'integer',
    'scrape_group' = 'integer',
    'resolution' = 'character',
    'icu' = 'integer',
    'cases_male' = 'integer',
    'cases_female' = 'integer',
    'lab' = 'character',
    'lab_tests' = 'integer',
    'lab_positive' = 'integer',
    'lab_negative' = 'integer',
    'age_range' = 'character',
    'age_cases' = 'integer',
    'age_percent' = 'character',
    'age_deaths' = 'integer',
    'age_hospitalized' = 'integer',
    'age_tested' = 'integer',
    'age_negative' = 'integer',
    'age_hospitalized_percent' = 'character',
    'age_deaths_percent' = 'character',
    'sex' = 'character',
    'sex_counts' = 'integer',
    'sex_percent' = 'character',
    'sex_death' = 'integer',
    'other' = 'character',
    'other_value' = 'integer')
  if (is.null(column) & is.null(type)) {
    if (is.null(value)) return(raw_data)
    if (value) return(names(raw_data))
    return(unname(raw_data))
  }
  if (value & is.null(type)) return(raw_data[[value]])
  if (!is.null(type)) return(names(raw_data[raw_data == type]))
  return(raw_data)
}
