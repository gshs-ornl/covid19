# sfread ------------------------------------------------------------------
#' @title  sfread
#' @description  passes `read.table()` through `as.data.table`
#' @param  f  the full path to the file to read (or zipfile)
#' @param  ... variables to be passed to `data.table::fread`
#' @return  a \code{data.table}
sfread <- function(f, keep_cols, drop, ...) {
  if (!is.na(keep_cols) && is.na(drop)) {
    return(invisible(unique(data.table::fread(
      file = f, header = TRUE, select = keep_cols,
      strip.white = TRUE, fill = TRUE, blank.lines.skip = TRUE,
      keepLeadingZeros = TRUE, ...
    ))))
  } else if (is.na(keep_cols) && is.na(drop)) {
    return(invisible(unique(data.table::fread(
      file = f, header = TRUE,
      strip.white = TRUE, fill = TRUE, blank.lines.skip = TRUE,
      keepLeadingZeros = TRUE, ...
    ))))
  } else if (is.na(keep_cols) && !is.na(drop)) {
    return(invisible(unique(data.table::fread(
      file = f, header = TRUE, drop = drop,
      strip.white = TRUE, fill = TRUE, blank.lines.skip = TRUE,
      keepLeadingZeros = TRUE, ...
    ))))
  }

}
# combiner ----------------------------------------------------------------
#' @title   combiner
#' @description  combines all csv or zipped csvs based upon columns provided
#' @param  dir the directory to recurse for .csv and zipped .csv files
#' @param  output_file  the location to store the output
#' @param  keep_cols  indicate the columns to keep
#' @param  fill_ids  pass idcol, default = 'file', since the list has filenames
#'                   as names
#' @param  ... other variables to be passed on to `sfread`
#' @return  a \code{data.table} object combined from all csvs and zipped csvs
#'          via \code[data.table::rbindlist]{data.table::rbindlist}, with the
#'          parameters `fill = TRUE`
combiner <- function(dir = getwd(),
                     output_file = file.path(getwd(), format(
                       Sys.time(), format = 'Combo_%Y-%m-%d_%H%M.csv')),
                     keep_cols = NA, fill_ids = NULL, drop = NA, ...) {
  stopifnot(file.exists(dir))
  file_list <- list.files(path = dir, pattern = '(zip|csv)', full.names = TRUE)
  fl <- length(file_list)
  for (f in file_list) {
    message(gettextf('Processing file: %s', f))
    tryCatch(
      {data.table::fwrite(sfread(f, keep_cols, drop, ...),
                         file = output_file, append = TRUE)},
      warning = function(cond) {
        data.table::fwrite(sfread(f, keep_cols, drop, ...),
                           file = output_file, append = TRUE)
      },
      error = function(cond) {
        message(gettextf('Processing of file "%s" failed.', f))
        return(NULL)
      }
    )
    message(gettextf('Processing status: %g', which(file_list == f)/fl * 100))
  }
  return(as.character(output_file))
}
# convert_am_pm -----------------------------------------------------------
#' @title       Convert between AM and PM variablities
#' @description given an AM/PM string, convert to the appropriate string for
#' @return      AM or PM if matched, x if not
#' @export
convert_am_pm <- function(
  x, pm_regex = '(p\\.m\\.|P\\.M\\.|p\\.M\\.|P\\.m\\.|pm)',
  am_regex = '(a\\.m\\.|A\\.M\\.|a\\.M\\.|A\\.m\\.|am)') {
  if (grepl(pm_regex, x, perl = TRUE)) {
    return(gsub(pm_regex, 'PM', x, perl = TRUE))
  }
  if (grepl(am_regex, x, perl = TRUE)) {
    return(gsub(pm_regex, 'AM', x, perl = TRUE))
  }
  warning(sprintf('Unable to find valid AM/PM value in %s', x))
  return(x)
}
# get_page ----------------------------------------------------------------
#' @title       Retrieve an HTML object
#' @description simply a wrapper to retrieve an HTML page object from xml2
#' @return      an xml2 page object
#' @export
get_page <- function(url) {
  url <- stringr::str_trim(url)
  httr::set_config(httr::config(ssl_verifypeeer = 0L,
                                ssl_verifyhost = 0L,
                                ssl_verifystatus = 0L))
  return(xml2::read_html(url, options = c('NOBLANKS'), trim = TRUE,
                         fill = TRUE))
}
# retrieve_timezone -------------------------------------------------------
#' @title       lookup a posix-compatible timezone
#' @description uses a combination of timezone datasets to make something
#'              useful
#' @return      the valid posix timezone
#' @export
retrieve_timezone <- function(ab = NULL, dst = NULL, country = 'US') {
  abbreviation <- country_code <- abb <- NULL
  if (!is.null(ab) && is.null(abbreviation)) {
    return(covidR::tzdt[abb == ab &
                          country_code == country,][['zone_name']][1])
  }
  if (is.null(ab) && !is.null(dst)) {
    return(covidR::tzdt[abbreviation == dst &
                          country_code == country,][['zone_name']][1])
  }
}
# fetch_number_in_text ----------------------------------------------------
#' @title       retrieve a number from text
#' @description fetch a number from text
#' @return      returns an integer
#' @export
fetch_number_in_text <- function(page_text, search_word = NULL) {
  comma_regex <- '(,*[\\d]+,*[\\d]*)+'
  return(
    as.integer(
      gsub(',', '',
         stringr::str_extract(page_text, paste0('(?<=', search_word, ')',
                                                comma_regex)))))
}
# make_access_time --------------------------------------------------------
#' @title       provide access time in UTC
#' @description provides the access time in UTC
#' @return      a datetime in UTC
#' @export
make_access_time <- function() {
  dt <- Sys.time()
  attr(dt, 'tzone') <- 'UTC'
  dt
}
# make_datetime_utc -------------------------------------------------------
#' @title       convert a date to UTC
#' @description converts a datetime object to UTC timezone
#' @return      a datetime object in UTC
#' @export
make_datetime_utc <- function(x) {
  attr(x, 'tzone') <- 'UTC'
  x
}
# sanitize_integer --------------------------------------------------------
#' @title       sanitize an integer
#' @description convert whatever to an integer
#' @return      returns an integer
#' @export
sanitize_integer <- function(x) {
  x <- unlist(lapply(x, gsub, pattern = ',', replacement = '', fixed = TRUE))
  as.integer(unlist(x))
}
# sanitize_numeric --------------------------------------------------------
#' @title       sanitize a number
#' @description given a possible list of numbers, create a numeric value
#' @return      returns a numeric number
#' @export
sanitize_numeric <- function(x) {
  x <- unlist(lapply(x, gsub, pattern = ',', replacement = '', fixed = FALSE))
  as.numeric(unlist(x))
}
# sanitize character ------------------------------------------------------
#' @title       sanitize a character
#' @description unlist and then create to character
#' @return      a character
#' @export
sanitize_char <- function(x) {
  as.character(unlist(x))
}
# text_to_num -------------------------------------------------------------
#' @title       text to num
#' @description converts text to number
#' @return      an integer
#' @export
text_to_num <- function(x) {
  as.integer(gsub(',', '', stringr::str_trim(x)))
}
# to_utf ------------------------------------------------------------------
#' @title       force encoding to UTF-8
#' @description utf-8 encode
#' @return      a utf-8 encoding
to_utf <- function(x) {
  if (class(x) == 'character') {
    tryCatch({
      return(enc2utf8(x))
    },
    warning = function(cond) {
      message(gettextf(
        'A warning occurred: %s', cond
      ))
      return(x)
    },
    error = function(cond) {
      message(gettextf(
        'An error occurred when converting to UTF: %s', cond))
      return(x)
    })
  }
  x
}

#' @title       sanitize a percentage
#' @description intelligently sanitize percent
#' @return      an integer representing the percent
sanitize_percent <- function(x) {
  if (class(x) == 'integer') return(as.numeric(x))
  if (class(x) == 'numeric' && x < 1) {
    return(x * 100)
  } else {
    return(x)
  }
  if (class(x) == 'character') {
    x <- gsub('(%|[a-zA-Z]|,)', '', x, perl = TRUE)
    return(as.numeric(x))
  }
}

#' @title       make the standardized data format
#' @description this provides the standard data format for import into the
#'              covid database
#' @return      returns a data.table ready for export or other usage
#' @import data.table
#' @export
make_dat <- function(country = 'US', state = NA_character_, url = NA_character_,
                     provider = 'state', region = NA_character_,
                     page = NA_character_, resolution = NA_character_,
                     cases = NA_integer_, update_date = NA,
                     deaths = NA, presumptive_positive = NA_integer_,
                     recovered = NA_integer_, tested = NA_integer_,
                     hospitalized = NA_integer_, county = NA_character_,
                     negative_tests = NA_integer_, counties = NA_character_,
                     severe_cases = NA_integer_, lat = NA_real_,
                     no_longer_monitored = NA_integer_, lon = NA_real_,
                     fips = NA_integer_, state_tests = NA_integer_,
                     private_tests = NA_integer_, icu = NA_integer_,
                     monitored = NA_integer_, pending_tests = NA_integer_,
                     active = NA_integer_, inconclusive = NA_integer_,
                     quarantined = NA_integer_,
                     lab = NA_character_, lab_tests = NA_integer_,
                     lab_positive = NA_integer_, lab_negative = NA_integer_,
                     cases_male = NA_integer_, age_deaths = NA_integer_,
                     age_range = NA_character_, age_hospitalized = NA_integer_,
                     age_cases = NA_integer_, age_tested = NA_integer_,
                     age_percent = NA_character_, age_negative = NA_integer_,
                     cases_female = NA_integer_,
                     age_hospitalized_percent = NA_integer_,
                     age_deaths_percent = NA_character_,
                     age_tested_percent = NA_character_,
                     age_negative_percent = NA_character_,
                     sex = NA_character_,
                     sex_counts = NA_integer_,
                     sex_percent = NA_integer_,
                     other = NA_character_,
                     other_value = NA_character_,
                     race = NA_character_,
                     ethnicity = NA_character_, ...) {
  runtime <- make_access_time()
  if (is.na(update_date) || length(update_date) == 0) {
    update_date <- make_access_time()
  }
  scrape_group = as.integer(format(Sys.time(), format = '%Y%m%d%H'))
  suppressWarnings(data.table::data.table(
                         provider = provider,
                         country = to_utf(country),
                         state = to_utf(state),
                         region = to_utf(region),
                         url =  to_utf(url),
                         page =  to_utf(as.character(page)),
                         access_time = runtime,
                         county = to_utf(county),
                         cases = sanitize_integer(cases),
                         updated = update_date,
                         deaths = sanitize_integer(deaths),
                         presumptive = sanitize_integer(presumptive_positive),
                         recovered = sanitize_integer(recovered),
                         tested = sanitize_integer(tested),
                         hospitalized = sanitize_integer(hospitalized),
                         negative = sanitize_integer(negative_tests),
                         counties = sanitize_integer(counties),
                         severe = sanitize_integer(severe_cases),
                         lat = sanitize_numeric(lat),
                         lon = sanitize_numeric(lon),
                         fips = sanitize_numeric(fips),
                         monitored = sanitize_integer(monitored),
                         no_longer_monitored = sanitize_integer(
                           no_longer_monitored),
                         pending = sanitize_integer(pending_tests),
                         active = sanitize_integer(active),
                         inconclusive = sanitize_integer(inconclusive),
                         quarantined = sanitize_integer(quarantined),
                         private_tests = sanitize_integer(private_tests),
                         state_tests = sanitize_integer(state_tests),
                         scrape_group = sanitize_integer(scrape_group),
                         resolution = to_utf(resolution),
                         icu = sanitize_integer(icu),
                         cases_male = sanitize_integer(cases_male),
                         cases_female = sanitize_integer(cases_female),
                         lab = to_utf(lab),
                         lab_tests = sanitize_integer(lab_tests),
                         lab_positive = sanitize_integer(lab_positive),
                         lab_negative = sanitize_integer(lab_negative),
                         age_range = to_utf(age_range),
                         age_cases = sanitize_integer(age_cases),
                         age_percent = to_utf(age_percent),
                         age_deaths = sanitize_integer(age_deaths),
                         age_hospitalized = sanitize_integer(age_hospitalized),
                         age_tested = sanitize_integer(age_tested),
                         age_negative = sanitize_integer(age_negative),
                         age_hospitalized_percent = sanitize_percent(age_hospitalized_percent),
                         age_negative_percent = sanitize_percent(age_negative_percent),
                         age_deaths_percent = sanitize_percent(age_deaths_percent),
                         sex = to_utf(sex),
                         sex_cases = sanitize_integer(sex_counts),
                         sex_percent = sanitize_percent(sex_percent),
                         other = other,
                         other_value = other_value,
                         race = race,
                         ethnicity = ethnicity,
                         ...
  ))
}


#' @title       unlist coordinates to points
#' @description unlist a list of coordinates to points
#' @return      returns a data.table with lat/lon values
#' @export
unlist_coordinates <- function(x) {
  dat <- data.table::data.table()
  for (i in 1:length(x)) {
    d <- data.table::data.table(lat = x[[i]][1],
                                lon = x[[i]][2])
    dat <- rbind(dat, d)
  }
  return(dat)
}

#' @title       convert lat/lon to fips
#' @description provided a points_df containg lat/lon columns to
#' @return      returns the county_names found
#' @export
lat_lon_to_fips <- function(points_df) {
  counties <- maps::map('county', fill = TRUE, col = 'transparent',
                        plot = FALSE)
  IDs <- sapply(strsplit(counties$names, ':'), function(x) x[1])
  counties_sp <- maptools::map2SpatialPolygons(
    counties, IDs, sp::CRS("+proj=longlat + datum=WGS85"))
  indices <- sp::over(points_df, counties_sp)
  county_names <- sapply(counties_sp@polygons, function(x) x@ID)
  county_names[indices]
}

#' @title       convert date to POSIXct datetime
#' @description given a date and format, convert
#' @return      a vector of POSIXct dates
#' @export
convert_date <- function(date, format, tz = 'UTC') {
  if (length(date) == 1) {
    return(as.POSIXct(lubridate::as_datetime(date, format = format, tz = tz)))
  }
  if (length(date) > 1) {
    dates <- c()
    for (d in date) {
      dates <- append(dates, as.POSIXct(lubridate::as_datetime(date,
                                                               format = format,
                                                               tz = tz)))
    }
    return(dates)
  }
}

#' @title       extract a scounty number
#' @description extract a county and number and return as a vector
#' @return      a vector in the form of county/cases
#' @export
extract_county_number <- function(x) {
  county <- stringr::str_extract(x, '\\w{1,}')
  cases <- as.integer(stringr::str_extract(x, '\\d{1,}'))
  return(c(county, cases))
}

#' @title       convert a word to a number
#' @description provided a num ber word convert it to a number
#' @return      a list of the word and the output
#' @export
convert_word_to_num <- function(word){
  wsplit <- strsplit(tolower(word)," ")[[1]]
  one_digits <- list(zero = 0, one = 1 , two = 2, three = 3, four = 4, five = 5,
                     six = 6, seven = 7, eight = 8, nine = 9)
  teens <- list(eleven = 11, twelve = 12, thirteen = 13, fourteen = 14,
                fifteen = 15,  sixteen = 16, seventeen = 17, eighteen = 18,
                nineteen = 19)
  ten_digits <- list(ten = 10, twenty = 20, thirty = 30, forty = 40, fifty = 50,
                     sixty = 60, seventy = 70, eighty = 80, ninety = 90)
  doubles <- c(teens, ten_digits)
  out <- 0
  i <- 1
  while (i <= length(wsplit)) {
    j <- 1
    if (i == 1 && wsplit[i] == "hundred")
      temp <- 100
    else if (i == 1 && wsplit[i] == "thousand")
      temp <- 1000
    else if (wsplit[i] %in% names(one_digits))
      temp <- as.numeric(one_digits[wsplit[i]])
    else if (wsplit[i] %in% names(teens))
      temp <- as.numeric(teens[wsplit[i]])
    else if (wsplit[i] %in% names(ten_digits))
      temp <- (as.numeric(ten_digits[wsplit[i]]))
    if (i < length(wsplit) && wsplit[i + 1] == "hundred") {
      if (i > 1 && wsplit[i - 1] %in% c("hundred", "thousand"))
        out <- out + 100*temp
      else
        out <- 100*(out + temp)
      j <- 2
    }
    else if (i < length(wsplit) && wsplit[i + 1] == "thousand") {
      if (i > 1 && wsplit[i - 1] %in% c("hundred", "thousand"))
        out <- out + 1000*temp
      else
        out <- 1000*(out + temp)
      j <- 2
    }
    else if (i < length(wsplit) && wsplit[i + 1] %in% names(doubles)) {
      temp <- temp*100
      out <- out + temp
    }
    else{
      out <- out + temp
    }
    i <- i + j
  }
  return(list(word,out))
}

#' @title       extract the county name and county number from string
#' @description given a string that contains county name and number
#' @return      a data.frame with county and cases field
#' @export
extract_county_number_to_df <- function(x) {
  county <- stringr::str_extract(x, '\\w{1,}')
  cases <- as.integer(stringr::str_extract(x, '\\d{1,}'))
  return(data.frame(county = county, cases = cases))
}

#' @title       retrieve all the scraper functions
#' @description creates all state fxns and then add additional scrapes
#' @return      a character containg the function to call
#' @export
get_scraper_functions <- function() {
  states <- state.name
  states <- append(states, c('Puerto Rico', 'DC', 'hattiesburg'))
  paste0('scrape_', snakecase::to_snake_case(states), '()')
}

#' @title       make file names
#' @description makes file names based on
#' @return       a list of file_names for csv data and html/json text
#' @export
make_file_names <- function(fxn) {
  name <- gsub('()', '', gsub('scrape_', '', fxn, fixed = TRUE), fixed = TRUE)
  if (Sys.getenv('OUTPUT_DIR') != '') {
    out_dir <- Sys.getenv('OUTPUT_DIR')
  } else {
   out_dir <- '/tmp/output'
   if (Sys.info()["sysname"] == "Windows") out_dir <- substring(out_dir, 2)
  }
  out_date <- format(Sys.time(), format = '%Y%m%d%H%M')
  page_fn <- file.path(out_dir, paste0(paste(
    name, out_date, 'page', sep = '_'), '.txt'))
  file_fn <- file.path(out_dir,
                       paste0(paste(name, out_date, sep = '_'), '.csv'))
  file_names <- c(file_fn, page_fn)
  return(file_names)
}

#' @title       write out the data
#' @description writes out the data to a CSV
#' @return      NULL
#' @export
write_out <- function(x, fxn) {
  if (Sys.getenv('PRODUCTION') == 'True') {
    keep_page = TRUE
  } else {
    keep_page = FALSE
  }
  # counties <- unique(x[['county']])
  # counties <- counties[counties != '']
  # state <- unique(x[['state']])
  # if (length(state != 1)) {
  #   stop(gettextf('More than one state passed: %s',
  #                    paste0(state, collapse = ', ')))
  # }
  # check_counties(counties, state)
  fns <- make_file_names(fxn)
  message(names(x))
  page_name <- names(x)[grepl('page', names(x))]
  if (any(grepl('page', names(x)))) {
    page <- unique(x[[page_name]])
    if (keep_page == TRUE) {
      data.table::fwrite(x, file = fns[[1]])
    } else {
      data.table::fwrite(x[, page := NULL], file = fns[1])
      file_con <- file(fns[2])
      writeLines(as.character(page), file_con)
      close(file_con)
    }
  } else {
    data.table::fwrite(x, file = fns[1])
  }
}

#' @title       scraper wrapper for scraper functions
#' @description wrap the scraper in a
#' @return      if interactive returns the data.table otherwise returns NULL
#' @export
#' @importFrom data.table :=
wrap_scraper <- function(fxn, interactive = FALSE) {
  page <- page_raw <- raw_page <- NULL # appease R CMD Check
  message(sprintf('Running scraper %s', fxn))
  dt <- try_scrape_wrapper(fxn, 10)
  if ('data.table' %in% class(dt)) {
    print(names(dt))
    if ('page' %in% names(dt)) {
      page <- as.character(unique(dt[['page']]))
      out <- dt[, page := NULL]
    } else if ('page_raw' %in% names(dt)) {
      page <- as.character(unique(dt[['page_raw']]))
      out <- dt[, page_raw := NULL]
    } else if ('raw_page' %in% names(dt)) {
      page <- as.character(unique(dt[['raw_page']]))
      out <- dt[, raw_page := NULL]
    } else {
      out <- dt
    }
    file_name <- make_file_names(fxn)
    data.table::fwrite(out, file = file_name[1])
    fileConn <- file(file_name[2])
    writeLines(page)
    close(fileConn)
  }
  if (interactive) {
    return(dt)
  }
  invisible(NULL)
}

#' @title       run all scripts
#' @description runs all scripts from get_scraper_functions
#' @return      a data.table containing all data
#' @export
run_all_scripts <- function() {
  fxns <- get_scraper_functions()
  dts <- c()
  for (i in 1:length(fxns)) {
    if (grepl('maine', fxns[i], fixed = TRUE)) {
      warning('Maine script needs revisitng')
      dt <- NULL
    }
    dt <- wrap_scraper(fxns[i], interactive = TRUE)
    if (!is.null(dt)) {
      dts <- c(dts, dt)
    }
  }
  dts <- as.list(dts)
  for (i in 1:length(dts)) {
    if (!'data.table' %in% class(dts[[i]])) {
      dts[[i]] <- NA
    }
  }
  data.table::rbindlist(dts, fill = TRUE)
}

#' @title       convert JSON list to character
#' @description some sites have multiple JSON URLs, and this will turn them into
#'              a single character
#' @return      a string
#' @export
convert_json_to_str <- function(...) {
  lst <- list(...)
  out <- ''
  for (l in lst) {
    nl <- paste(paste(as.character(unlist(l)), collapse = '|'))
    out <- paste0(out, nl, collapse = '\n')
  }
  return(out)
}

#' @title       convert vector of URLs to string
#' @description takes a vector of URLs passed as ... and converts to string
#' @return      a string of URLs
#' @export
convert_urls_to_str <- function(...) {
  return(paste0(c(...), collapse = '\n'))
}

#' @title       try for the web connection
#' @description tries a function for a connection until successful or tries out
#' @return      the results of the function
#' @export
try_scrape_wrapper <- function(fxn, retries = 5) {
  tryCatch({eval(parse(text = fxn))},
           warning = function(cond) {
             if (retries >= 0) {
               try_scrape_wrapper(fxn, retries - 1)
             }
           },
           error = function(cond) {
             if (retries >= 0) {
               try_scrape_wrapper(fxn, retries - 1)
             }
           })
}
#' @title       remove columns with all NAs, all NULLs or all ""s
#' @description remvoes all columns of a data.table that contain either all
#'              NAs, all NULLs, or all empty strings
#' @param x a data.table object to remove empty columns
#' @export
clean_dt <- function(x) {
  # lst <- add_diff(append(lst, meta(x))
  # message(gettextf('Cleaning data.table with %d columns and %d rows',
  #                  lst[[1]]$cols, meta[[1]]$rows))
  x <- x[,which(unlist(lapply(x, function(x) !all(is.na(x))))), with = FALSE]
  # lst <- append(lst, meta(x))
  # message(getestf('Removed %d columns containg all NAs', meta[[2]]$cols))
  x <- x[,which(unlist(lapply(x, function(x) !all(is.null(x))))), with = FALSE]
  # lst <- append(lst, meta(x))
  # message(getestf('Removed %d columns containg all NULLs', meta[[3]]$cols))
  x <- x[,which(unlist(lapply(x, function(x) !all(x == '')))), with = FALSE]
  invisible(x)
}

#' @title   helper function to zip everything in output and write to dest
#' @export
zip_temp_write <- function(dest = '~') {
  setwd(dest)
  fs <- list.files('/tmp/output', pattern = '*.csv', full.names = TRUE)
  fd <- file.path(dest, paste0(format(Sys.time(), format = '%Y-%m-%d_%H%M'),
                         'R_scrapes.zip'))
  zip(fd, fs)
}

#' @title when county column is populated, check that it matches within a state
#' @export
check_counties <- function(c, s) {
  state <- NULL # appease R CMD check
  state_counties <- covidR::county_data[state == s][['county']]
  if (!all(c %in% state_counties)) {
    stop(gettextf('The following counties are not in the state: %s'),
            paste0(c[!c %in% state_counties]))
  }
}

#' @title    make first row of
