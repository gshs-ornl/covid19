#' @title scrap capacity predictor
#' @export
scrape_capacity_predictor <- function() {
  #url <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/8DEEDC28EC7644C287092D35E2531332-0:0/views/14854958574850990019_6086303216675469576?csv=true'
  url <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/B93CD93893F945138A9ED72253F87E8B-0:0/views/14854958574850990019_6086303216675469576?csv=true&summary=true'
  download.file(url, basename(url))
  states <- data.table::data.table(
    name = datasets::state.name,
    abb = datasets::state.abb
  )
  d <- data.table::as.data.table(read.table(basename(url),
                                          fileEncoding = 'UTF-16', sep = '\t'))
  dm <- data.table::melt(d, id.vars = c('Case.Date', 'COUNTY', 'County.Name',
                                    'Fips', 'State'), variable.name = 'other',
                         value.name = 'other_value')
  dms <- data.table::merge.data.table(dm, states, by.x = 'State', by.y = 'abb')
  dms[, `:=`(State = NULL, state = name, name = NULL,
             COUNTY = stringr::str_trim(gsub('County', '', COUNTY,
                                             ignore.case = TRUE)))]
  d1 <- dms[!is.na(other_value),]
  dt <- make_dat(provider = 'capacity_predictor', url = url,
                 update_date = anytime::anytime(d1[['Case.Date']]),
                 state = d1[['state']], county = d1[['COUNTY']],
                 fips = d1[['Fips']], other = d1[['other']],
                 other_value = d1[['other_value']])
  url2 <- 'https://public.tableau.com/vizql/w/DefinitiveHCCOVID-19CapacityPredictor/v/DefinitiveHealthcareCOVID-19CapacityPredictor/vud/sessions/B93CD93893F945138A9ED72253F87E8B-0:0/views/14854958574850990019_6086303216675469576?csv=true'
  download.file(url2, basename(url2))
  d2 <- data.table::as.data.table(read.table(basename(url2),
                                          fileEncoding = 'UTF-16', sep = '\t',
                                          fill = TRUE))
  d <- data.table::rbindlist(list(d1, d2), fill = TRUE)
  write_out(d, 'capacity_predictor')
  invisible(d)
}

#' @title Capactity Predictor
#' @export
scrape_ctp <- function() {
  surl <- 'https://covidtracking.com/api/v1/states/current.csv'
  shurl <- 'https://covidtracking.com/api/v1/states/daily.csv'
  siurl <- 'https://covidtracking.com/api/v1/states/info.csv'
  ccurl <- 'https://covidtracking.com/api/v1/us/current.csv'
  churl <- 'https://covidtracking.com/api/v1/us/daily.csv'
  curl <- 'https://covidtracking.com/api/v1/counties.csv'
  turl <- 'https://covidtracking.com/api/v1/urls.json'
  wurl <- 'https://covidtracking.com/api/v1/states/screenshots.json'
  purl <- 'https://covidtracking.com/api/v1/press.json'
  scv <- data.table::fread(surl)
  shd <- data.table::fread(shurl)
  si <- data.table::fread(siurl)
  uscv <- data.table::fread(ccurl)
  ushd <- data.table::fread(churl)
  counties <- data.table::fread(curl)
  trackers <- jsonlite::fromJSON(turl)
  sws <- jsonlite::fromJSON(wurl)
  press <- jsonlite::fromJSON(purl)
  d1 <- make_dat(provider = 'COVID_Tracking_Project', state = scv[['state']],
                 cases = scv[['positive']], url = surl,
                 update_date = anytime::anytime(scv[['dateModified']]),
                 deaths = scv[['death']],
                 negative_tests = scv[['negative']],
                 recovered = scv[['recovered']],
                 pending_tests = scv[['pending']],
                 hospitalized = scv[['hospitalized']])
  scvm <- data.table::melt.data.table(scv[,-c('positive', 'negative', 'pending',
                                              'death', 'negative', 'ending',
                                              'recovered')],
                                      id.vars = c('state', 'dateModified'))
  d2 <- make_dat(provider = 'COVID_Tracking_Project', state = scvm[['state']],
                 update_date = anytime::anytime(scvm[['dateModified']]),
                 url = surl,
                 other = scvm[['dateModified']], other_value = scvm[['value']])
  d3 <- make_dat(provider = 'COVID_Tracking_Project',
                 update_date = anytime::anytime(shd[['dateChecked']]),
                 url = shurl, state = shd[['state']],
                 cases = shd[['positive']], deaths = shd[['death']],
                 hospitalized = shd[['hospitalized']],
                 negative_tests = shd[['negative']])
  shdm <- data.table::melt.data.table(shd[,-c('positive', 'negative', 'pending',
                                              'death', 'negative', 'ending',
                                              'recovered')],
                                      id.vars = c('state', 'date'))
  shdm[, ud := anytime::anytime(paste(paste(stringi::stri_sub(date, 1, 4),
                           stringi::stri_sub(date, 5, 6),
                           stringi::stri_sub(date, 7, 8), sep = '-'),
                     '12:00')),
       by = c('state', 'date', 'variable', 'value')]
   d4 <- make_dat(provider = 'COVID_Tracking_Project',
                 update_date = shdm[['ud']], state = shdm[['state']],
                 other = shdm[['variable']], other_value = shdm[['value']])
   sim <- data.table::melt.data.table(si, id.vars = c('state', 'name'))
   d5 <- make_dat(provider = 'COVID_Tracking_Project', state = sim[['name']],
                  other = sim[['variable']], other_value = sim[['value']])
   uscv[, country := 'US']
   uscvm <- data.table::melt.data.table(uscv, id.vars = c('country', 'positive',
                                                          'negative', 'pending',
                                                          'recovered',
                                                          'lastModified'))
   uscvm[, ud :=  anytime::anytime(paste(lastModified, '13:00'))]
   d6 <- make_dat(provider = 'COVID_Tracking_Project',
                  update_date = uscvm[['ud']],
                  cases = uscvm[['positive']],
                  negative_tests = uscvm[['negative']],
                  pending_tests = uscvm[['pending']],
                  recovered = uscvm[['recovered']],
                  other = uscvm[['variable']], other_value = uscvm[['value']])
   ushd[, ud :=  anytime::anytime(paste(
     paste(stringi::stri_sub(date, 1, 4),
           stringi::stri_sub(date, 5, 6),
           stringi::stri_sub(date, 7, 8), sep = '-'),
                                        '12:00'))]
   ushdm <- data.table::melt.data.table(ushd[,-c('date')], id.vars = 'ud')
   d7 <- make_dat(provider = 'COVID_Tracking_Project',
                  update_date = ushdm[['ud']], other = ushdm[['variable']],
                  other_value = ushdm[['value']])
   ccm <- data.table::melt.data.table(counties,
                                      id.vars = c('state', 'county'))
   d8 <- make_dat(provider = 'COVID_Tracking_Project', state = ccm[['state']],
                  county = ccm[['county']], other = ccm[['variable']],
                  other_value = ccm[['value']])
   t <- data.table::as.data.table(trackers)
   tm <- data.table::melt.data.table(t[,-c('kind')], id.vars = c('name',
                                                                 'stateId'))
   d9 <- make_dat(provider = 'COVID_Tracking_Project', state = tm[['name']],
                  other = tm[['variable']], other_value = tm[['value']])
   sw <- data.table::as.data.table(sws)
   swm <- data.table::melt.data.table(sw[, -c('date')],
                                      id.vars = c('state', 'dateChecked'))
   d10 <- make_dat(provider = 'COVID_Tracking_Project', state = swm[['state']],
                   update_date = anytime::anytime(swm[['dateChecked']]),
                   other = swm[['variable']], other_value = swm[['value']])
   p <- data.table::as.data.table(press)
   p[, ud :=  anytime::anytime(paste(
     paste(publishDate, sep = '-'),
     '12:00'))]
   pm <- data.table::melt.data.table(p[, -c('publishDate')],
                                       id.vars = 'ud')
   d11 <- make_dat(provider = 'COVID_Tracking_Project',
                   update_date = pm[['ud']],
                   other = pm[['variable']], other_value = pm[['value']])
   d <- data.table::rbindlist(list(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10,
                                   d11), fill = TRUE)
   write_out(d, 'ctp')
   invisible(d)
}

