library(data.table)
automated_scrapes <- list.files(path = '/mnt/forbin/dev',
                                pattern = '^covidR.*.csv',
                                full.names = TRUE)
other_scrapes <- list.files(path = '/home/sempervent/Downloads/',
                            pattern = '*.csv',
                            full.names = TRUE)
all_scrapes <- c(automated_scrapes, other_scrapes)
try_fread <- function(x, ...) {
  message(gettextf('Processing file: %s', x))
  tryCatch({
    data.table::fread(x, fill = TRUE, ...)
  },
  error = function(e) {
    cat('\nError reading in file: ', x, '\n')
    message(e)
    list(Error = x)
  },
  warning = function(cond) {
    data.table::fread(x, fill = TRUE, ...)
  })
}

collections <- split(all_scrapes, ceiling(seq_along(all_scrapes)/60))
import_data <- list()
iterate_collections <- function(collections, type = c('hattiesburg', 'nyt',
                                                      'tomq')) {
  import_data <- list()
  for (i in 1:length(collections)) {
    candidate <- data.table::rbindlist(lapply(
      collections[[i]], try_fread, integer64 = 'character',
      logical01 = FALSE, keepLeadingZeros = TRUE, ), fill = TRUE, )
    import_data[[i]] <- candidate
    file_name <-  paste0('/mnt/forbin/dev/candidate_', i, '_.csv' )
      data.table::fwrite(candidate,
                         file = file_name,)
      message(gettextf('Processed collection entry %d of %d', i,
                       length(collections)))
      message(gettextf('Row Names:\n\t%s\n', paste0(names(candidate),
                                                    collapse = ', ')))
      message('Statistics:')
      message(gettextf('\trows:\t\t%d', nrow(candidate)))
      message(gettextf('\tcolumns:\t%d', length(names(candidate))))
      message(gettextf('\tsize:\t\t%s', format(object.size(candidate),
                                               units = 'MB')))
      # readline(prompt = "Press [enter] to continue")
      candidate <- NULL
  }
  import_data
}

iterate_files <- function(files, type = c('state', 'hopkins', 'tomq', 'nyt',
                                          'hattiesburg')) {
  type <- match.arg(type)
  file_list <- list()
  message(gettextf('Proceeding with type "%s"', type))
  for (f in files) {
    if (type == 'state') {
      if (!grepl('(hopkins|tomq|nyt|hatties)', f, perl = TRUE)) {
        message(gettextf('Found state data file: %s', f))
        candidate <- try_fread(f, integer64 = 'character', logical01 = FALSE)#,
                               # keepLeadingZeroes = TRUE)
        file_list[[f]] <- candidate
      }
    } else if (type == 'hopkins') {
      if (grepl('hopkins_raw', f, perl = TRUE)) {
        message(gettextf('Found Hopkins data file: %s', f))
        file_list[[f]] <- fread(f)
      }
    } else if (type == 'tomq') {
      if (grepl('tomq_raw', f, perl = TRUE)) {
        message(gettextf('Found tomq data file: %s', f))
        file_list[[f]] <- data.table::fread(f)
      }
    } else if (type == 'nyt') {
      if (grepl('nyt.*raw', f, perl = TRUE)) {
        message(gettextf('Found NYT data file: %s', f))
        candidate <- data.table::fread(f)
        file_list[[f]] <- candidate
      }
    } else if (type == 'hattiesburg') {
      if (grepl('hattiesburg.*raw', f, perl = TRUE)) {
        message(gettextf('Found Hattiesburg data file: %s', f))
        candidate <- data.table::fread(f)
        file_list[[f]] <- candidate
      }
    } else {
      warning(gettextf('Unknown data file type: %s', f))
    }
  }
  file_list
}

auto_state_list <- iterate_files(automated_scrapes, type = 'state')
ad_to_date <- data.table::rbindlist(auto_state_list, fill = TRUE)
ad <- ad_to_date[-537:-8,]
ad_auto_data <- data.table::rbindlist(iterate_files(automated_scrapes,
                                                 type = 'state'),
                                   fill = TRUE)[,-c(85:496)]
hopkins_data <- data.table::rbindlist(iterate_files(automated_scrapes,
                                                    type = 'hopkins'),
                                      fill = TRUE)
tomq_data <- data.table::rbindlist(iterate_files(automated_scrapes,
                                                    type = 'tomq'),
                                      fill = TRUE)
nyt_data <- data.table::rbindlist(iterate_files(automated_scrapes,
                                                 type = 'nyt'),
                                   fill = TRUE)
data.table::fwrite(hopkins_data,
                   file = '/home/sempervent/Downloads/hopkins_data.csv')
data.table::fwrite(tomq_data,
                   file = '/home/sempervent/Downloads/tomq_data.csv')
data.table::fwrite(nyt_data,
                   file = '/home/sempervent/Downloads/nyt_data.csv')



all_data <- data.table::rbindlist(import_data, fill = TRUE)

final <- data.table::melt.data.table(
  all_data, id.vars = c('country', 'state', 'url', 'access_time',
                        'county.county', 'updated'),
  variable.name = 'attribute')


automated_data <- iterate_collections(automated_scrapes, type = 'state')
auto_data_merge <- data.table::rbindlist(automated_data, fill = TRUE)

ad <- iterate_files(automated_scrapes, type = 'state')




