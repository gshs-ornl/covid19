#!/usr/bin/env Rscript
library(covidR)
library(data.table)

fl <- list.files('/home/sempervent/Documents/covid19data', pattern = '*.csv',
                 full.names = TRUE)

fl_split <- split(fl, rep_len(1:20, length(fl)))

df_list = list()
for (i in 1:length(fl_split)) {
  dat <- covidR::iterate_files(fl_split[[i]])
  df_list[[i]] <- dat
  # fn <- file.path('/home/sempervent/dev/covid_data', paste0('ad_', i, '.csv'))
  # data.table::fwrite(dat, fn)
}
d <- data.table::rbindlist(df_list, fill = TRUE)

c <- d[, c(covidR::static())]

e <- unique(c, by = c('provider','country','state','url', 'updated',
                      'cases', 'deaths', 'presumptive', 'recovered',
                      'tested', 'hospitalized', 'negative', 'counties',
                      'severe', 'lat', 'lon', 'fips', 'monitored',
                      'no_longer_monitored', 'pending', 'active',
                      'inconclusive', 'quarantined', 'resolution',
                      'icu', 'cases_male', 'cases_female', 'lab',
                      'lab_tests', 'lab_positive', 'lab_negative',
                      'age_range', 'age_cases', 'age_percent', 'age_deaths',
                      'age_hospitalized', 'age_tested', 'age_negative',
                      'age_hospitalized_percent', 'age_deaths_percent',
                      'sex', 'sex_counts', 'sex_percent', 'sex_death',
                      'other', 'other_value'))


ages <- fread('/home/sempervent/Documents/covid19data/static/age.csv',
              header = TRUE)
adf <- melt(ages, id.vars = 'age_range')
df <- adf[!is.na(value)]
df[, variable := NULL]
fwrite(df, '/mnt/forbin/dev/data/ages.csv')
