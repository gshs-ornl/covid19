library(covidR)
library(data.table)

if (Sys.getenv('OUTPUT_DIR') != '') {
  output_dir <- Sys.getenv('OUTPUT_DIR')
} else {
  output_dir <- '~/dev/covidb-data/csvs'
}

out_file <- '~/dev/all_join.csv'

combiner(dir = output_dir, output_file = out_file, drop = 'page')

d1 <- fread(out_file, fill = TRUE, blank.lines.skip = TRUE, nrows = 1904)
d2 <- fread(out_file, fill = TRUE, blank.lines.skip = TRUE, skip = 1906,
            nrows = 281795)
d3 <- fread(out_file, fill = TRUE, blank.lines.skip = TRUE, skip = 283701,
            nrows = 844)
d4 <- fread(out_file, fill = TRUE, blank.lines.skip = TRUE, skip = 284547,
            nrows = 9)
d5 <- fread(out_file, fill = TRUE, blank.lines.skip = TRUE, skip = 400000)


