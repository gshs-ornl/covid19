#!/usr/bin/env Rscript
#
#  Usage:
#
#     ./aggregate_covid.R <dir> <aggregation_type> <output_file>
#
#       Aggregate CSVs, .zip files containing CSVs in either the default or the
#       passed directory. The second argument instructs what structure to output
#       the file as. And the third argument instructs where to output the file.
#
#      <dir>  the directory to parse for zip files and csvs
#             DEFAULT: current directory
#      <aggregation_type> currently one of WSTAMP, MELT, SIMPLE
#             DEFAULT: SIMPLE
#      <output_file> the name of the output file
#             DEFAULT: <current_dir>/output.zip
#

# functions ---------------------------------------------------------------
#' @title   load packages and install if not found
#' @param   pkgs a vector of pkgs to install
#' @param   repo your preferred repository
#' @param   lib the library to use for package installation
#' @return  TRUE if successfull, FALSE if not
loadPackages <- function(pkgs, repo = 'https://cloud.r-project.org',
                         lib = .libPaths()[1]) {
  not_installed <- pkgs[!pkgs %in% rownames(installed.packages())]
  install.packages(not_installed, repos = repo, lib = lib)
  loaded <- unlist(lapply(pkgs, require, character.only = TRUE, quietly = TRUE))
  if (any(loaded == FALSE)) {
    message(sprintf('The following packages failed to load: %s',
                    paste0(pkgs[!loaded], collapse = ', ')))
    return(FALSE)
  }
  return(TRUE)
}
#' @title   parse CSVs and zip files in a directory
#' @param   dir the directory to parse
#' @return  a combined data.table of all the data in the directory
parse_csvs <- function(dir) {
  stopifnot(file.exists(dir))
  file_list <- list.files(path = dir, pattern = '(zip|csv)', full.names = TRUE)
  dt_list <- list()
  for (f in file_list) {
    if (endsWith(f, 'csv')) {
      dt_list[[f]] <- data.table::fread(f)
    } else if (endsWith(f, 'zip')) {
      dt_list[[f]] <- data.table::as.data.table(read.table(
        f, header = TRUE, sep = ',', strip.white = TRUE, fill = TRUE,
        stringsAsFactors = FALSE, blank.lines.skip = TRUE
      ))
    }
  }
  invisible(data.table::rbindlist(dt_list, fill = TRUE))
}
#' @title   convert to simple
#' @param   dat the data output from \code{parse_csvs()}
#' @param   output_dir the place to store the simple zip file
#' @return  the location of the zip file
convert_simple <- function(dat, output_dir) {
  tmpzip <- tempfile(fileext = '.csv')
  zipfile <- tempfile(fileext = '.zip')
  data.table::fwrite(dat, tmpzip)
  zip::zip(zipfile, tmpzip)
}
# logic -------------------------------------------------------------------
# type choices definitions:
#     simple - write out a zip file containing the results
#     wstamp - write out a zip file containg the results in WSTAMP compatible
#              format
#        csv - write out a csv
#       flat - write out a flattened (melted) zipped csv ala scraping.melt table
#       json - write out a zipped series of json files for each provider/geo
#              location for input into the new scraping.raw schema
type_choices <- c('simple', 'wstamp', 'csv', 'flat', 'json')
# name the packages that we need for this script
pkgs <- c('data.table', 'zip', 'readr')
stopifnot(loadPackages(pkgs))  # stop if all packages cannot be installed/loaded
args <- commandArgs(trailingOnly = TRUE)
if (length(args) == 0) {
  dir = getwd()
  type = "SIMPLE"
  output_file =  file.path(dir, 'output.zip')
} else if (length(args) == 1) {
  dir = args[1]
  type = "SIMPLE"
  output_file =  file.path(getwd(), 'output.zip')
} else if (length(args) == 2) {
  dir = args[1]
  type = args[2]
  output_file =  file.path(getwd(), 'output.zip')
} else if (length(args) == 3) {
  dir = args[1]
  type = args[2]
  output_file = args[3]
} else {
  stop('Unknown logic encountered')
}
stopifnot(file.exists(dir))
message(gettextf(paste0('Initializing aggregation:\n\tInput Directory\t%s\n\t',
                        'Type:\t%s\n\tOutput:\t%s'), dir, type, output_file))
if (!tolower(type) %in% type_choices) {
  stop(gettextf('Invalide type choice "%s"', type))
}
dt <- parse_csvs(dir = dir)



