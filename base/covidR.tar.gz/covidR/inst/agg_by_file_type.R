#!/usr/bin/env Rscript
library(data.table)

read_list <- function(lst) {
  dlst <- list()
  lst_len <- length(lst)
  for (i in 1:length(lst)) {
    message(gettextf('Processing file: %s', lst[[i]]))
    dlst[[i]] <- tryCatch({
      fread(lst[[i]], fill = TRUE)
    },
    warning = function(cond) {
      fread(lst[[i]], fill = TRUE)
    },
    error = function(cond) {
      data.table::data.table()
    })
    message(gettextf('Percent complete: %g', which(lst == f)/lst_len))
  }
  message(gettextf('Processed %d', length(dlst)))
  data.table::rbindlist(dlst, fill = TRUE, idcol = 'file')
}

file_list <- list.files('~/dev/covidb-data/csvs', full.names = TRUE)
al_file_list <- file_list[grepl('alabama', file_list)]
AL <- read_list(al_file_list)
unique(AL[['updated']])
