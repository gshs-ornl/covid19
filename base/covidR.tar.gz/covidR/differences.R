#!/usr/bin/env Rscript
library(data.table)
library(ggplot2)
library(ggthemes)
library(gridExtra)
library(anytime)
library(lubridate)
library(reshape2)
gdat <- as.Date('2000/01/01')
# Import Automated Data ---------------------------------------------------
ald <- fread('/mnt/forbin/dev/state_automated_scrapes.csv')[,1:86]
ald[, `:=`(county = county.county,
           county.county = NULL,
           access_time = NULL,
           date = as.Date(updated),
           updated = NULL,
           provider = 'state')]
ald[(is.na(county) | county == '') & parish != '', county := parish]
ald[is.na(county) | county == '', county := county.County]
ald <- ald[!is.na(county),]
ald <- ald[county != '',]
ald <- ald[,c('provider','country','state','county','date', 'cases', 'deaths')]
fwrite(ald, '/mnt/forbin/dev/automated_county_data-0407.csv')
# Import Hattiesburg Data -------------------------------------------------
hat <- fread('/mnt/forbin/dev/covidR_hattiesburg_raw_202004011406.csv')
hat[, `:=`(date = as.Date(paste(update_time, '2020'), format = '%B %d %Y'),
           update_time = NULL,
           provider = 'hattiesburg')]
hat <- hat[,c('provider','country', 'date', 'cases','deaths')]
fwrite(hat, '/mnt/forbin/dev/hat_data-0401.csv')
# Import NYT Data ---------------------------------------------------------
nyt <- fread('/mnt/forbin/dev/covidR_nyt_counties_raw_202004011001.csv')
nyt[, `:=`(date = as.Date(date),
           provider = 'nyt',
           country = 'US',
           fips = NULL)]
nyt <- nyt[,c('provider', 'country', 'state', 'county', 'date', 'cases',
              'deaths')]
# Import Johns Hopkins Data -----------------------------------------------
hop <- fread('/mnt/forbin/dev/covidR_hopkins_daily_once_raw_202004011001.csv')
hop[, date := gdat]
hop[, Last_Update := gsub('T', ' ', as.character(Last_Update), fixed = TRUE)]
hop[nchar(Last_Update) %in% c(11, 12, 13) & date == gdat,
    date := as.Date(Last_Update, format = '%m/%d/%y %H:%M')]
hop[date != gdat & !is.na(date), Last_Update := NA]
hop[nchar(Last_Update) == 13 & date == gdat,
    date := as.Date(Last_Update, format = '%m/%d/%Y %H:%M')]
hop[date != gdat & !is.na(date), Last_Update := NA]
hop[nchar(Last.Update) %in% c(13,14,15) & date == gdat,
    date := as.Date(Last.Update, format = '%m/%d/%Y %H:%M')]
hop[date != gdat & !is.na(date), Last.Update := NA]
hop[date == gdat, date := anytime::anydate(Last_Update)]
hop[date != gdat & !is.na(date), Last_Update := NA]
hop[date == gdat, `:=`(date = anytime::anydate(Last.Update))]
hop[date != gdat & !is.na(date), Last.Update := NA]
unique(hop[is.na(date), c('Last_Update', 'Last.Update')])
hop[!is.na(Last_Update) & (date == gdat | is.na(date)),
    date := as.Date(Last_Update, format = '%Y-%m-%dT%H:%M:%S')]
hop[date != gdat & !is.na(date), Last_Update := NA]
hop[!is.na(Last.Update) & (date == gdat | is.na(date)),
    date := as.Date(Last.Update, format = '%Y-%m-%dT%H:%M:%S')]
hop[date != gdat & !is.na(date), Last.Update := NA]
hop[, date := format(date, format = '%Y-%m-%d')]
hop[nchar(date) == 8, date := paste0('20', date)]
hop[, date := as.Date(date)]
# fwrite(hop, '/mnt/forbin/dev/hopkins_0401_date_fixed.csv')
# hop <- fread('/mnt/forbin/dev/hopkins_0401_date_fixed.csv')
hop[, `:=`(Last.Update = NULL, Last_Update = NULL, Lat = NULL,
           cases = Confirmed, Long_ = NULL, Active = NULL,
           Confirmed = NULL, country = NA_character_,
           deaths = Deaths, state = NA_character_,
           Deaths = NULL, county = NA_character_)]
hop[Country.Region != '', country := Country.Region]
hop[is.na(country), country := Country_Region]
hop[is.na(state), state := Province.State]
hop[is.na(state) | state == '', state := Province_State]
hop[is.na(county), county := Admin2]
hop[, `:=`(Province.State = NULL,
           Province_State = NULL,
           Country.Region = NULL,
           Country_Region = NULL,
           Combined_Key = NULL,
           # Recovered = NULL,
           Latitude = NULL,
           Longitude = NULL,
           FIPS = NULL,
           Admin2 = NULL,
           provider = 'hopkins')]
hop <- hop[, c('provider', 'country', 'state', 'county', 'date', 'cases',
               'deaths')]
# Import Tomq Data --------------------------------------------------------
tmq <- fread('/mnt/forbin/dev/covidR_tomq_once_raw_202004011000.csv')
tmq[, `:=`(provider = 'tomq',
           country = 'US',
           state = State_Name, State_Name = NULL,
           county = County_Name, County_Name = NULL,
           date = as.Date(substr(Last_Update, 1, length(Last_Update) - 4),
                          format = '%Y-%m-%d %H:%M'),
           cases = Confirmed, deaths = Death, Latitude = NULL,
           Longitude = NULL, New_Death = NULL, Confirmed = NULL,
           Death = NULL, Fatality_Rate = NULL, New = NULL,
           Last_Update = NULL)]
tmq[state == 'New York' & county == 'New York', county := 'New York City']
# Import Manual Scrapes ---------------------------------------------------
man <- fread('/home/sempervent/Downloads/manual_scrape_all.csv')
man[, `:=`(provider = 'state', country = 'US', state = State, State = NULL,
           county = county.county, url = NULL, access_time = NULL,
           pending = NULL, monitored = NULL, no_longer_monitor = NULL,
           hospitalized = NULL, negative = NULL, tested = NULL,
           tested_comm = NULL, tested_state = NULL, cases_age_definition = NULL,
           cases_age_value = NULL, cases_age_percent = NULL, recovered = NULL,
           hospitalized_age_definition = NULL, hospitalized_age_value = NULL,
           hospitalized_age_percent = NULL, deaths_age_percent = NULL,
           deaths_age_definition = NULL, deaths_age_value = NULL, date = gdat,
           sex_definition = NULL, sex_cases = NULL, sex_percent = NULL,
           other_definition = NULL, other_value = NULL, county.county = NULL,
           cases = as.integer(cases), deaths = as.integer(deaths))]
man[nchar(updated) == 17 & date == gdat & !is.na(updated),
    `:=`(date = anytime::anydate(updated), updated = NA_character_)]
man[nchar(updated) == 9 & date == gdat & !is.na(updated),
    `:=`(date = anytime::anydate(updated), updated = NA_character_)]
man[nchar(updated) == 18 & date == gdat & !is.na(updated),
    `:=`(date = anytime::anydate(updated), updated = NA_character_)]
man[nchar(updated) == 19 & date == gdat & !is.na(updated),
    `:=`(date = anytime::anydate(updated), updated = NA_character_)]
man[nchar(updated) == 5, `:=`(updated = NA_character_,
                              date = as.Date('2020/03/29'))]
# below
dat <- man
man <- dat
man[nchar(updated) == 15 & date == gdat & !is.na(updated),
    `:=`(date = as.Date(updated, format = '%Y-%m-%d-%H:%M'),
         updated = NA_character_)]
man[nchar(updated) == 16 & date == gdat & !is.na(updated),
    updated := substr(updated, 1, 9)]
man[date == gdat & !is.na(updated),
    `:=`(date = anytime::anydate(updated), updated = NA_character_)]
unique(man[['updated']])
unique(man[['date']])
man <- man[!is.na(date)]
man[, updated := NULL]
# Combine Data for Plotting -----------------------------------------------
dat <- data.table::rbindlist(list(ald, man, hat, nyt, hop, tmq), fill = TRUE)
us <- dat[country == 'US' & !county %in% c('Total', 'Unknown'),]
tt <- us[(state == 'New York' & county == 'New York City') |
           (state == 'Tennessee' & county == 'Shelby') |
           (state == 'Tennessee' & county == 'Knox') |
           (state == 'New York' & county == 'Nassau') |
           (state == 'Louisiana' & county == 'Orleans') |
           (state == 'California' & county == 'Los Angeles') |
           (state == 'Illinois' & county == 'Cook') |
           (state == 'Pennsylvania' & county == 'Philadelphia') |
           (state == 'New York' & county == 'Suffolk') |
           (state == 'Washington' & county == 'King') |
           (state == 'Flordia' & county == 'Broward') |
           (state == "Massachusetts" & county == 'Berkshire')]
tp <- tt[cases > 0 & !is.na(date),
         .(dist = max(cases, na.rm = TRUE) - min(cases, na.rm = TRUE)),
         by = c('state', 'county', 'date')]
tp <- tp[!is.na(date),]
scaleFactor <- max(tt$cases, na.rm = TRUE) / max(tp$dist, na.rm = TRUE)
counties <- unique(tt[['county']])
plot_list <- list()
for (plot_county in counties) {
  dat1 <- unique(tt[county == plot_county & date > as.Date('2020-03-08') &
                      !is.na(cases)  & cases > 0])
  dat2 <- unique(tp[county == plot_county & date > as.Date('2020-03-08') &
                      !is.na(dist)])
  state <- unique(dat1[['state']])
  plot_title <- paste0(plot_county, ', ', state)
  p1 <- ggplot(dat1, aes(x = date, y = cases, color = provider)) +
    scale_x_date(expand = c(0,0)) + scale_y_continuous(expand = c(0,0)) +
    geom_line() + theme_bw() + geom_smooth() +
    ggtitle(paste0('Cases for ', plot_title)) +
    theme(legend.position = 'bottom',
          axis.title.x = element_blank()) +
    ylab('Confirmed Cases')
  p2 <- ggplot(dat2[date > as.Date('2020-03-08')],
               aes(x = date, y = dist, color = county)) +
    scale_x_date(expand = c(0,0)) + geom_smooth() +
    scale_y_continuous(expand = c(0,0)) + geom_line() + theme_bw() +
    ggtitle(
      paste0('Daily Range Distances for All Sources')) +
    xlab('Date') + ylab('Distance Between Reported Min and Max per Day') +
    guides(color=guide_legend(title = 'County')) +
    theme(plot.title = element_text(hjust = 0.5))
  dat3 <- dat1[,.(dist = max(cases, na.rm = TRUE) - min(cases, na.rm = TRUE))]
  p3 <- ggplot(dat3[date > as.Date('2020-03-08')],
               aes(x = date, y = dist)) + geom_smooth()
  plot_list[plot_county] <- grid.arrange(p1, p2, p3, nrow = 3, ncol = 1)


}


ggplot(tt, aes(x = date)) +
  theme_bw()

ggplot(tp[ date > as.Date('2020-03-08')],
       aes(x = date, y = dist, color = county)) +
  geom_line() + theme_bw()
ggplot(tt, aes(x = date, y = cases, color = county))

dd <- dcast(tt, formula = d)


tp <- tt[cases > 0 & !is.na(date) & provider != 'state',
         .(dist = max(cases, na.rm = TRUE) - min(cases, na.rm = TRUE)),
         by = c('state', 'county', 'date')]
tp <- tp[!is.na(date),]
ggplot(tp[date > as.Date('2020-03-08')],
       aes(x = date, y = dist, color = county)) +
  scale_x_date(expand = c(0,0)) +
  scale_y_continuous(expand = c(0,0)) + theme_bw() +
  ggtitle(
    paste0('Daily Range Distances for NYT, Tomq, and Hopkins')) +
  xlab('Date') + ylab('Distance Between Reported Min and Max per Day') +
  guides(color=guide_legend(title = 'County')) +
  theme(plot.title = element_text(hjust = 0.5)) + geom_smooth(fullrange = FALSE,
                                                              se = FALSE)
tp <- tt[cases > 0 & !is.na(date),
         .(dist = max(cases, na.rm = TRUE) - min(cases, na.rm = TRUE)),
         by = c('state', 'county', 'date')]
tp <- tp[!is.na(date),]
ggplot(tp[date > as.Date('2020-03-08')],
       aes(x = date, y = dist, color = county)) + geom_smooth(fullrange = FALSE,
                                                              se = FALSE) +
  scale_x_date(expand = c(0,0)) +
  scale_y_continuous(expand = c(0,0)) + theme_bw() +
  ggtitle(
    paste0('Daily Range Distances for All Sources')) +
  xlab('Date') + ylab('Distance Between Reported Min and Max per Day') +
  guides(color=guide_legend(title = 'County')) +
  theme(plot.title = element_text(hjust = 0.5))
ggplot(tt[date > as.Date('2020-03-08')],
       aes(x = date, y = ))

tp <- unique(tt[cases > 0 & !is.na(date) & !provider %in% c('hopkins', 'nyt', 'man'),
         .(dist = max(cases, na.rm = TRUE) - min(cases, na.rm = TRUE)),
         by = c('state', 'county', 'date')])
tp <- tp[!is.na(date),]
ggplot(tp[date > as.Date('2020-03-08')],
       aes(x = date, y = dist, color = county)) +
  scale_x_date(expand = c(0,0)) +
  scale_y_continuous(expand = c(0,0)) + theme_bw() +
  ggtitle(
    paste0('Daily Range Distances for NYT, Tomq, and Hopkins')) +
  xlab('Date') + ylab('Distance Between Reported Min and Max per Day') +
  guides(color=guide_legend(title = 'County')) +
  theme(plot.title = element_text(hjust = 0.5)) + geom_smooth(fullrange = FALSE,
                                                              se = FALSE)

pc <- melt(unique(tt[state %in% unique(tt[provider == 'state'][['state']]) |
              date %in% unique(tt[provider == 'state'][['date']]) |
              county %in% unique(tt[provider == 'state'][['county']]),
            .(case_sums = sum(cases, na.rm = TRUE),
             cases_max = sum(cases, na.rm = TRUE),
             cases_min = sum(cases, na.rm = TRUE),
             cases_avg = mean(cases, na.rm = TRUE),
             cases_std = mean(cases, na.rm = TRUE),
             cases_dst = max(cases, na.rm = TRUE) - min(cases, na.rm=TRUE),
             death_sums = sum(deaths, na.rm = TRUE),
             deaths_max = sum(deaths, na.rm = TRUE),
             deaths_min = sum(deaths, na.rm = TRUE),
             deaths_avg = mean(deaths, na.rm = TRUE),
             deaths_std = mean(deaths, na.rm = TRUE)
             ),
         by = c('provider', 'date')]), id.vars = c('provider', 'date'),
         na.rm = TRUE)
ggplot(pc[date > as.Date('2020/03/08')],
       aes(x = date, y = value, color = provider)) +
  facet_wrap(. ~ variable, scales = 'free') +
  geom_line() + ggthemes::theme_fivethirtyeight()
