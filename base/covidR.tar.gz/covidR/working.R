#!/usr/bin/env Rscript
iterate_files <- function(files) {
  file_list <- list()
  for (f in files) {
    candidate <- try_fread(f, integer64 = 'character', logical01 = FALSE)
    file_list[[f]] <- candidate
  }
  data.table::rbindlist(file_list, fill = TRUE)
}
csvs <- list.files('Z:/dev/data', pattern = '.csv',
                   full.names = TRUE)
d <- iterate_files(csvs)

auto <- data.table::fread(csvs[1], integer64='character')
hat <- data.table::fread(csvs[2])
hop <- data.table::fread(csvs[3])
man <- data.table::fread(csvs[4])
nytc <- data.table::fread(csvs[5])
nyts <- data.table::fread(csvs[6])
pys <- data.table::fread(csvs[7])
tom <- data.table::fread(csvs[8])

ad <- data.table::rbindlist(list(auto, hat, hop, man, nytc, nyts, pys, tom),
                            fill = TRUE)

fwrite(ad, 'Z:/dev/data/ALL.csv')

jd <- jsonlite::toJSON(ad)
jsonlite::write_json(jd, 'Z:/dev/data/ALL.json')
