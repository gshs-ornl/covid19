pkgs <- c('choroplethr', 'data.table', 'viridis', 'usmap', 'ggthemes',
          'ggplot2', 'cowplot', 'magrittr', 'multipanelfigure' )
lapply(pkgs, require, character.only = TRUE, quietly = TRUE)

dat <- fread(file = 'C:\\Users/jngra/Downloads/Scrape.csv')
dat[, fips := NULL``]
dat[, region := paste(counties, 'County')]

map('county')
region_info <- as.data.table(us_map(regions = 'counties'))

d <- merge.data.table(dat, region_info, by.x = c('state_name', 'region'),
                      by.y = c('full', 'county'))


cd <- d[, value := as.integer(cases)]
cd <- cd[, c('fips', 'value')]
cases <- plot_usmap(regions = 'county', data = cd, values = 'value') +
  scale_fill_viridis(trans = 'log',
                        breaks = c(1,5,10,20,50,100,250,500,1000),
                     na.value = 'white') +
  guides(fill=guide_legend(title='Cases')) +
  ggtitle('COVID-19 Confirmed Cases') +
  theme(plot.title = element_text(hjust = 0.5))



cd <- d[, value := as.integer(deaths)]
cd <- cd[, c('fips', 'value')]
cd <- cd[value > 0]
deaths <- plot_usmap(regions = 'county', data = cd, values = 'value') +
  scale_fill_viridis(na.value = 'white') +
  guides(fill=guide_legend(title='Deaths')) + ggtitle('COVID-19 Deaths') +
  theme(plot.title = element_text(hjust = 0.5))

pdf(file = 'map_example.pdf', width = 8, height = 10)
plot_grid(cases, deaths, ncol = 1, align = 'v', pointsize = 6)
dev.off()

ggsave(filename = 'deaths.png', deaths, scale = 1.2, dpi = 700,
       width = 8, height = 5, units = 'in')
ggsave(filename = 'cases.png', cases, scale = 1.2, dpi = 700,
       width = 8, height = 5, units = 'in')


